import{e as ce,i as Xt,s as ks,a as Qt,b as We,c as _s}from"./assets/domain.js";const St={"15m":{id:"15m",labelKey:"settings.lock_15m",ms:15*60*1e3},"1h":{id:"1h",labelKey:"settings.lock_1h",ms:60*60*1e3},"8h":{id:"8h",labelKey:"settings.lock_8h",ms:8*60*60*1e3},session:{id:"session",labelKey:"settings.lock_session",ms:0},"1day":{id:"1day",labelKey:"settings.lock_1day",ms:24*60*60*1e3}},ne="sp_active_session";let fe=null;function xs(e){const t=new Uint8Array(e);let a="";for(let o=0;o<t.byteLength;o++)a+=String.fromCharCode(t[o]);return btoa(a)}function Ss(e){const t=atob(e),a=new Uint8Array(t.length);for(let o=0;o<t.length;o++)a[o]=t.charCodeAt(o);return a.buffer}function Mt(){return typeof chrome<"u"&&chrome.storage&&chrome.storage.local?chrome.storage.local:{get:(e,t)=>{try{const a=localStorage.getItem(e);t({[e]:a?JSON.parse(a):null})}catch{t({[e]:null})}},set:(e,t)=>{try{Object.entries(e).forEach(([a,o])=>localStorage.setItem(a,JSON.stringify(o)))}catch{}t&&t()},remove:(e,t)=>{try{localStorage.removeItem(e)}catch{}t&&t()}}}function js(e){return!e||e==="session"?"session":St[e]?e:e==="3days"||e==="1week"||e==="1month"?"1day":"session"}async function Be(e,t="session"){if(!(e instanceof Uint8Array)||e.length!==32)throw new TypeError("createSession expects a raw MEK Uint8Array");const a=js(t),o=St[a]||St.session,i=Date.now(),d=o.id==="session"?0:i+o.ms,u=new Uint8Array(e);fe=u;const l={token:xs(u),isRawMek:!0,createdAt:i,expiresAt:d,intervalId:o.id},p=Mt(),m=o.id==="1day";return!m&&typeof chrome<"u"&&chrome.storage&&chrome.storage.session?(await new Promise(h=>chrome.storage.session.set({[ne]:l},h)),await new Promise(h=>p.remove(ne,h))):m?(await new Promise(h=>p.set({[ne]:l},h)),typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&await new Promise(h=>chrome.storage.session.remove(ne,h))):await new Promise(h=>p.set({[ne]:l},h)),l}async function $s(){if(fe)return{rawMek:fe,expiresAt:0,intervalId:"session"};const e=Mt();let t=null;if(typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&(t=await new Promise(o=>{chrome.storage.session.get(ne,i=>o(i[ne]||null))})),t||(t=await new Promise(o=>{e.get(ne,i=>o(i[ne]||null))})),!t||!t.token)return null;if(!t.isRawMek)return await ve(),null;const a=Date.now();if(t.expiresAt>0&&a>t.expiresAt)return await ve(),null;try{const o=new Uint8Array(Ss(t.token));return o.length!==32?(await ve(),null):(fe=o,{rawMek:o,expiresAt:t.expiresAt,intervalId:t.intervalId})}catch{return await ve(),null}}async function ve(){if(fe&&fe.fill)try{fe.fill(0)}catch{}fe=null;const e=Mt();typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.remove(ne),await new Promise(t=>e.remove(ne,t))}const Es=6e5,Yt=16,Ot=12;function we(e){const t=new Uint8Array(e);let a="";for(let o=0;o<t.byteLength;o++)a+=String.fromCharCode(t[o]);return btoa(a)}function re(e){const t=atob(e),a=new Uint8Array(t.length);for(let o=0;o<t.length;o++)a[o]=t.charCodeAt(o);return a.buffer}async function Ze(e,t){const a=new TextEncoder,o=await crypto.subtle.importKey("raw",a.encode(e),"PBKDF2",!1,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:t,iterations:Es,hash:"SHA-256"},o,{name:"AES-GCM",length:256},!1,["encrypt","decrypt"])}const rt=["abandon","ability","able","about","above","absent","absorb","abstract","absurd","abuse","access","accident","account","accuse","achieve","acid","acoustic","acquire","across","act","action","actor","actress","actual","adapt","add","addict","address","adjust","admit","adult","advance","advice","aerobic","affair","afford","afraid","again","age","agent","agree","ahead","aim","air","airport","aisle","alarm","album","alcohol","alert","alien","all","alley","allow","almost","alone","alpha","already","also","alter","always","amateur","amazing","among","amount","amused","analyst","anchor","ancient","anger","angle","angry","animal","ankle","announce","annual","another","answer","antenna","antique","anxiety","any","apart","apology","appear","apple","approve","april","arch","arctic","area","arena","argue","arm","armed","armor","army","around","arrange","arrest","arrive","arrow","art","artefact","artist","artwork","ask","aspect","assault","asset","assist","assume","asthma","athlete","atom","attack","attend","attitude","attract","auction","audit","august","aunt","author","auto","autumn","average","avocado","avoid","awake","aware","away","awesome","awful","awkward","axis","baby","bachelor","bacon","badge","bag","balance","balcony","ball","bamboo","banana","banner","bar","barely","bargain","barrel","base","basic","basket","battle","beach","bean","beauty","because","become","beef","before","begin","behave","behind","believe","below","belt","bench","benefit","best","betray","better","between","beyond","bicycle","bid","bike","bind","biology","bird","birth","bitter","black","blade","blame","blanket","blast","bleak","bless","blind","blood","blossom","blouse","blue","blur","blush","board","boat","body","boil","bomb","bone","bonus","book","boost","border","boring","borrow","boss","bottom","bounce","box","boy","bracket","brain","brand","brass","brave","bread","breeze","brick","bridge","brief","bright","bring","brisk","broccoli","broken","bronze","broom","brother","brown","brush","bubble","buddy","budget","buffalo","build","bulb","bulk","bullet","bundle","bunker","burden","burger","burst","bus","business","busy","butter","buyer","buzz","cabbage","cabin","cable"];function pt(){const e=[],t=new Uint8Array(12);crypto.getRandomValues(t);for(let a=0;a<12;a++){const o=t[a]%rt.length;e.push(rt[o])}return e.join(" ")}function Ne(e){return!e||typeof e!="string"?"":e.trim().toLowerCase().split(/\s+/).join(" ")}function Is(e,t){const a=e.length,o=t.length,i=Array.from({length:a+1},()=>new Array(o+1).fill(0));for(let r=0;r<=a;r++)i[r][0]=r;for(let r=0;r<=o;r++)i[0][r]=r;for(let r=1;r<=a;r++)for(let d=1;d<=o;d++)e[r-1]===t[d-1]?i[r][d]=i[r-1][d-1]:i[r][d]=1+Math.min(i[r-1][d],i[r][d-1],i[r-1][d-1]);return i[a][o]}function Cs(e){const t=e.trim().toLowerCase();if(rt.includes(t))return{word:t,distance:0,exact:!0,suggestion:null};let a=null,o=1/0;for(const i of rt){const r=Is(t,i);r<o&&(o=r,a=i)}return{word:a,distance:o,exact:!1,suggestion:o<=2?a:null}}function Ps(e){return!e||typeof e!="string"?[]:e.trim().toLowerCase().split(/\s+/).filter(Boolean).map(a=>{const o=Cs(a);return{word:a,valid:o.exact,suggestion:o.suggestion}})}function ut(){return crypto.getRandomValues(new Uint8Array(32))}const Zt=new TextEncoder().encode("simplepass|v3|payload"),es=new TextEncoder().encode("simplepass|v3|mek-pwd"),ts=new TextEncoder().encode("simplepass|v3|mek-rec");async function Z(e,t,a=null){const o=typeof t=="string"?t:"",i=crypto.getRandomValues(new Uint8Array(Yt)),r=crypto.getRandomValues(new Uint8Array(Ot)),d=await Ze(o,i),u={name:"AES-GCM",iv:r};a==="mek-pwd"?u.additionalData=es:a==="mek-rec"&&(u.additionalData=ts);const l=await crypto.subtle.encrypt(u,d,e),p={salt:we(i),iv:we(r),data:we(l)};return a&&(p.aad=!0,p.slot=a),p}async function Je(e,t){if(!e||e.version!==2&&e.version!==3||!e.keyByPassword)throw new Error("Invalid vault envelope structure");try{const a=e.keyByPassword,o=new Uint8Array(re(a.salt)),i=new Uint8Array(re(a.iv)),r=re(a.data),d=await Ze(t,o),u={name:"AES-GCM",iv:i};(a.aad===!0||e.version>=3&&a.aad!==!1)&&(u.additionalData=es);const l=await crypto.subtle.decrypt(u,d,r);return new Uint8Array(l)}catch{throw new Error("Invalid master password or corrupted vault.")}}async function zs(e,t){if(!e||e.version!==2&&e.version!==3||!e.keyByRecovery)throw new Error("12-word recovery key is not supported for this vault version.");const a=Ne(t);if(!a||a.split(" ").length!==12)throw new Error("Recovery key must contain exactly 12 words.");try{const o=e.keyByRecovery,i=new Uint8Array(re(o.salt)),r=new Uint8Array(re(o.iv)),d=re(o.data),u=await Ze(a,i),l={name:"AES-GCM",iv:r};o.aad===!0&&(l.additionalData=ts);const p=await crypto.subtle.decrypt(l,u,d);return new Uint8Array(p)}catch{throw new Error("Invalid recovery key or corrupted vault.")}}async function xe(e,t,a=null){const i=new TextEncoder().encode(JSON.stringify(e)),r=await crypto.subtle.importKey("raw",t,{name:"AES-GCM"},!1,["encrypt"]),u=!a||!!(a.keyByPassword&&a.keyByPassword.aad)?3:2,l=crypto.getRandomValues(new Uint8Array(Ot)),p={name:"AES-GCM",iv:l};u===3&&(p.additionalData=Zt);const m=await crypto.subtle.encrypt(p,r,i),h={version:u,iv:we(l),data:we(m)};return a&&(a.keyByPassword&&(h.keyByPassword=a.keyByPassword),a.keyByRecovery&&(h.keyByRecovery=a.keyByRecovery)),h}async function mt(e,t){if(!e||!e.data||!e.iv)throw new Error("Invalid vault envelope structure");const a=new TextDecoder,o=await crypto.subtle.importKey("raw",t,{name:"AES-GCM"},!1,["decrypt"]),i=new Uint8Array(re(e.iv)),r=re(e.data),d={name:"AES-GCM",iv:i};e.version===3&&(d.additionalData=Zt);const u=await crypto.subtle.decrypt(d,o,r);return JSON.parse(a.decode(u))}async function Ls(e,t,a=null){if(a){const p=ut(),m=await Z(p,t,"mek-pwd"),h=Ne(a),g=await Z(p,h,"mek-rec");return await xe(e,p,{keyByPassword:m,keyByRecovery:g})}const i=new TextEncoder().encode(JSON.stringify(e)),r=crypto.getRandomValues(new Uint8Array(Yt)),d=crypto.getRandomValues(new Uint8Array(Ot)),u=await Ze(t,r),l=await crypto.subtle.encrypt({name:"AES-GCM",iv:d},u,i);return{version:1,salt:we(r),iv:we(d),data:we(l)}}async function Ge(e,t){if(!e||!e.data)throw new Error("Invalid vault envelope structure");if((e.version===2||e.version===3)&&e.keyByPassword){const u=await Je(e,t);return await mt(e,u)}if(!e.salt||!e.iv)throw new Error("Invalid vault envelope structure");const a=new TextDecoder,o=new Uint8Array(re(e.salt)),i=new Uint8Array(re(e.iv)),r=re(e.data),d=await Ze(t,o);try{const u=await crypto.subtle.decrypt({name:"AES-GCM",iv:i},d,r),l=a.decode(u);return JSON.parse(l)}catch{throw new Error("Invalid master password or corrupted vault.")}}async function As(e,t){const a=await zs(e,t);return{vaultData:await mt(e,a),rawMek:a}}function gt(e){return!e||typeof e!="string"?{valid:!1,errorCode:"pwd_empty",error:"pwd_empty"}:e.length<10?{valid:!1,errorCode:"pwd_too_short",error:"pwd_too_short"}:e.length<16&&!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/.test(e)?{valid:!1,errorCode:"pwd_needs_special",error:"pwd_needs_special"}:{valid:!0,errorCode:null,error:null}}const Y="sp_encrypted_vault",jt="sp_user_config",de="sp_vault_profiles",ue="sp_active_vault_id",Ke="sp_favicon_cache",Ts={activeProjectId:"proj_default",latestProjectId:"proj_default",lockInterval:"session",autolockMinutes:15,clipboardClearSeconds:30,theme:"light",language:"en",defaultCategory:"Work",categories:["Work","Personal"],showCardTags:!1,showFavicons:!0,useExternalIcons:!1,currentSiteEnabled:!0},tt=new Map,kt=typeof localStorage<"u",Vt=typeof chrome<"u"&&chrome.storage&&chrome.storage.local?chrome.storage.local:{get:(e,t)=>{const a={},o=r=>kt?localStorage.getItem(r):tt.has(r)?tt.get(r):null,i=(r,d=null)=>{if(!r)return d;try{return JSON.parse(r)}catch{return d}};if(Array.isArray(e))e.forEach(r=>{const d=o(r);if(d!=null){const u=i(d,null);u!==null&&(a[r]=u)}});else if(typeof e=="string"){const r=o(e);if(r!=null){const d=i(r,null);d!==null&&(a[e]=d)}}else typeof e=="object"&&e!==null&&Object.keys(e).forEach(r=>{const d=o(r);a[r]=d!=null?i(d,e[r]):e[r]});t(a)},set:(e,t)=>{Object.entries(e).forEach(([a,o])=>{const i=JSON.stringify(o);kt?localStorage.setItem(a,i):tt.set(a,i)}),t&&t()},remove:(e,t)=>{const a=o=>{kt?localStorage.removeItem(o):tt.delete(o)};Array.isArray(e)?e.forEach(a):a(e),t&&t()}};function Nt(){return typeof chrome<"u"&&chrome.runtime&&chrome.runtime.lastError?new Error(chrome.runtime.lastError.message||"chrome.storage operation failed"):null}function $e(e){return new Promise((t,a)=>{Vt.get(e,o=>{const i=Nt();if(i)return a(i);t(o)})})}function Ce(e){return new Promise((t,a)=>{Vt.set(e,()=>{const o=Nt();if(o)return a(o);t()})})}function $t(e){return new Promise((t,a)=>{Vt.remove(e,()=>{const o=Nt();if(o)return a(o);t()})})}async function he(){const e=await $e([de,Y]);let t=e[de];const a=e[Y];return(!t||t.length===0)&&a?(t=[{id:"vault_default",name:"Main Vault",storageKey:Y,createdAt:new Date().toISOString()}],await Ce({[de]:t,[ue]:"vault_default"}),t):t&&Array.isArray(t)?t:[]}async function Fe(){const e=await $e([ue,de,Y]),t=e[ue],a=e[de]||[];return t&&a.some(o=>o.id===t)?t:a.length>0?a[0].id:e[Y]?"vault_default":null}function Bs(e){return Ce({[ue]:e})}async function Ee(e){const t=await he(),a=await Fe()||"vault_default";let o=Y;const i=t.find(d=>d.id===a);if(i)o=i.storageKey;else if(a!=="vault_default")return null;const r=await $e(o);return r[o]!==void 0&&r[o]!==null?r[o]:a==="vault_default"&&o!==Y&&(await $e(Y))[Y]||null}async function De(e,t){let a=await Fe(),o=await he();a||(a="vault_default");let i=o.find(d=>d.id===a),r=i?i.storageKey:a==="vault_default"?Y:`sp_vault_${a}`;return i||(i={id:a,name:"Main Vault",storageKey:r,createdAt:new Date().toISOString()},o=[...o,i]),await Ce({[r]:e,[de]:o,[ue]:a}),i}async function Ds(e,t){const a=await he(),o="vault_"+Date.now()+"_"+Math.random().toString(36).substr(2,4),i=`sp_vault_${o}`,r=e&&e.trim()||`Vault ${a.length+1}`,d={id:o,name:r,storageKey:i,createdAt:new Date().toISOString()},u=[...a,d];return await Ce({[i]:t,[de]:u,[ue]:o}),d}async function Ms(e){const t=await he(),a=t.findIndex(l=>l.id===e);if(a===-1)return t;const o=t[a],i=t.filter(l=>l.id!==e),r=await Fe();let d=r;r===e&&(d=i.length>0?i[0].id:null),await $t(o.storageKey);const u={[de]:i};return d&&(u[ue]=d),await Ce(u),d||await $t([ue,Y]),i}async function q(){const e=await $e(jt);return{...Ts,...e[jt]||{}}}function W(e){return Ce({[jt]:e})}const Wt=300,ss=48*1024;let Le=null,ke=null;async function as(){if(ke){const o={};for(const[i,r]of Object.entries(ke))o[i]=r&&typeof r=="object"&&r.dataUrl?r.dataUrl:typeof r=="string"?r:"";return o}const t=(await $e(Ke))[Ke]||{},a={};for(const[o,i]of Object.entries(t))a[o]=i&&typeof i=="object"&&i.dataUrl?i.dataUrl:typeof i=="string"?i:"";return a}function Os(e){const t=[],a=Date.now();for(const[i,r]of Object.entries(e||{})){let d="",u=a;r&&typeof r=="object"&&r.dataUrl?(d=r.dataUrl,u=r.usedAt||a):typeof r=="string"&&(d=r),d&&d.length<=ss&&t.push({domain:i.toLowerCase().trim(),dataUrl:d,usedAt:u})}t.length>Wt&&(t.sort((i,r)=>r.usedAt-i.usedAt),t.length=Wt);const o={};for(const i of t)o[i.domain]={dataUrl:i.dataUrl,usedAt:i.usedAt};return ke=null,Ce({[Ke]:o})}function Vs(){if(Le&&(clearTimeout(Le),Le=null),ke){const e=ke;return ke=null,Os(e)}return Promise.resolve()}async function ye(e){if(!e||typeof e!="string")return null;const t=e.toLowerCase().trim();return(await as())[t]||null}async function st(e,t){if(!e||!t||typeof t=="string"&&t.length>ss)return;const a=e.toLowerCase().trim(),o=ke||(await $e(Ke))[Ke]||{};return o[a]={dataUrl:t,usedAt:Date.now()},ke=o,Le&&clearTimeout(Le),new Promise(i=>{Le=setTimeout(async()=>{await Vs(),i()},2e3)})}async function Ns(){const e=await he(),t=[Y,de,ue];return e.forEach(a=>{a.storageKey&&!t.includes(a.storageKey)&&t.push(a.storageKey)}),$t(t)}function ht(e,t="main"){const a=new Date().toISOString();let o=e.projects||[],i=e.items||[];o.length||(o=[{id:"proj_default",name:t,type:"browser",createdAt:a,updatedAt:a}]);const r=o[0].id;i=i.map(p=>p.projectId?p:{...p,projectId:r});const d=30*24*60*60*1e3,u=Date.now();let l=Array.isArray(e.trash)?e.trash:[];return l=l.filter(p=>{const m=p.deletedAt?new Date(p.deletedAt).getTime():0;return m&&u-m<d}),{version:e.version||2,createdAt:e.createdAt||a,updatedAt:a,projects:o,items:i,trash:l}}async function Fs(e,t){try{const a=await Ee(t);return a?(await Ge(a,e),!0):!1}catch{return!1}}function Us(e){let t=`${e.password}
`;return e.username&&(t+=`login: ${e.username}
`),e.url&&(t+=`url: ${e.url}
`),e.category&&(t+=`category: ${e.category}
`),e.notes&&(t+=`notes: ${e.notes}
`),t}function Rs(e,t,a="proj_default"){const o=t.trim().split(`
`),i=o[0]||"",r={id:"item_"+Date.now()+"_"+Math.random().toString(36).substr(2,6),projectId:a,title:e||"Untitled",password:i,username:"",url:"",category:"General",notes:"",updatedAt:new Date().toISOString()};for(let d=1;d<o.length;d++){const u=o[d].trim();if(!u)continue;const l=u.indexOf(":");if(l>0){const p=u.slice(0,l).trim().toLowerCase(),m=u.slice(l+1).trim();p==="login"||p==="username"||p==="user"||p==="email"?r.username=m:p==="url"||p==="website"||p==="link"?r.url=m:p==="category"||p==="folder"?r.category=m:p==="notes"||p==="note"?r.notes=(r.notes?r.notes+`
`:"")+m:r.notes=(r.notes?r.notes+`
`:"")+u}else r.notes=(r.notes?r.notes+`
`:"")+u}return r}function Pe(e){if(e==null)return"";const t=String(e);return t.includes(",")||t.includes('"')||t.includes(`
`)||t.includes("\r")?`"${t.replace(/"/g,'""')}"`:t}function Hs(e=[]){const t="login,pass,name,tag,url,note",a=e.map(o=>{const i=Pe(o.username||""),r=Pe(o.password||""),d=Pe(o.title||""),u=Array.isArray(o.tags)&&o.tags.length>0?o.tags.join(", "):o.category||"",l=Pe(u),p=Pe(o.url||""),m=Pe(o.notes||"");return`${i},${r},${d},${l},${p},${m}`});return[t,...a].join(`
`)}function Gs(e=[]){const t=new Set;e.forEach(r=>{(Array.isArray(r.tags)&&r.tags.length>0?r.tags:r.category?[r.category]:[]).forEach(u=>{u&&u.trim()&&u.trim()!=="Work"&&t.add(u.trim())})});const a=Array.from(t).map((r,d)=>({id:`folder_${d+1}`,name:r})),o=new Map(a.map(r=>[r.name,r.id])),i=e.map((r,d)=>{const u=Array.isArray(r.tags)&&r.tags[0]||r.category||"",l=o.get(u)||null,p=new Date().toISOString();return{type:1,name:r.title||r.url||"Untitled",favorite:!!r.favorite,reprompt:0,id:r.id||`bw_${Date.now()}_${Math.random().toString(36).substr(2,6)}_${d}`,folderId:l,collectionIds:null,fields:[],notes:r.notes||"",login:{uris:r.url?[{uri:r.url}]:[],fido2Credentials:[],username:r.username||"",password:r.password||""},passwordHistory:Array.isArray(r.passwordHistory)?r.passwordHistory.map(m=>({lastUsedDate:m.createdAt||m.lastUsed||p,password:m.password})):[],creationDate:r.createdAt||p,revisionDate:r.updatedAt||p}});return JSON.stringify({encrypted:!1,folders:a,items:i},null,2)}const c={isInitialized:!1,isUnlocked:!1,rawMek:null,keySlots:null,projects:[],activeProjectId:null,items:[],trash:[],categories:["All","Work","Personal"],categoryColors:{Work:"blue",Personal:"green"},activeCategory:"All",searchQuery:"",activeTab:"vault",selectedItem:null,isEditing:!1,lockInterval:"session",autolockMinutes:15,theme:"light",language:"en",showCardTags:!1,showFavicons:!0,useExternalIcons:!1,currentSiteEnabled:!0,hasTabsPermission:!1,hasNativeMessagingPermission:!1,sessionExpiresAt:null,isProjectSwitcherOpen:!1,projectToDelete:null,passHostStatus:null,isShowPassInstructions:!1,lastActivity:Date.now()},Et=new Set;function qs(e){return Et.add(e),()=>Et.delete(e)}function Ue(){c.lastActivity=Date.now(),Et.forEach(e=>e(c))}function P(e){Object.assign(c,e),Ue()}function me(){return c.projects.length?c.projects.find(e=>e.id===c.activeProjectId)||c.projects[0]:null}function ge(){const e=me();return e?c.items.filter(t=>t.projectId===e.id):[]}function Ws(e){const t=c.projects.find(a=>a.id===e);t&&(c.activeProjectId=t.id,c.selectedItem=null,c.isEditing=!1,c.isProjectSwitcherOpen=!1,Ue())}function Js(e,t="browser"){const a="proj_"+Date.now()+"_"+Math.random().toString(36).substr(2,5),o=new Date().toISOString(),i={id:a,name:e.trim()||"New Database",type:t,createdAt:o,updatedAt:o};return c.projects.push(i),c.activeProjectId=a,c.isProjectSwitcherOpen=!1,Ue(),i}function Ks(e,t){const a=c.projects.find(o=>o.id===e);return a?(a.name=t.trim(),a.updatedAt=new Date().toISOString(),Ue(),!0):!1}async function Xs(e,t,a){const o=c.projects.find(r=>r.id===e);if(!o)throw new Error("Project not found.");if(c.projects.length<=1)throw new Error("Cannot delete the only project. At least one database must remain.");if(a.trim()!==o.name.trim())throw new Error(`Entered name "${a}" does not match project name "${o.name}".`);if(!await Fs(t))throw new Error("Invalid master password. Operation cancelled.");return c.projects=c.projects.filter(r=>r.id!==e),c.items=c.items.filter(r=>r.projectId!==e),c.activeProjectId===e&&(c.activeProjectId=c.projects[0].id),c.selectedItem=null,c.isEditing=!1,c.projectToDelete=null,Ue(),!0}async function je(){if(await ve(),c.rawMek&&c.rawMek.fill)try{c.rawMek.fill(0)}catch{}c.isUnlocked=!1,c.rawMek=null,c.keySlots=null,c.projects=[],c.items=[],c.activeProjectId=null,c.selectedItem=null,c.isEditing=!1,c.activeTab="vault",c.isProjectSwitcherOpen=!1,c.projectToDelete=null,Ue()}async function se(e,t=30){try{typeof navigator<"u"&&navigator.clipboard&&navigator.clipboard.writeText&&await navigator.clipboard.writeText(e);const a=Number(t)||0;return a>0&&typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:"SCHEDULE_CLIPBOARD_CLEAR",seconds:a}).catch(()=>{}),!0}catch(a){return console.error("Clipboard copy failed:",a),!1}}const n={activeTabDomain:"",activeTabFavicon:"",activeTabId:null,activeTabUrl:"",isAutofillSupported:!1,cachedFavicons:{},isDrawerOpen:!1,failedAttempts:0,lockoutUntil:0,lockoutTimer:null,isRecoveryViewActive:!1,newlyCreatedRecoveryPhrase:null,cachedVaultProfiles:[],cachedActiveVaultId:null,isCreatingNewVaultFromLock:!1,isProfileSelectorViewActive:!1,genOptions:{length:20,useUpper:!0,useLower:!0,useDigits:!0,useSymbols:!0,avoidAmbiguous:!1},currentGeneratedPassword:"",isPasswordVisible:!1,settingsSearchQuery:"",openSections:new Set,isChangePwdOpen:!1,isCustomSelectOpen:!1,isAutolockSelectOpen:!1,isLangSelectOpen:!1,isExportFormatSelectOpen:!1,selectedExportFormat:"spbackup",isExportAdvancedOpen:!1,exportModalData:null,importBackupData:null,exportSelectedTags:new Set,selectedNewCatColor:"amber",activeColorPickerCat:null,editingTagId:null,formSelectedTags:[],currentFormItemId:null,currentFormItemPassword:"",formDraft:null,securitySearchQuery:"",securityActiveRiskFilter:"all",isSecurityLegendOpen:!1,securityAuditReport:null,isAuditing:!1};function Ae(){return n.lockoutUntil&&Date.now()<n.lockoutUntil?Math.ceil((n.lockoutUntil-Date.now())/1e3):0}function te(){var p,m,h,g,k,y,b;if(!document.getElementById("sp-item-form"))return;const t=((p=document.getElementById("sp-item-id"))==null?void 0:p.value)||"",a=((m=document.getElementById("sp-item-title"))==null?void 0:m.value)||"",o=((h=document.getElementById("sp-item-username"))==null?void 0:h.value)||"",i=((g=document.getElementById("sp-item-password"))==null?void 0:g.value)||n.currentFormItemPassword||"",r=((k=document.getElementById("sp-item-url"))==null?void 0:k.value)||"",d=((y=document.getElementById("sp-item-notes"))==null?void 0:y.value)||"",u=((b=document.getElementById("sp-item-project"))==null?void 0:b.value)||"",l=!t;n.formDraft={id:t,isNew:l,projectId:u,title:a,username:o,password:i,url:r,notes:d,tags:[...n.formSelectedTags]}}function be(){n.formDraft=null,n.formSelectedTags=[],n.currentFormItemId=null,n.currentFormItemPassword="",n.isPasswordVisible=!1}const Qs="ABCDEFGHIJKLMNOPQRSTUVWXYZ",Jt="abcdefghijklmnopqrstuvwxyz",Kt="0123456789",Ys="!@#$%^&*()-_=+[]{}|;:,.<>?",at="O0Il1|";function nt(e){if(e<=1)return 0;const t=Math.floor(4294967296/e)*e,a=new Uint32Array(1);for(;;)if(crypto.getRandomValues(a),a[0]<t)return a[0]%e}function et(e={}){const{length:t=20,useUpper:a=!0,useLower:o=!0,useDigits:i=!0,useSymbols:r=!0,avoidAmbiguous:d=!1}=e;let u=a?Qs:"",l=o?Jt:"",p=i?Kt:"",m=r?Ys:"";d&&(u=u.split("").filter(y=>!at.includes(y)).join(""),l=l.split("").filter(y=>!at.includes(y)).join(""),p=p.split("").filter(y=>!at.includes(y)).join(""),m=m.split("").filter(y=>!at.includes(y)).join(""));const h=[];u&&h.push(u),l&&h.push(l),p&&h.push(p),m&&h.push(m);const g=h.join("")||Jt+Kt,k=[];if(t>=h.length){for(const y of h)k.push(y[nt(y.length)]);for(let y=h.length;y<t;y++)k.push(g[nt(g.length)]);for(let y=k.length-1;y>0;y--){const b=nt(y+1);[k[y],k[b]]=[k[b],k[y]]}}else for(let y=0;y<t;y++)k.push(g[nt(g.length)]);return k.join("")}function ns(e){if(!e)return{score:0,label:"Empty",color:"#6b7280"};let t=0;return e.length>=8&&(t+=20),e.length>=14&&(t+=20),e.length>=20&&(t+=10),/[a-z]/.test(e)&&(t+=10),/[A-Z]/.test(e)&&(t+=10),/[0-9]/.test(e)&&(t+=15),/[^a-zA-Z0-9]/.test(e)&&(t+=15),t=Math.min(100,t),t<40?{score:t,label:"Weak",color:"#ef4444"}:t<70?{score:t,label:"Moderate",color:"#f59e0b"}:t<90?{score:t,label:"Strong",color:"#10b981"}:{score:t,label:"Very Strong",color:"#06b6d4"}}const Zs={name:{en:"SimplePass Manager",ru:"SimplePass Manager",ua:"SimplePass Manager",be:"SimplePass Manager",kk:"SimplePass Manager",zh:"SimplePass 密码管理器",ja:"SimplePass パスワードマネージャー",hi:"SimplePass Manager"}},ea={menu:{en:"Menu",ru:"Меню",ua:"Меню",be:"Меню",kk:"Мәзір",zh:"菜单",ja:"メニュー",hi:"मेनू"},close:{en:"Close",ru:"Закрыть",ua:"Закрити",be:"Закрыць",kk:"Жабу",zh:"关闭",ja:"閉じる",hi:"बंद करें"},passwords:{en:"Passwords",ru:"Пароли",ua:"Паролі",be:"Паролі",kk:"Құпия сөздер",zh:"密码",ja:"パスワード",hi:"पासवर्ड"},generator:{en:"Password Generator",ru:"Генератор пароля",ua:"Генератор паролів",be:"Генератар пароляў",kk:"Құпия сөз генераторы",zh:"密码生成器",ja:"パスワード生成",hi:"पासवर्ड जनरेटर"},settings:{en:"Settings",ru:"Настройки",ua:"Налаштування",be:"Налады",kk:"Баптаулар",zh:"设置",ja:"設定",hi:"सेटिंग्स"},add_password:{en:"Add password",ru:"Добавить пароль",ua:"Додати пароль",be:"Дадаць пароль",kk:"Құпия сөз қосу",zh:"添加密码",ja:"パスワードを追加",hi:"पासवर्ड जोड़ें"},lock_vault:{en:"Lock vault",ru:"Заблокировать",ua:"Заблокувати",be:"Заблакіраваць",kk:"Құлыптау",zh:"锁定保险库",ja:"ロックする",hi:"वॉल्ट लॉक करें"},share_tunnel:{en:"Share password (E2EE tunnel)",ru:"Поделиться паролем (E2EE туннель)",ua:"Поділитися паролем (E2EE тунель)",be:"Падзяліцца паролем (E2EE тунэль)",kk:"Құпия сөзбен бөлісу (E2EE туннелі)",zh:"共享密码 (E2EE 隧道)",ja:"パスワードを共有 (E2EEトンネル)",hi:"पासवर्ड साझा करें (E2EE टनल)"}},ta={items_count:{en:"{count} passwords in vault",ru:"{count} паролей в базе",ua:"{count} паролів у базі",be:"{count} пароляў у базе",kk:"Дерекқорда {count} құпия сөз бар",zh:"保管库中有 {count} 个密码",ja:"保管庫に {count} 件のパスワード",hi:"वॉल्ट में {count} पासवर्ड"},db_project:{en:"Database (Project)",ru:"База данных (Проект)",ua:"База даних (Проєкт)",be:"База даных (Праект)",kk:"Дерекқор (Жоба)",zh:"数据库 (项目)",ja:"データベース (プロジェクト)",hi:"डेटाबेस (प्रोजेक्ट)"}},sa={search_placeholder:{en:"Search passwords...",ru:"Поиск паролей...",ua:"Пошук паролів...",be:"Пошук пароляў...",kk:"Құпия сөздерді іздеу...",zh:"搜索密码...",ja:"パスワードを検索...",hi:"पासवर्ड खोजें..."},empty_title:{en:"No passwords in this database",ru:"Нет паролей в этой базе",ua:"Немає паролів у цій базі",be:"Хранілішча пустое",kk:"Қойма бос",zh:"保管库为空",ja:"保管庫は空です",hi:"वॉल्ट खाली है"},empty_desc:{en:"Click «+» at the top to add a new entry",ru:"Нажмите «+» вверху, чтобы добавить запись",ua:"Натисніть «+» вгорі, щоб додати запис",be:"Дадайце свой першы пароль кнопкай + зверху",kk:"Жоғарғы жақтағы + батырмасымен алғашқы құпия сөзді қосыңыз",zh:"点击右上角 + 按钮添加您的第一个密码",ja:"上部の + ボタンをクリックして最初のパスワードを追加してください",hi:"ऊपर + बटन पर क्लिक करके अपना पहला पासवर्ड जोड़ें"},current_site:{en:"Current site",ru:"Текущий сайт",ua:"Поточний сайт",be:"Бягучы сайт",kk:"Ағымдағы сайт",zh:"当前网站",ja:"現在のサイト",hi:"वर्तमान साइट"},filter_domain_title:{en:"Filter to this site only",ru:"Оставить только этот сайт",ua:"Залишити тільки цей сайт",be:"Фільтраваць па гэтым дамене",kk:"Осы домен бойынша сүзу",zh:"按此域名筛选",ja:"このドメインでフィルター",hi:"इस डोमेन द्वारा फ़िल्टर करें"},site_pill:{en:"site",ru:"сайт",ua:"сайт",be:"Сайт",kk:"Сайт",zh:"网站",ja:"サイト",hi:"साइट"},no_login:{en:"No username",ru:"Нет логина",ua:"Немає логіну",be:"Няма лагіна",kk:"Логин жоқ",zh:"无用户名",ja:"ユーザー名なし",hi:"कोई लॉगिन नहीं"},export_csv_btn:{en:"Export to CSV",ru:"Экспорт в CSV",ua:"Експорт в CSV",be:"Экспарт у CSV",kk:"CSV пішіміне экспорттау",zh:"导出为 CSV",ja:"CSVにエクスポート",hi:"CSV में निर्यात करें"},autofill_action:{en:"Autofill on website",ru:"Заполнить на сайте",ua:"Заповнити на сайті",be:"Аўтазапаўненне",kk:"Автотолтыру",zh:"自动填充",ja:"自動入力",hi:"ऑटोफ़िल"},copy_user:{en:"Copy username",ru:"Копировать логин",ua:"Копіювати логін",be:"Скапіяваць лагін",kk:"Логинді көшіру",zh:"复制用户名",ja:"ユーザー名をコピー",hi:"लॉगिन कॉपी करें"},copy_pwd:{en:"Copy password",ru:"Копировать пароль",ua:"Копіювати пароль",be:"Скапіяваць пароль",kk:"Құпия сөзді көшіру",zh:"复制密码",ja:"パスワードをコピー",hi:"पासवर्ड कॉपी करें"},autofill_unsupported:{en:"Autofill unavailable on this page",ru:"Автозаполнение недоступно на этой странице",ua:"Автозаповнення недоступне на цій сторінці",be:"Аўтазапаўненне недаступнае на гэтай старонцы",kk:"Бұл бетте автотолтыру қолжетімсіз",zh:"此页面不支持自动填充",ja:"このページでは自動入力を利用できません",hi:"इस पृष्ठ पर ऑटोफ़िल उपलब्ध नहीं है"},enable_site_detection_btn:{en:"Enable Active Site Detection",ru:"Включить определение сайта",ua:"Увімкнути визначення сайту",be:"Уключыць вызначэнне сайта",kk:"Сайтты анықтауды қосу",zh:"启用活动网站检测",ja:"サイト検出を有効にする",hi:"सक्रिय साइट पहचान सक्षम करें"},enable_site_detection_desc:{en:"Grant permission to automatically suggest passwords for the open website",ru:"Разрешите доступ к вкладкам для автоподбора паролей к открытому сайту",ua:"Дозвольце доступ до вкладок для автопідбору паролів до відкритого сайту",be:"Дазвольце доступ да ўкладак для аўтаматычнага падбору пароляў",kk:"Ашық сайтқа арналған құпиясөздерді автоматты түрде таңдау үшін қойындыларға рұқсат беріңіз",zh:"授予权限以自动为打开的网站推荐密码",ja:"開いているウェブサイトのパスワードを自動提案するための権限を付与",hi:"खुली वेबसाइट के लिए स्वचालित रूप से पासवर्ड सुझाने की अनुमति दें"}},aa={length_label:{en:"Password length",ru:"Длина пароля",ua:"Довжина пароля",be:"Даўжыня",kk:"Ұзындығы",zh:"长度",ja:"長さ",hi:"लंबाई"},uppercase:{en:"Uppercase letters (A-Z)",ru:"Прописные буквы (A-Z)",ua:"Великі літери (A-Z)",be:"Вялікія (A-Z)",kk:"Бас әріптер (A-Z)",zh:"大写字母 (A-Z)",ja:"大文字 (A-Z)",hi:"बड़े अक्षर (A-Z)"},lowercase:{en:"Lowercase letters (a-z)",ru:"Строчные буквы (a-z)",ua:"Малі літери (a-z)",be:"Малыя (a-z)",kk:"Кіші әріптер (a-z)",zh:"小写字母 (a-z)",ja:"小文字 (a-z)",hi:"छोटे अक्षर (a-z)"},numbers:{en:"Digits (0-9)",ru:"Цифры (0-9)",ua:"Цифри (0-9)",be:"Лічбы (0-9)",kk:"Сандар (0-9)",zh:"数字 (0-9)",ja:"数字 (0-9)",hi:"अंक (0-9)"},symbols:{en:"Special symbols (!@#$%^&*)",ru:"Спецсимволы (!@#$%^&*)",ua:"Спецсимволи (!@#$%^&*)",be:"Спецсімвалы (!@#$)",kk:"Арнайы таңбалар (!@#$)",zh:"特殊符号 (!@#$)",ja:"記号 (!@#$)",hi:"विशेष प्रतीक (!@#$)"},refresh_title:{en:"Generate new",ru:"Сгенерировать новый",ua:"Згенерувати новий",be:"Згенераваць новы",kk:"Жаңасын жасау",zh:"重新生成",ja:"再生成",hi:"नया जनरेट करें"},copy_title:{en:"Copy",ru:"Копировать",ua:"Копіювати",be:"Скапіяваць пароль",kk:"Құпия сөзді көшіру",zh:"复制密码",ja:"パスワードをコピー",hi:"पासवर्ड कॉपी करें"},avoid_ambiguous:{en:"Exclude ambiguous (0, O, 1, l)",ru:"Исключить неоднозначные (0, O, 1, l)",ua:"Виключити неоднозначні (0, O, 1, l)",be:"Выключыць падобныя (0, O, l, 1)",kk:"Ұқсас таңбаларды алып тастау (0, O, l, 1)",zh:"排除易混淆字符 (0, O, l, 1)",ja:"紛らわしい文字を除外 (0, O, l, 1)",hi:"भ्रमित करने वाले वर्ण छोड़ें (0, O, l, 1)"}},na={back:{en:"Back",ru:"Назад",ua:"Назад",be:"Назад",kk:"Артқа",zh:"返回",ja:"戻る",hi:"वापस"},new_title:{en:"New Entry",ru:"Новая запись",ua:"Новий запис",be:"Новы запіс",kk:"Жаңа жазба",zh:"新建密码",ja:"新規パスワード",hi:"नई प्रविष्टि"},edit_title:{en:"Edit Entry",ru:"Редактирование",ua:"Редагування",be:"Рэдагаванне",kk:"Өңдеу",zh:"编辑密码",ja:"パスワード編集",hi:"प्रविष्टि संपादित करें"},delete_btn:{en:"Delete",ru:"Удалить",ua:"Видалити",be:"Выдаліць",kk:"Жою",zh:"删除",ja:"削除",hi:"हटाएं"},csv_title:{en:"Import passwords from CSV",ru:"Импорт паролей из CSV",ua:"Імпорт паролів з CSV",be:"Хуткі імпарт з CSV",kk:"CSV файлынан жылдам импорттау",zh:"从 CSV 快速导入",ja:"CSVからクイックインポート",hi:"CSV से त्वरित आयात"},csv_sub:{en:"Chrome, Bitwarden, 1Password...",ru:"Chrome, Bitwarden, 1Password...",ua:"Chrome, Bitwarden, 1Password...",be:"Загрузіце табліцу пароляў у актыўную базу",kk:"Белсенді дерекқорға құпия сөздер кестесін жүктеңіз",zh:"将密码表格导入当前数据库",ja:"パスワード表を現在のDBに読み込みます",hi:"सक्रिय डेटाबेस में पासवर्ड तालिका अपलोड करें"},csv_choose_file:{en:"Choose file",ru:"Выбрать файл",ua:"Вибрати файл",be:"Выбраць CSV",kk:"CSV таңдау",zh:"选择 CSV",ja:"CSVを選択",hi:"CSV चुनें"},title_label:{en:"Title",ru:"Название",ua:"Назва",be:"Назва",kk:"Атауы",zh:"名称",ja:"タイトル",hi:"शीर्षक"},title_placeholder:{en:"e.g. GitHub or Google",ru:"Напр. GitHub или Google",ua:"Напр. GitHub або Google",be:"напрыклад Google, GitHub",kk:"мысалы Google, GitHub",zh:"例如 Google, GitHub",ja:"例: Google, GitHub",hi:"जैसे Google, GitHub"},login_label:{en:"Username / Email",ru:"Логин / Email",ua:"Логін / Email",be:"Лагін або Email",kk:"Логин немесе Email",zh:"用户名或邮箱",ja:"ユーザー名またはメール",hi:"लॉगिन या ईमेल"},login_placeholder:{en:"username@example.com",ru:"username@example.com",ua:"username@example.com",be:"user@example.com",kk:"user@example.com",zh:"user@example.com",ja:"user@example.com",hi:"user@example.com"},password_label:{en:"Password",ru:"Пароль",ua:"Пароль",be:"Пароль",kk:"Құпия сөз",zh:"密码",ja:"パスワード",hi:"पासवर्ड"},password_placeholder:{en:"Secret password",ru:"Секретный пароль",ua:"Секретний пароль",be:"Пароль",kk:"Құпия сөз",zh:"密码",ja:"パスワード",hi:"पासवर्ड"},generate_btn:{en:"Generate",ru:"Сгенерировать",ua:"Згенерувати",be:"Згенераваць",kk:"Жасау",zh:"生成",ja:"生成",hi:"जनरेट करें"},url_label:{en:"Website URL",ru:"URL сайта",ua:"URL сайту",be:"URL адрас",kk:"URL мекенжайы",zh:"网址 URL",ja:"URLアドレス",hi:"वेबसाइट URL"},url_placeholder:{en:"https://example.com/login",ru:"https://example.com/login",ua:"https://example.com/login",be:"https://example.com",kk:"https://example.com",zh:"https://example.com",ja:"https://example.com",hi:"https://example.com"},refresh_favicon_title:{en:"Refresh favicon from website",ru:"Обновить фавикон с сайта",ua:"Оновити фавікон із сайту",be:"Абнавіць фавікон з сайта",kk:"Сайттан фавиконды жаңарту",zh:"从网站刷新图标",ja:"サイトからファビコンを更新",hi:"वेबसाइट से फ़ेविकॉन ताज़ा करें"},category_label:{en:"Tags",ru:"Метки",ua:"Мітки",be:"Меткі",kk:"Белгілер",zh:"标签",ja:"タグ",hi:"टैग"},tags_placeholder:{en:"Search or add tag...",ru:"Поиск или новая метка...",ua:"Пошук або нова мітка...",be:"Пошук або новая метка...",kk:"Іздеу немесе жаңа белгі...",zh:"搜索或新建标签...",ja:"検索または新規タグ...",hi:"खोजें या नया टैग जोड़ें..."},tags_create_option:{en:"+ Create tag «{name}»",ru:"+ Создать метку «{name}»",ua:"+ Створити мітку «{name}»",be:"Стварыць метку «{name}»",kk:"«{name}» белгісін жасау",zh:"创建标签 “{name}”",ja:"タグ「{name}」を作成",hi:"टैग बनाएं «{name}»"},tags_create_new_action:{en:"+ Create new tag",ru:"+ Создать новую метку",ua:"+ Створити нову мітку",be:"+ Стварыць новую пазнаку",kk:"+ Жаңа белгі жасау",zh:"+ 创建新标签",ja:"+ 新しいタグを作成",hi:"+ नया टैग बनाएं"},tags_prompt_new:{en:"Enter new tag name:",ru:"Введите название новой метки:",ua:"Введіть назву нової мітки:",be:"Увядзіце назву новай пазнакі:",kk:"Жаңа белгі атауын енгізіңіз:",zh:"输入新标签名称：",ja:"新しいタグ名を入力してください:",hi:"नया टैग नाम दर्ज करें:"},title_required:{en:"Title is required",ru:"Укажите название записи",ua:"Вкажіть назву запису",be:"Пакажыце назву запісу",kk:"Жазба атауын енгізіңіз",zh:"请输入条目标题",ja:"タイトルを入力してください",hi:"कृपया शीर्षक दर्ज करें"},password_required:{en:"Password is required",ru:"Укажите или сгенерируйте пароль",ua:"Вкажіть або згенеруйте пароль",be:"Пакажыце альбо згенеруйце пароль",kk:"Құпия сөзді енгізіңіз немесе жасаңыз",zh:"请输入或生成密码",ja:"パスワードを入力または生成してください",hi:"कृपया पासवर्ड दर्ज करें या जनरेट करें"},tags_no_tags:{en:"No tags assigned",ru:"Нет меток",ua:"Немає міток",be:"Няма меток",kk:"Белгілер жоқ",zh:"暂无标签",ja:"タグなし",hi:"कोई टैग नहीं"},notes_label:{en:"Notes",ru:"Заметки",ua:"Нотатки",be:"Нататкі",kk:"Жазбалар",zh:"备注",ja:"メモ",hi:"नोट्स"},notes_placeholder:{en:"Additional info (PIN, backup codes...)",ru:"Дополнительная информация (PIN, резервные коды...)",ua:"Додаткова інформація (PIN, резервні коди...)",be:"Дадатковая інфармацыя, 2FA сакрэт і г.д.",kk:"Қосымша ақпарат, 2FA құпиясы т.б.",zh:"额外信息、2FA 备用码等",ja:"追加情報、2FAシークレットなど",hi:"अतिरिक्त विवरण, 2FA गुप्त कुंजी आदि"},save_btn:{en:"Save",ru:"Сохранить",ua:"Зберегти",be:"Захаваць",kk:"Сақтау",zh:"保存",ja:"保存",hi:"सहेजें"},cancel_btn:{en:"Cancel",ru:"Отмена",ua:"Скасувати",be:"Адмена",kk:"Болдырмау",zh:"取消",ja:"キャンセル",hi:"रद्द करें"},required_field:{en:"Required field",ru:"Обязательное поле",ua:"Обов'язкове поле",be:"Абавязковае поле",kk:"Міндетті өріс",zh:"必填项",ja:"必須項目",hi:"आवश्यक फ़ील्ड"},password_history:{en:"Password history",ru:"История паролей",ua:"Історія паролів",be:"Гісторыя пароляў",kk:"Құпия сөздер тарихы",zh:"历史密码",ja:"パスワード履歴",hi:"पासवर्ड इतिहास"},restore_pwd_btn:{en:"Use",ru:"Применить",ua:"Застосувати",be:"Ужыць",kk:"Қолдану",zh:"使用",ja:"適用",hi:"उपयोग करें"},pwd_history_copied:{en:"Previous password copied",ru:"Предыдущий пароль скопирован",ua:"Попередній пароль скопійовано",be:"Папярэдні пароль скапіяваны",kk:"Алдыңғы құпия сөз көшірілді",zh:"历史密码已复制",ja:"以前のパスワードをコピーしました",hi:"पिछला पासवर्ड कॉपी किया गया"},pwd_history_restored:{en:"Previous password restored to field",ru:"Предыдущий пароль подставлен в поле",ua:"Попередній пароль підставлено в поле",be:"Папярэдні пароль устаўлены ў поле",kk:"Алдыңғы құпия сөз өріске қойылды",zh:"已恢复历史密码到输入框",ja:"以前のパスワードを入力欄に復元しました",hi:"पिछला पासवर्ड फ़ील्ड में पुनर्स्थापित किया गया"}},oa={title:{en:"Settings",ru:"Настройки",ua:"Налаштування",be:"Налады",kk:"Баптаулар",zh:"设置",ja:"設定",hi:"सेटिंग्स"},search_placeholder:{en:"Search settings...",ru:"Поиск по настройкам...",ua:"Пошук за налаштуваннями...",be:"Пошук па наладах...",kk:"Баптаулардан іздеу...",zh:"搜索设置...",ja:"設定を検索...",hi:"सेटिंग्स खोजें..."},back_to_settings:{en:"Settings",ru:"Настройки",ua:"Налаштування",be:"Назад да налад",kk:"Баптауларға қайту",zh:"返回设置",ja:"設定に戻る",hi:"सेटिंग्स पर वापस जाएं"},appearance_section:{en:"Appearance & Theme",ru:"Оформление и тема",ua:"Зовнішній вигляд та тема",be:"Знешні выгляд",kk:"Сыртқы түрі",zh:"外观与界面",ja:"外観",hi:"रूप-रंग"},appearance_desc_short:{en:"Theme and interface language",ru:"Тема оформления и язык интерфейса",ua:"Тема оформлення та мова інтерфейсу",be:"Тэма і мова інтэрфейсу",kk:"Тақырып және интерфейс тілі",zh:"主题与界面语言",ja:"テーマとインターフェース言語",hi:"थीम और इंटरफ़ेस भाषा"},language_label:{en:"Interface Language",ru:"Язык интерфейса",ua:"Мова інтерфейсу",be:"Мова інтэрфейсу",kk:"Интерфейс тілі",zh:"界面语言",ja:"表示言語",hi:"इंटरफ़ेस भाषा"},language_desc:{en:"Select application language (EN / RU / UA).",ru:"Выберите язык приложения (EN / RU / UA).",ua:"Оберіть мову додатку (EN / RU / UA).",be:"Выберыце зручную мову для працы з SimplePass",kk:"SimplePass қолдану үшін қолайлы тілді таңдаңыз",zh:"选择 SimplePass 的界面显示语言",ja:"SimplePassで使用する言語を選択してください",hi:"SimplePass के लिए अपनी पसंदीदा भाषा चुनें"},theme_label:{en:"Dark Theme",ru:"Тёмная тема",ua:"Темна тема",be:"Цёмная тэма",kk:"Күңгірт тақырып",zh:"暗色模式",ja:"ダークテーマ",hi:"डार्क थीम"},theme_dark_desc:{en:"Active theme: Darkest Hour (#1F1F21)",ru:"Активна тема: Darkest Hour (#1F1F21)",ua:"Активна тема: Darkest Hour (#1F1F21)",be:"Актыўная тэма: Darkest Hour (#1F1F21)",kk:"Белсенді тақырып: Darkest Hour (#1F1F21)",zh:"当前主题: 深色 (#1F1F21)",ja:"現在のテーマ: ダーク (#1F1F21)",hi:"सक्रिय थीम: डार्क (#1F1F21)"},theme_light_desc:{en:"Active theme: Light (#F8FAFC)",ru:"Активна тема: Светлая (#F8FAFC)",ua:"Активна тема: Світла (#F8FAFC)",be:"Актыўная тэма: Светлая (#F8FAFC)",kk:"Белсенді тақырып: Жарық (#F8FAFC)",zh:"当前主题: 浅色 (#F8FAFC)",ja:"現在のテーマ: ライト (#F8FAFC)",hi:"सक्रिय थीम: लाइट (#F8FAFC)"},show_card_tags_label:{en:"Show tags on cards",ru:"Метки на карточках",ua:"Мітки на картках",be:"Пазнакі на картках",kk:"Карточкалардағы белгілер",zh:"在卡片上显示标签",ja:"カードのタグ表示",hi:"कार्डों पर टैग दिखाएं"},show_card_tags_desc:{en:"Show category and tag badges directly on vault password cards",ru:"Показывать цветные бейджи меток прямо на карточках в общем списке",ua:"Показувати кольорові бейджі міток прямо на картках у загальному списку",be:"Паказваць каляровыя бэйджы пазнак прама на картках у агульным спісе",kk:"Құпия сөздер карточкаларында белгілерді бірден көрсету",zh:"在密码卡片列表中直接显示彩色标签徽章",ja:"保管庫のパスワードカード上にカラータグバッジを表示します",hi:"पासवर्ड कार्ड पर सीधे श्रेणी और टैग बैज प्रदर्शित करें"},show_favicons_label:{en:"Website icons on cards",ru:"Иконки сайтов на карточках",ua:"Іконки сайтів на картках",be:"Іконкі сайтаў на картках",kk:"Карточкалардағы сайт белгішелері",zh:"在卡片上显示网站图标",ja:"カードのWebサイトアイコン表示",hi:"कार्डों पर वेबसाइट आइकन दिखाएं"},show_favicons_desc:{en:"Display website favicons and fetch them for saved links",ru:"Отображать фавиконы сайтов на карточках и автоматически подтягивать их по URL",ua:"Відображати фавікони сайтів на картках та автоматично підтягувати їх за URL",be:"Адлюстроўваць фавіконы сайтаў на картках і аўтаматычна падцягваць іх па URL",kk:"Карточкаларда сайттардың белгішелерін көрсету және URL бойынша жүктеу",zh:"在卡片上显示网站图标并自动通过网址获取",ja:"カード上にWebサイトのファビコンを表示し、URLから自動取得します",hi:"कार्डों पर वेबसाइट फ़ेविकॉन प्रदर्शित करें और सहेजे गए URL से प्राप्त करें"},external_icons_label:{en:"External icon services",ru:"Внешние сервисы иконок",ua:"Зовнішні сервіси іконок",be:"Вонкавыя сэрвісы іконак",kk:"Сыртқы белгіше қызметтері",zh:"外部图标服务",ja:"外部アイコンサービス",hi:"बाहरी आइकन सेवाएं"},external_icons_desc:{en:"Fetch missing icons via Google and DuckDuckGo (may leak visited domains)",ru:"Загружать отсутствующие иконки сайтов через Google и DuckDuckGo (может раскрыть домены)",ua:"Завантажувати відсутні іконки через Google та DuckDuckGo (може розкрити домени)",be:"Загружаць адсутныя іконкі праз Google і DuckDuckGo (можа раскрыць дамены)",kk:"Жетіспейтін белгішелерді Google және DuckDuckGo арқылы жүктеп алу (домендерді ашуы мүмкін)",zh:"通过 Google 和 DuckDuckGo 获取缺失的网站图标（可能会泄露访问的域名）",ja:"Google および DuckDuckGo 経由で見つからないファビコンを取得 (ドメインが漏洩する可能性があります)",hi:"Google और DuckDuckGo के माध्यम से छूटे हुए आइकन लाएं (डोमेन लीक हो सकते हैं)"},security_section:{en:"Security & Session",ru:"Безопасность и сессия",ua:"Безпека та сесія",be:"Бяспека і сесія",kk:"Қауіпсіздік және сессия",zh:"安全与会话",ja:"セキュリティとセッション",hi:"सुरक्षा और सत्र"},security_desc_short:{en:"Master password, lock timeout and session",ru:"Мастер-пароль, блокировка и сессия",ua:"Майстер-пароль, блокування та сесія",be:"Майстар-пароль, блакіроўка і сесія",kk:"Мастер-құпия сөз, құлыптау және сессия",zh:"主密码、自动锁定与超时",ja:"マスターパスワード、ロック時間",hi:"मास्टर पासवर्ड, लॉक टाइमआउट और सत्र"},master_pwd_check:{en:"Master Password Check",ru:"Проверка мастер-пароля",ua:"Перевірка майстер-пароля",be:"Перыядычнасць праверкі майстар-пароля",kk:"Мастер-құпия сөзді сұрау жиілігі",zh:"主密码验证频率",ja:"マスターパスワード確認頻度",hi:"मास्टर पासवर्ड सत्यापन आवृत्ति"},master_pwd_check_desc:{en:"Frequency of requesting the master password.",ru:"Периодичность, с которой расширение запрашивает мастер-пароль.",ua:"Періодичність, з якою розширення запитує майстер-пароль.",be:"Праз гэты час спатрэбіцца зноў увесці майстар-пароль",kk:"Осы уақыттан кейін мастер-құпия сөзді қайта енгізу қажет",zh:"在此超时后需要重新输入主密码",ja:"この時間が経過するとマスターパスワードの再入力が必要になります",hi:"इस समय सीमा के बाद मास्टर पासवर्ड पुनः दर्ज करना होगा"},interval_15m:{en:"15 minutes",ru:"15 минут",ua:"15 хвилин",be:"15 хвілін",kk:"15 минут",zh:"15 分钟",ja:"15分",hi:"15 मिनट"},interval_1h:{en:"1 hour",ru:"1 час",ua:"1 година",be:"1 гадзіна",kk:"1 сағат",zh:"1 小时",ja:"1時間",hi:"1 घंटा"},interval_8h:{en:"8 hours (workday)",ru:"8 часов (рабочий день)",ua:"8 годин (робочий день)",be:"8 гадзін (рабочы дзень)",kk:"8 сағат (жұмыс күні)",zh:"8 小时 (工作日)",ja:"8時間 (勤務日)",hi:"8 घंटे (कार्यदिवस)"},interval_session:{en:"Every new browser session",ru:"Каждый раз при новой сессии браузера",ua:"Щоразу під час нової сесії браузера",be:"Да закрыцця браўзера (бягучая сесія)",kk:"Браузер жабылғанша (ағымдағы сессия)",zh:"直到浏览器关闭 (单次会话)",ja:"ブラウザを閉じるまで (現在のセッション)",hi:"ब्राउज़र बंद होने तक (सत्र)"},interval_1day:{en:"Once a day (24 hours)",ru:"Раз в день (24 часа)",ua:"Раз на день (24 години)",be:"1 дзень",kk:"1 күн",zh:"1 天",ja:"1日",hi:"1 दिन"},interval_1day_warning:{en:"Vault key will be kept on this device until timeout",ru:"Ключ хранилища будет сохранён на устройстве до истечения интервала",ua:"Ключ сховища буде збережено на пристрої до закінчення інтервалу",be:"Ключ сховішча будзе захаваны на прыладзе да заканчэння інтэрвалу",kk:"Қойма кілті уақыт біткенше құрылғыда сақталады",zh:"会话密钥将保存在设备上直到超时",ja:"タイムアウトまでキーは端末に保持されます",hi:"समय सीमा तक कुंजी डिवाइस पर संग्रहीत रहेगी"},autolock_title:{en:"Inactivity autolock",ru:"Автоблокировка по бездействию",ua:"Автоблокування за бездіяльністю",be:"Аўтаблакіроўка пры бяздзейнасці",kk:"Әрекетсіздік кезінде автоқұлыптау",zh:"无操作自动锁定",ja:"無操作時の自動ロック",hi:"निष्क्रियता पर ऑटो-लॉक"},autolock_desc:{en:"Lock the vault automatically after a period of inactivity",ru:"Автоматически блокировать хранилище при отсутствии действий пользователя",ua:"Автоматично блокувати сховище за відсутності дій користувача",be:"Аўтаматычна блакіраваць сховішча пры адсутнасці дзеянняў",kk:"Әрекет болмаған кезде қойманы автоматты түрде құлыптау",zh:"在设定的无操作时间后自动锁定密码库",ja:"一定時間操作がない場合に保管庫を自動的にロックします",hi:"निष्क्रियता की अवधि के बाद वॉल्ट को स्वचालित रूप से लॉक करें"},autolock_off:{en:"Disabled",ru:"Отключено",ua:"Вимкнено",be:"Адключана",kk:"Өшірілген",zh:"已禁用",ja:"無効",hi:"अक्षम"},autolock_1m:{en:"1 minute",ru:"1 минута",ua:"1 хвилина",be:"1 хвіліна",kk:"1 минут",zh:"1 分钟",ja:"1分",hi:"1 मिनट"},autolock_5m:{en:"5 minutes",ru:"5 минут",ua:"5 хвилин",be:"5 хвілін",kk:"5 минут",zh:"5 分钟",ja:"5分",hi:"5 मिनट"},autolock_15m:{en:"15 minutes (default)",ru:"15 минут (по умолчанию)",ua:"15 хвилин (за замовчуванням)",be:"15 хвілін (па змаўчанні)",kk:"15 минут (әдепкі)",zh:"15 分钟 (默认)",ja:"15分 (デフォルト)",hi:"15 मिनट (डिफ़ॉल्ट)"},autolock_30m:{en:"30 minutes",ru:"30 минут",ua:"30 хвилин",be:"30 хвілін",kk:"30 минут",zh:"30 分钟",ja:"30分",hi:"30 मिनट"},interval_3days:{en:"Every three days (default, 72 hours)",ru:"Раз в три дня (по умолчанию, 72 часа)",ua:"Раз на три дні (за замовчуванням, 72 години)",be:"3 дні (па змаўчанні)",kk:"3 күн (әдепкі)",zh:"3 天 (推荐)",ja:"3日間 (デフォルト)",hi:"3 दिन (अनुशंसित)"},interval_1week:{en:"Once a week (7 days)",ru:"Раз в неделю (7 дней)",ua:"Раз на тиждень (7 днів)",be:"1 тыдзень",kk:"1 апта",zh:"1 周",ja:"1週間",hi:"1 सप्ताह"},interval_1month:{en:"Once a month (30 days)",ru:"Раз в месяц (30 дней)",ua:"Раз на місяць (30 днів)",be:"1 месяц",kk:"1 ай",zh:"1 个月",ja:"1か月",hi:"1 महीना"},session_status_label:{en:"Current Session Status",ru:"Статус текущей сессии",ua:"Статус поточної сесії",be:"Статус бягучай сесіі",kk:"Ағымдағы сессия күйі",zh:"当前会话状态",ja:"現在のセッション状態",hi:"वर्तमान सत्र स्थिति"},session_status_desc:{en:"While session is active, secrets are accessible without re-entering password.",ru:"Пока сессия активна, секреты доступны без повторного ввода пароля.",ua:"Поки сесія активна, секрети доступні без повторного введення пароля.",be:"Час, які застаўся да аўтаматычнай блакіроўкі хранілішча",kk:"Қойма автоматты түрде құлыпталғанға дейін қалған уақыт",zh:"距离保险库自动锁定剩余的时间",ja:"保管庫が自動ロックされるまでの残り時間",hi:"वॉल्ट के स्वतः लॉक होने तक शेष समय"},session_active:{en:"Active",ru:"Активна",ua:"Активна",be:"Актыўна (бясконца)",kk:"Белсенді (шектеусіз)",zh:"已激活 (持续有效)",ja:"有効 (無期限)",hi:"सक्रिय (निरंतर)"},session_active_browser:{en:"Active (until browser closes)",ru:"Активна (до закрытия браузера)",ua:"Активна (до закриття браузера)",be:"Актыўна (да закрыцця браўзера)",kk:"Белсенді (браузер жабылғанша)",zh:"已激活 (直到浏览器关闭)",ja:"有効 (ブラウザ終了まで)",hi:"सक्रिय (ब्राउज़र बंद होने तक)"},session_active_days:{en:"Active (~{days} d.)",ru:"Активна (~{days} дн.)",ua:"Активна (~{days} дн.)",be:"Актыўна (засталося {days} дн.)",kk:"Белсенді ({days} күн қалды)",zh:"已激活 (剩余 {days} 天)",ja:"有効 (残り {days} 日)",hi:"सक्रिय ({days} दिन शेष)"},session_active_hours:{en:"Active (~{hours} h.)",ru:"Активна (~{hours} ч.)",ua:"Активна (~{hours} год.)",be:"Актыўна (засталося менш за 24 гадз.)",kk:"Белсенді (24 сағаттан аз қалды)",zh:"已激活 (剩余少于 24 小时)",ja:"有効 (残り24時間未満)",hi:"सक्रिय (24 घंटे से कम शेष)"},session_expired:{en:"Expired",ru:"Истекла",ua:"Закінчилася",be:"Сесія скончылася",kk:"Сессия мерзімі аяқталды",zh:"会话已过期",ja:"セッションの有効期限切れ",hi:"सत्र समाप्त"},master_pwd_label:{en:"Master Password",ru:"Мастер-пароль",ua:"Майстер-пароль",be:"Змяніць майстар-пароль",kk:"Мастер-құпия сөзді өзгерту",zh:"更改主密码",ja:"マスターパスワードを変更",hi:"मास्टर पासवर्ड बदलें"},master_pwd_desc:{en:"Change master password and re-encrypt all databases.",ru:"Смена главного пароля с перешифрованием всех баз данных.",ua:"Зміна головного пароля з перешифруванням усіх баз даних.",be:"Перашыфраванне ўсіх захаваных пароляў новым ключом",kk:"Барлық сақталған құпия сөздерді жаңа кілтпен қайта шифрлеу",zh:"使用新主密钥重新加密所有保存的数据",ja:"新しいキーですべてのパスワードを再暗号化します",hi:"नए मास्टर कुंजी के साथ सभी सहेजे गए डेटा को पुनः एन्क्रिप्ट करें"},change_pwd_btn:{en:"Change",ru:"Сменить",ua:"Змінити",be:"Змяніць пароль",kk:"Құпия сөзді өзгерту",zh:"修改密码",ja:"パスワードを変更",hi:"पासवर्ड बदलें"},current_pwd_placeholder:{en:"Current master password",ru:"Текущий мастер-пароль",ua:"Поточний майстер-пароль",be:"Бягучы майстар-пароль",kk:"Ағымдағы мастер-құпия сөз",zh:"当前主密码",ja:"現在のマスターパスワード",hi:"वर्तमान मास्टर पासवर्ड"},new_pwd_placeholder:{en:"New password (>8 chars + special char)",ru:"Новый пароль (более 8 симв. + спецсимвол)",ua:"Новий пароль (>8 симв. + спецсимвол)",be:"Новы майстар-пароль (мін. 8 сімвалаў)",kk:"Жаңа мастер-құпия сөз (кемінде 8 таңба)",zh:"新主密码 (至少 8 位包含特殊符号)",ja:"新しいマスターパスワード (8文字以上)",hi:"नया मास्टर पासवर्ड (कम से कम 8 वर्ण)"},repeat_new_pwd_placeholder:{en:"Repeat new password",ru:"Повторите новый пароль",ua:"Повторіть новий пароль",be:"Паўтарыце новы майстар-пароль",kk:"Жаңа мастер-құпия сөзді қайталаңыз",zh:"重复新主密码",ja:"新しいマスターパスワード (確認)",hi:"नए मास्टर पासवर्ड की पुष्टि करें"},save_new_pwd_btn:{en:"Save new password",ru:"Сохранить новый пароль",ua:"Зберегти новий пароль",be:"Захаваць новы пароль",kk:"Жаңа құпия сөзді сақтау",zh:"保存新密码",ja:"新しいパスワードを保存",hi:"नया पासवर्ड सहेजें"},lock_vault_label:{en:"Vault Lock",ru:"Блокировка хранилища",ua:"Блокування сховища",be:"Заблакіраваць сховішча цяпер",kk:"Қойманы қазір құлыптау",zh:"立即锁定保管库",ja:"今すぐ保管庫をロック",hi:"वॉल्ट अभी लॉक करें"},lock_now_btn:{en:"Lock now",ru:"Заблокировать сейчас",ua:"Заблокувати зараз",be:"Заблакіраваць",kk:"Құлыптау",zh:"锁定",ja:"ロック",hi:"लॉक करें"},lock_vault_desc:{en:"Instantly clear active session and return to lock screen.",ru:"Мгновенный сброс активной сессии и возврат к экрану ввода пароля.",ua:"Миттєве скидання активної сесії та повернення до екрану входу.",be:"Імгненна ачышчае ключ шыфравання з аператыўнай памяці",kk:"Шифрлеу кілтін жедел жадтан бірден тазалайды",zh:"立即从内存中清除加密密钥",ja:"メモリから暗号化キーを即座に破棄します",hi:"मेमोरी से एन्क्रिप्शन कुंजी को तुरंत हटा देता है"},db_section:{en:"Databases & Storage",ru:"Базы данных и хранилище",ua:"Бази даних та сховище",be:"Базы даных і праекты",kk:"Дерекқорлар және жобалар",zh:"数据库与项目",ja:"データベースとプロジェクト",hi:"डेटाबेस और प्रोजेक्ट"},db_desc_short:{en:"Projects, pass CLI and local storage",ru:"Проекты, pass CLI и локальное хранилище",ua:"Проєкти, pass CLI та локальне сховище",be:"Праекты, сховішчы і інтэграцыя з UNIX PASS",kk:"Жобалар, қоймалар және UNIX PASS интеграциясы",zh:"项目、保管库与 UNIX PASS 集成",ja:"プロジェクトとUNIX PASS統合",hi:"प्रोजेक्ट, वॉल्ट और UNIX pass एकीकरण"},current_db_label:{en:"Current Database (Project)",ru:"Текущая база (Проект)",ua:"Поточна база (Проєкт)",be:"Бягучая актыўная база",kk:"Ағымдағы белсенді дерекқор",zh:"当前活动数据库",ja:"現在のアクティブDB",hi:"वर्तमान सक्रिय डेटाबेस"},badge_pass_cli:{en:"PASS CLI",ru:"PASS CLI",ua:"PASS CLI",be:"UNIX PASS",kk:"UNIX PASS",zh:"UNIX PASS",ja:"UNIX PASS",hi:"UNIX PASS"},badge_browser:{en:"Browser",ru:"Браузер",ua:"Браузер",be:"Лакальная",kk:"Жергілікті",zh:"本地存储",ja:"ローカル",hi:"स्थानीय"},db_stats_desc:{en:"Total databases: {projects}. Passwords in current: {items}.",ru:"Всего создано баз: {projects} шт. Паролей в текущей: {items} шт.",ua:"Всього створено баз: {projects} шт. Паролів у поточній: {items} шт.",be:"Тып: {type} • Запісаў: {count} • Створана: {date}",kk:"Түрі: {type} • Жазбалар: {count} • Жасалған: {date}",zh:"类型: {type} • 记录数: {count} • 创建于: {date}",ja:"タイプ: {type} • 件数: {count} • 作成日: {date}",hi:"प्रकार: {type} • प्रविष्टियां: {count} • बनाया गया: {date}"},manage_dbs_btn:{en:"Manage databases in footer",ru:"Управление базами в футере",ua:"Керування базами у футері",be:"Кіраванне базамі (Праектамі)",kk:"Дерекқорларды басқару (Жобалар)",zh:"管理数据库 (项目)",ja:"データベースの管理",hi:"डेटाबेस प्रबंधित करें (प्रोजेक्ट)"},pass_cli_label:{en:"UNIX PASS CLI Integration",ru:"Интеграция с UNIX PASS CLI",ua:"Інтеграція з UNIX PASS CLI",be:"UNIX pass CLI інтэграцыя",kk:"UNIX pass CLI интеграциясы",zh:"UNIX pass CLI 集成",ja:"UNIX pass CLI 連携",hi:"UNIX pass CLI एकीकरण"},pass_connected:{en:"✓ Connected (v{version})",ru:"✓ Подключен (v{version})",ua:"✓ Підключено (v{version})",be:"Падключана",kk:"Қосылған",zh:"已连接",ja:"接続済み",hi:"कनेक्टेड"},pass_not_connected:{en:"⚠ Native Host not detected",ru:"⚠ Native Host не обнаружен",ua:"⚠ Native Host не знайдено",be:"Не падключана",kk:"Қосылмаған",zh:"未连接",ja:"未接続",hi:"कनेक्ट नहीं है"},pass_desc:{en:"Password storage in local filesystem (~/.password-store) shared across browsers and CLI.",ru:"Хранение паролей в локальной файловой системе (~/.password-store) с общим доступом из разных браузеров и консоли.",ua:"Зберігання паролів у локальній файловій системі (~/.password-store) зі спільним доступом з різних браузерів і консолі.",be:"Прамая двухбаковая сінхранізацыя з лакальным сховішчам ~/.password-store праз GPG",kk:"GPG арқылы ~/.password-store жергілікті қоймасымен тікелей екі жақты синхрондау",zh:"通过 GPG 与本地 ~/.password-store 直接进行双向同步",ja:"GPG経由でローカルの ~/.password-store と直接双方向同期",hi:"GPG के माध्यम से स्थानीय ~/.password-store के साथ सीधा द्वि-दिशात्मक समन्वयन"},store_path_label:{en:"Storage directory:",ru:"Каталог хранилища:",ua:"Каталог сховища:",be:"Шлях да сховішча",kk:"Қойма жолы",zh:"存储路径",ja:"保管先パス",hi:"स्टोर पथ"},pass_tool_label:{en:"pass utility:",ru:"Утилита pass:",ua:"Утиліта pass:",be:"Утыліта pass",kk:"pass құралы",zh:"pass 工具",ja:"passツール",hi:"pass उपकरण"},gpg_tool_label:{en:"GPG utility:",ru:"Утилита GPG:",ua:"Утиліта GPG:",be:"Утыліта gpg",kk:"gpg құралы",zh:"gpg 工具",ja:"gpgツール",hi:"gpg उपकरण"},tool_installed:{en:"✓ Installed",ru:"✓ Установлена",ua:"✓ Встановлена",be:"ўстаноўлена",kk:"орнатылған",zh:"已安装",ja:"インストール済み",hi:"स्थापित है"},tool_not_found:{en:"✗ Not found",ru:"✗ Не найдена",ua:"✗ Не знайдена",be:"не знойдзена",kk:"табылмады",zh:"未找到",ja:"見つかりません",hi:"नहीं मिला"},pass_entries_label:{en:"PASS entries:",ru:"Записей в PASS:",ua:"Записів у PASS:",be:"Запісаў у pass",kk:"pass ішіндегі жазбалар",zh:"pass 记录数",ja:"pass内の項目数",hi:"pass में प्रविष्टियां"},check_status_btn:{en:"Check status",ru:"Проверить статус",ua:"Перевірити статус",be:"Праверыць статус",kk:"Күйді тексеру",zh:"检查状态",ja:"ステータス確認",hi:"स्थिति जांचें"},connect_pass_btn:{en:"Connect pass CLI",ru:"Подключить pass CLI",ua:"Підключити pass CLI",be:"Падключыць pass CLI",kk:"pass CLI қосу",zh:"连接 pass CLI",ja:"pass CLI を接続",hi:"pass CLI कनेक्ट करें"},instructions_btn:{en:"Instructions",ru:"Инструкция",ua:"Інструкція",be:"Інструкцыя па наладзе",kk:"Орнату нұсқаулығы",zh:"配置说明",ja:"設定手順",hi:"सेटअप निर्देश"},sync_pass_btn:{en:"Sync active database with ~/.password-store",ru:"Синхронизировать активную базу с ~/.password-store",ua:"Синхронізувати активну базу з ~/.password-store",be:"Сінхранізаваць з PASS",kk:"PASS-пен синхрондау",zh:"与 PASS 同步",ja:"PASSと同期",hi:"PASS से सिंक करें"},categories_section:{en:"Tags",ru:"Метки",ua:"Мітки",be:"Меткі",kk:"Белгілер",zh:"标签管理",ja:"タグ管理",hi:"टैग"},categories_desc_short:{en:"Manage tags and color tones",ru:"Управление метками и цветами",ua:"Керування мітками та кольорами",be:"Спіс меток і колеравыя адценні",kk:"Белгілер тізімі және түстері",zh:"标签列表与颜色设置",ja:"タグ一覧とカラー設定",hi:"टैग सूची और रंग संकेत"},categories_desc:{en:"Manage saved tags and their color tones. You can rename tags and assign multiple tags to each entry.",ru:"Управление сохранёнными метками и их цветовыми тонами. Вы можете переименовывать метки и присваивать несколько меток одной записи.",ua:"Керування збереженими мітками та їх кольоровими тонами. Ви можете перейменовувати мітки та призначати кілька міток одному запису.",be:"Дадавайце персанальныя меткі і прызначайце ім колеравыя індыкатары",kk:"Жеке белгілерді қосып, оларға түсті индикаторларды тағайындаңыз",zh:"添加个性化标签并为其指定专属颜色",ja:"カスタムタグを作成し、カラーインジケーターを割り当てます",hi:"कस्टम टैग जोड़ें और उनके लिए रंग निर्दिष्ट करें"},default_cat_badge:{en:"(default)",ru:"(базовая)",ua:"(базова)",be:"базавая",kk:"әдепкі",zh:"默认",ja:"デフォルト",hi:"डिफ़ॉल्ट"},new_cat_placeholder:{en:"New tag name (letters & digits only)...",ru:"Название новой метки (буквы и цифры)...",ua:"Назва нової мітки (букви та цифри)...",be:"Назва новай меткі...",kk:"Жаңа белгі атауы...",zh:"新标签名称...",ja:"新しいタグ名...",hi:"नए टैग का नाम..."},add_cat_btn:{en:"Add",ru:"Добавить",ua:"Додати",be:"Дадаць метку",kk:"Белгі қосу",zh:"添加标签",ja:"タグを追加",hi:"टैग जोड़ें"},rename_cat_title:{en:"Rename tag",ru:"Переименовать метку",ua:"Перейменувати мітку",be:"Перайменаваць",kk:"Атын өзгерту",zh:"重命名",ja:"名前を変更",hi:"नाम बदलें"},new_cat_color_label:{en:"Tag color tone:",ru:"Цветовой тон метки:",ua:"Колірний тон мітки:",be:"Колер новай меткі",kk:"Жаңа белгінің түсі",zh:"新标签颜色",ja:"新規タグの色",hi:"नए टैग का रंग"},change_color_title:{en:"Change color tone",ru:"Изменить цветовой тон",ua:"Змінити колірний тон",be:"Змяніць колер меткі",kk:"Белгі түсін өзгерту",zh:"更改标签颜色",ja:"タグの色を変更",hi:"टैग का रंग बदलें"},cat_color_updated:{en:"Tag color updated",ru:"Цвет метки обновлен",ua:"Колір мітки оновлено",be:"Колер абноўлены",kk:"Түс жаңартылды",zh:"颜色已更新",ja:"色を更新しました",hi:"रंग अपडेट किया गया"},cat_renamed:{en:"Tag renamed",ru:"Метка переименована",ua:"Мітку перейменовано",be:"Метка перайменавана",kk:"Белгі атауы өзгертілді",zh:"标签已重命名",ja:"タグ名を変更しました",hi:"टैग का नाम बदला गया"},backup_section:{en:"Backup & Data Transfer",ru:"Резервное копирование и экспорт",ua:"Резервне копіювання та експорт",be:"Рэзервовае капіраванне і экспарт",kk:"Сақтық көшірме және экспорт",zh:"备份与导出",ja:"バックアップとエクスポート",hi:"बैकअप और निर्यात"},backup_desc_short:{en:"Export JSON / CSV and import data",ru:"Экспорт JSON / CSV и импорт данных",ua:"Експорт JSON / CSV та імпорт даних",be:"Экспарт, імпарт JSON/CSV і ключ аднаўлення",kk:"Экспорт, JSON/CSV импорты және қалпына келтіру кілті",zh:"JSON/CSV 导入导出与恢复密钥",ja:"JSON/CSVの入出力と復元キー",hi:"JSON/CSV निर्यात, आयात और पुनर्प्राप्ति कुंजी"},csv_export_btn:{en:"Export",ru:"Export",ua:"Export",be:"Export",kk:"Export",zh:"导出",ja:"エクスポート",hi:"Export"},csv_import_btn:{en:"Import",ru:"Import",ua:"Import",be:"Import",kk:"Import",zh:"导入",ja:"インポート",hi:"Import"},csv_import_success:{en:"Imported {count} passwords from CSV",ru:"Импортировано {count} паролей из CSV",ua:"Імпортовано {count} паролів із CSV",be:"Імпартавана {count} пароляў з CSV",kk:"CSV-ден {count} құпия сөз импортталды",zh:"已从 CSV 导入 {count} 条密码",ja:"CSVから {count} 件のパスワードをインポートしました",hi:"CSV से {count} पासवर्ड आयात किए गए"},csv_import_empty:{en:"No valid passwords found in CSV",ru:"В файле CSV не найдено подходящих паролей",ua:"У файлі CSV не знайдено відповідних паролів",be:"У файле CSV не знойдзена прыдатных пароляў",kk:"CSV файлында жарамды құпия сөздер табылмады",zh:"CSV 文件中未找到有效密码",ja:"CSV内に有効なパスワードが見つかりませんでした",hi:"CSV में कोई मान्य पासवर्ड नहीं मिला"},recovery_key_label:{en:"Recovery Key (12 Words)",ru:"Ключ восстановления (12 слов)",ua:"Ключ відновлення (12 слів)",be:"Ключ аднаўлення (12 слоў)",kk:"Қалпына келтіру кілті (12 сөз)",zh:"紧急恢复密钥 (12个助记词)",ja:"復元キー (12の単語)",hi:"पुनर्प्राप्ति कुंजी (12 शब्द)"},recovery_key_desc:{en:"Secret mnemonic phrase to recover master password if lost.",ru:"Секретная мнемоническая фраза для сброса мастер-пароля в случае его утери.",ua:"Секретна мнемонічна фраза для скидання майстер-пароля у разі його втрати.",be:"Дазваляе скінуць і стварыць новы майстар-пароль без страты захаваных даных.",kk:"Сақталған деректерді жоғалтпай жаңа мастер-құпия сөзді орнатуға мүмкіндік береді.",zh:"可在遗忘主密码时安全重置密码且不丢失数据。",ja:"マスターパスワードを忘れた場合にデータを保持したままリセットできます。",hi:"यदि आप मास्टर पासवर्ड भूल जाते हैं तो डेटा खोए बिना पासवर्ड रीसेट करने की अनुमति देता है।"},show_recovery_btn:{en:"Show 12 words",ru:"Показать 12 слов",ua:"Показати 12 слів",be:"Паказаць ключ аднаўлення",kk:"Қалпына келтіру кілтін көрсету",zh:"查看恢复密钥",ja:"復元キーを表示",hi:"पुनर्प्राप्ति कुंजी दिखाएं"},wipe_data_label:{en:"Danger Zone: Reset All Data",ru:"Опасная зона: Сброс всех данных",ua:"Небезпечна зона: Скидання всіх даних",be:"Поўны скід і выдаленне сховішча",kk:"Қойманы толық тазалау және жою",zh:"完全清除并重置保管库",ja:"完全リセットと保管庫の消去",hi:"पूरा डेटा हटाएं और रीसेट करें"},wipe_data_desc:{en:"Permanently erase all databases, passwords, and settings from this browser.",ru:"Полное безвозвратное удаление всех баз, паролей и настроек из этого браузера.",ua:"Повне безповоротне видалення усіх баз, паролів та налаштувань з цього браузера.",be:"Усе паролі, базы даных і налады будуць незваротна выдалены з браўзера.",kk:"Барлық құпия сөздер, дерекқорлар және баптаулар браузерден біржола жойылады.",zh:"所有密码、项目和设置都将从浏览器中永久抹除。",ja:"すべてのパスワード、データベース、設定がブラウザから完全に削除されます。",hi:"सभी पासवर्ड, डेटाबेस और सेटिंग्स ब्राउज़र से स्थायी रूप से हटा दी जाएंगी।"},wipe_all_btn:{en:"Wipe all and reset",ru:"Стереть всё и сбросить",ua:"Стерти все та скинути",be:"Выдаліць усе даныя",kk:"Барлық деректерді жою",zh:"清除所有数据",ja:"すべてのデータを消去",hi:"सभी डेटा हटाएं"},delete_current_vault_btn:{en:"Delete current database",ru:"Удалить текущую базу данных",ua:"Видалити поточну базу даних",be:"Выдаліць бягучую базу даных",kk:"Ағымдағы деректер қорын жою",zh:"删除当前数据库",ja:"現在のデータベースを削除",hi:"वर्तमान डेटाबेस हटाएं"},delete_current_vault_desc:{en:"Permanently deletes only this database. Other databases will remain intact.",ru:"Безвозвратно удаляет только эту базу данных. Другие базы данных останутся нетронутыми.",ua:"Безповоротно видаляє лише цю базу даних. Інші бази даних залишаться недоторканими.",be:"Выдаляе толькі гэтую базу даных. Іншыя базы захаваюцца.",kk:"Тек осы деректер қорын жояды. Басқа қорлар өзгеріссіз қалады.",zh:"仅永久删除此数据库。其他数据库将保持不变。",ja:"このデータベースのみを完全に削除します。他のデータベースはそのまま保持されます。",hi:"केवल इस डेटाबेस को स्थायी रूप से हटाता है। अन्य डेटाबेस सुरक्षित रहेंगे।"},about_section:{en:"About & License",ru:"О программе и Лицензия",ua:"Про програму та Ліцензія",be:"Пра дадатак",kk:"Бағдарлама туралы",zh:"关于 SimplePass",ja:"SimplePassについて",hi:"जानकारी"},about_desc_short:{en:"Version 0.6, encryption specs and reset",ru:"Версия 0.6, шифрование и сброс данных",ua:"Версія 0.6, шифрування та скидання даних",be:"Версія, крыптаграфія і ліцэнзія",kk:"Нұсқасы, криптографиясы және лицензиясы",zh:"版本信息、加密规格与开源许可",ja:"バージョン、暗号化仕様、ライセンス",hi:"संस्करण, क्रिप्टोग्राफी और लाइसेंस"},about_desc:{en:"Open-source zero-knowledge password manager. Passwords are never sent to third-party servers.",ru:"Открытый менеджер паролей с нулевым разглашением (Zero-Knowledge). Пароли не отправляются на сторонние серверы.",ua:"Відкритий менеджер паролів з нульовим розголошенням (Zero-Knowledge). Паролі не надсилаються на сторонні сервери.",be:"Бяспечны менеджэр пароляў для Chrome з лакальным E2EE шыфраваннем і падтрымкай UNIX pass.",kk:"Жергілікті E2EE шифрлеуі және UNIX pass қолдауы бар Chrome арналған қауіпсіз құпия сөз реттеушісі.",zh:"基于本地端到端加密 (E2EE) 并支持 UNIX pass 的安全 Chrome 密码管理器。",ja:"ローカルE2EE暗号化とUNIX passに対応したChrome用安全なパスワードマネージャー。",hi:"स्थानीय E2EE एन्क्रिप्शन और UNIX pass समर्थन के साथ Chrome के लिए सुरक्षित पासवर्ड मैनेजर।"},crypto_spec_title:{en:"Encryption Specification",ru:"Спецификация шифрования",ua:"Специфікація шифрування",be:"Спецыфікацыя крыптаграфіі",kk:"Криптография сипаттамасы",zh:"加密技术规格",ja:"暗号化仕様",hi:"क्रिप्टोग्राफ़िक विनिर्देश"},settings_not_found:{en:"Settings not found",ru:"Настройки не найдены",ua:"Налаштування не знайдено",be:"Налады не знойдзены",kk:"Баптаулар табылмады",zh:"未找到相关设置",ja:"設定が見つかりません",hi:"सेटिंग्स नहीं मिलीं"},no_search_results:{en:"No settings found for «{query}»",ru:"По запросу «{query}» ничего не найдено",ua:"За запитом «{query}» нічого не знайдено",be:"Няма вынікаў па запыце «{query}»",kk:"«{query}» сұрауы бойынша нәтиже жоқ",zh:"未找到与 “{query}” 匹配的结果",ja:"「{query}」に一致する結果は見つかりませんでした",hi:"«{query}» के लिए कोई परिणाम नहीं मिला"},csv_template_link:{en:"Download CSV import template",ru:"Скачать шаблон CSV для импорта",ua:"Завантажити шаблон CSV для імпорту",be:"Спампаваць шаблон CSV для імпарту",kk:"Импортқа арналған CSV үлгісін жүктеп алу",zh:"下载 CSV 导入模板",ja:"CSVインポートテンプレートをダウンロード",hi:"आयात के लिए CSV टेम्प्लेट डाउनलोड करें"},export_title:{en:"Export passwords",ru:"Экспорт паролей",ua:"Експорт паролів",be:"Экспарт пароляў",kk:"Құпия сөздерді экспорттау",zh:"导出密码",ja:"パスワードのエクスポート",hi:"पासवर्ड निर्यात"},export_desc:{en:"Export all passwords in unencrypted format (JSON or CSV).",ru:"Экспорт всех паролей в незашифрованном виде (JSON или CSV).",ua:"Експорт усіх паролів у незашифрованому вигляді (JSON або CSV).",be:"Экспарт усіх пароляў у незашыфраваным выглядзе (JSON або CSV).",kk:"Барлық құпия сөздерді шифрленбеген түрде экспорттау (JSON немесе CSV).",zh:"导出所有未加密密码（JSON 或 CSV）。",ja:"暗号化されていない形式（JSONまたはCSV）ですべてのパスワードをエクスポートします。",hi:"सभी पासवर्ड अनएन्क्रिप्टेड प्रारूप (JSON या CSV) में निर्यात करें।"},export_advanced_link:{en:"Advanced settings",ru:"Дополнительные настройки",ua:"Додаткові налаштування",be:"Дадатковыя налады",kk:"Қосымша баптаулар",zh:"高级设置",ja:"詳細設定",hi:"उन्नत सेटिंग्स"},export_spbackup_opt:{en:"Backup (.spbackup)",ru:"Бэкап (.spbackup)",ua:"Бекап (.spbackup)",be:"Бэкап (.spbackup)",kk:"Сақтық көшірме (.spbackup)",zh:"备份 (.spbackup)",ja:"バックアップ (.spbackup)",hi:"बैकअप (.spbackup)"},export_warning_title:{en:"Unencrypted Export Warning",ru:"Предупреждение: открытый экспорт",ua:"Попередження: відкритий експорт",be:"Папярэджанне: адкрыты экспарт",kk:"Ескерту: ашық экспорт",zh:"未加密导出警告",ja:"暗号化されていないエクスポートの警告",hi:"असुरक्षित निर्यात चेतावनी"},export_warning_desc:{en:"This file will contain your passwords in plaintext. Anyone with access to this file can read them.",ru:"Файл будет содержать ваши пароли в открытом незашифрованном виде. Любой, у кого есть доступ к файлу, сможет их прочитать.",ua:"Файл міститиме ваші паролі у відкритому незашифрованому вигляді.",be:"Файл будзе змяшчаць вашыя паролі ў адкрытым незашыфраваным выглядзе.",kk:"Файлда құпия сөздер ашық түрде болады.",zh:"该文件将包含未加密的明文密码。任何能够访问该文件的人都可以直接读取它们。",ja:"このファイルには暗号化されていない平文のパスワードが含まれます。",hi:"इस फ़ाइल में आपके पासवर्ड सादे पाठ में होंगे।"},export_confirm_pwd_label:{en:"Enter master password to confirm:",ru:"Введите мастер-пароль для подтверждения:",ua:"Введіть майстер-пароль для підтвердження:",be:"Увядзіце майстар-пароль для пацвярджэння:",kk:"Растау үшін мастер-құпия сөзді енгізіңіз:",zh:"请输入主密码以确认导出:",ja:"確認のためマスターパスワードを入力してください:",hi:"पुष्टि के लिए मास्टर पासवर्ड दर्ज करें:"},export_backup_pwd_label:{en:"Set password to encrypt this backup:",ru:"Задайте пароль для шифрования бэкапа:",ua:"Вкажіть пароль для шифрування бекапу:",be:"Увядзіце пароль для шыфравання бэкапу:",kk:"Сақтық көшірмені шифрлеу үшін құпия сөзді орнатыңыз:",zh:"设置用于加密此备份的密码:",ja:"バックアップを暗号化するパスワードを設定:",hi:"इस बैकअप को एन्क्रिप्ट करने के लिए पासवर्ड सेट करें:"},import_backup_pwd_label:{en:"Enter backup decryption password:",ru:"Введите пароль для расшифровки бэкапа:",ua:"Введіть пароль для розшифрування бекапу:",be:"Увядзіце пароль для расшыфравання бэкапу:",kk:"Сақтық көшірменің шифрын ашу құпия сөзін енгізіңіз:",zh:"输入备份解密密码:",ja:"バックアップ復号パスワードを入力:",hi:"बैकअप डिक्रिप्शन पासवर्ड दर्ज करें:"},export_spbackup_success:{en:"Encrypted backup saved (.spbackup)",ru:"Зашифрованный бэкап успешно сохранён (.spbackup)",ua:"Зашифрований бекап збережено (.spbackup)",be:"Зашыфраваны бэкап паспяхова захаваны (.spbackup)",kk:"Шифрленген сақтық көшірме сақталды (.spbackup)",zh:"已保存加密备份 (.spbackup)",ja:"暗号化バックアップを保存しました (.spbackup)",hi:"एन्क्रिप्टेड बैकअप सहेजा गया (.spbackup)"},import_spbackup_success:{en:"Restored {count} passwords from .spbackup",ru:"Восстановлено {count} паролей из .spbackup",ua:"Відновлено {count} паролів із .spbackup",be:"Адноўлена {count} пароляў з .spbackup",kk:".spbackup файлынан {count} құпия сөз қалпына келтірілді",zh:"已从 .spbackup 恢复 {count} 个密码",ja:".spbackup から {count} 件のパスワードを復元しました",hi:".spbackup से {count} पासवर्ड पुनर्स्थापित किए गए"},export_by_tags_title:{en:"Export by tags",ru:"Экспорт по меткам",ua:"Експорт за мітками",be:"Экспарт па пазнаках",kk:"Белгілер бойынша экспорт",zh:"按标签导出",ja:"タグ別にエクスポート",hi:"टैग द्वारा निर्यात"},export_select_all:{en:"Select all",ru:"Выбрать все",ua:"Вибрати всі",be:"Выбраць усе",kk:"Барлығын таңдау",zh:"全选",ja:"すべて選択",hi:"सभी चुनें"},export_clear_tags:{en:"Clear",ru:"Сбросить",ua:"Скинути",be:"Скінуць",kk:"Тазарту",zh:"重置",ja:"リセット",hi:"रीसेट करें"},export_tags_none_selected:{en:"No tags selected — all passwords will be exported ({count})",ru:"Метки не выбраны — будут экспортированы все пароли ({count})",ua:"Мітки не вибрані — буде експортовано всі паролі ({count})",be:"Пазнакі не выбраныя — будуць экспартаваныя ўсе паролі ({count})",kk:"Белгілер таңдалмаған — барлық құпия сөздер экспортталады ({count})",zh:"未选择标签 — 将导出所有密码 ({count})",ja:"タグ未選択 — すべてのパスワードが出力されます ({count})",hi:"कोई टैग नहीं चुना गया — सभी पासवर्ड निर्यात होंगे ({count})"},export_tags_selected_count:{en:"Passwords selected for export: {count} of {total}",ru:"Выбрано паролей для экспорта: {count} из {total}",ua:"Вибрано паролів для експорту: {count} з {total}",be:"Выбрана пароляў для экспарту: {count} з {total}",kk:"Экспортқа таңдалған құпия сөздер: {count} / {total}",zh:"已选择导出密码：{count} / {total}",ja:"エクスポート対象: {total} 件中 {count} 件",hi:"निर्यात के लिए चयनित पासवर्ड: {total} में से {count}"},export_no_matching_items:{en:"No passwords match the selected tags for export",ru:"Нет паролей с выбранными метками для экспорта",ua:"Немає паролів з вибраними мітками для експорту",be:"Няма пароляў з выбранымі пазнакамі для экспарту",kk:"Экспорт үшін таңдалған белгілері бар құпия сөздер жоқ",zh:"没有符合所选标签的密码可供导出",ja:"選択されたタグに一致するパスワードがありません",hi:"निर्यात के लिए चयनित टैग से मेल खाने वाला कोई पासवर्ड नहीं है"},export_no_tags_available:{en:"No tags available",ru:"Нет доступных меток",ua:"Немає доступних міток",be:"Няма даступных пазнак",kk:"Қолжетімді белгілер жоқ",zh:"没有可用的标签",ja:"利用可能なタグがありません",hi:"कोई टैग उपलब्ध नहीं है"},import_title:{en:"Import passwords",ru:"Импорт паролей",ua:"Імпорт паролів",be:"Імпарт пароляў",kk:"Құпия сөздерді импорттау",zh:"导入密码",ja:"パスワードのインポート",hi:"पासवर्ड आयात"},import_desc:{en:"Import passwords from JSON (Bitwarden / SimplePass) or CSV file. File type is detected automatically.",ru:"Импорт паролей из файла JSON (Bitwarden / SimplePass) или CSV. Тип файла определяется автоматически.",ua:"Імпорт паролів із файлу JSON (Bitwarden / SimplePass) або CSV. Тип файлу визначається автоматично.",be:"Імпарт пароляў з файла JSON (Bitwarden / SimplePass) або CSV. Тып файла вызначаецца аўтаматычна.",kk:"JSON (Bitwarden / SimplePass) немесе CSV файлынан құпия сөздерді импорттау. Файл түрі автоматты түрде анықталады.",zh:"从 JSON（Bitwarden / SimplePass）或 CSV 文件导入密码。系统会自动识别文件类型。",ja:"JSON（Bitwarden / SimplePass）またはCSVファイルからパスワードをインポートします。ファイル形式は自動検出されます。",hi:"JSON (Bitwarden / SimplePass) या CSV फ़ाइल से पासवर्ड आयात करें। फ़ाइल प्रकार स्वचालित रूप से पहचाना जाता है।"},export_csv_success:{en:"Exported to CSV successfully",ru:"Экспорт в CSV успешно выполнен",ua:"Експорт у CSV успішно виконано",be:"Экспарт у CSV паспяхова выкананы",kk:"CSV форматында сәтті экспортталды",zh:"已成功导出为 CSV",ja:"CSVに正常にエクスポートしました",hi:"CSV में सफलतापूर्वक निर्यात किया गया"},export_json_success:{en:"Exported to JSON successfully",ru:"Экспорт в JSON успешно выполнен",ua:"Експорт у JSON успішно виконано",be:"Экспарт у JSON паспяхова выкананы",kk:"JSON форматында сәтті экспортталды",zh:"已成功导出为 JSON",ja:"JSONに正常にエクスポートしました",hi:"JSON में सफलतापूर्वक निर्यात किया गया"},delete_vault_confirm:{en:'Delete database "{name}"? Other database profiles will remain safe.',ru:"Удалить текущую базу «{name}»? Другие базы данных останутся сохранены.",ua:"Видалити поточну базу «{name}»? Інші бази даних залишаться збереженими.",be:"Выдаліць бягучую базу «{name}»? Іншыя базы даных застануцца захаванымі.",kk:"Ағымдағы «{name}» қоймасын жою керек пе? Басқа қоймалар сақталады.",zh:"确定删除数据库“{name}”吗？其他数据库配置文件将保持安全。",ja:"データベース「{name}」を削除しますか？他のプロファイルは保持されます。",hi:'डेटाबेस "{name}" हटाएं? अन्य डेटाबेस प्रोफ़ाइल सुरक्षित रहेंगी।'},reset_prompt:{en:"WARNING: To completely wipe all stored data, type RESET:",ru:"ВНИМАНИЕ: Для полного сброса всех данных введите СБРОС:",ua:"УВАГА: Для повного скидання всіх даних введіть СКИДАННЯ:",be:"УВАГА: Для поўнага скіду ўсіх даных увядзіце СКІД:",kk:"ЕСКЕРТУ: Барлық деректерді толық өшіру үшін ЖОЮ деп жазыңыз:",zh:"警告：如需完全清除所有存储数据，请输入 RESET：",ja:"警告：すべての保存データを完全に消去するには RESET と入力してください：",hi:"चेतावनी: सभी सहेजे गए डेटा को पूरी तरह से मिटाने के लिए RESET टाइप करें:"},tag_name_empty:{en:"Tag name cannot be empty",ru:"Название метки не может быть пустым",ua:"Назва мітки не може бути порожньою",be:"Назва пазнакі не можа быць пустой",kk:"Тег атауы бос болмауы керек",zh:"标签名称不能为空",ja:"タグ名は空にできません",hi:"टैग का नाम खाली नहीं हो सकता"},new_db_name_prompt:{en:"New database name:",ru:"Новое имя базы данных:",ua:"Нова назва бази даних:",be:"Новая назва базы дадзеных:",kk:"Дерекқордың жаңа атауы:",zh:"新数据库名称：",ja:"新しいデータベース名:",hi:"नया डेटाबेस नाम:"},current_site_label:{en:"Show Passwords for Active Site",ru:"Пароли для текущего сайта",ua:"Паролі для поточного сайту",be:"Паролі для бягучага сайта",kk:"Ағымдағы сайтқа арналған құпиясөздер",zh:"显示当前网站的密码",ja:"アクティブなサイトのパスワードを表示",hi:"सक्रिय साइट के लिए पासवर्ड दिखाएं"},current_site_desc:{en:"Automatically filters and pins credentials for the active tab (requires tab permission)",ru:"Автоматически фильтрует и закрепляет пароли активной вкладки (требует доступ к вкладкам)",ua:"Автоматично фільтрує та закріплює паролі активної вкладки (потребує доступ до вкладок)",be:"Аўтаматычна фільтруе і замацоўвае паролі актыўнай укладкі (патрабуе доступ да ўкладак)",kk:"Ағымдағы қойынды үшін құпиясөздерді автоматты түрде сүзеді (қойындыларға рұқсат қажет)",zh:"自动筛选并置顶活动标签页的凭据（需要标签页权限）",ja:"アクティブなタブの認証情報を自動的にフィルターして固定します（タブの権限が必要）",hi:"सक्रिय टैब के लिए क्रेडेंशियल को स्वचालित रूप से फ़िल्टर और पिन करता है (टैब अनुमति आवश्यक)"}},ra={create_profile_title:{en:"Create Profile",ru:"Создание профиля",ua:"Створення профілю",be:"Стварыць сховішча",kk:"Қойма жасау",zh:"创建密码保管库",ja:"保管庫を作成",hi:"वॉल्ट बनाएं"},create_profile_desc:{en:"Set profile name and master password for AES-256-GCM encryption.",ru:"Задайте имя первого профиля и мастер-пароль для шифрования AES-256-GCM.",ua:"Вкажіть назву першого профілю та майстер-пароль для шифрування AES-256-GCM.",be:"Прыдумайце надзейны майстар-пароль для шыфравання даных",kk:"Деректерді шифрлеу үшін сенімді мастер-құпия сөзді ойлап табыңыз",zh:"设置一个强主密码以保护您的加密数据",ja:"データを保護する強力なマスターパスワードを設定してください",hi:"डेटा सुरक्षा के लिए एक मजबूत मास्टर पासवर्ड बनाएं"},profile_name_placeholder:{en:"Profile name",ru:"Название профиля",ua:"Назва профілю",be:"Імя сховішча (напрыклад: Асноўнае)",kk:"Қойма атауы (мысалы: Негізгі)",zh:"保管库名称 (例如: 主库)",ja:"保管庫名 (例: メイン)",hi:"वॉल्ट नाम (जैसे: मुख्य)"},master_pwd_placeholder:{en:"Master password (min 10 chars)",ru:"Мастер-пароль (не менее 10 симв.)",ua:"Майстер-пароль (не менше 10 симв.)",be:"Майстар-пароль (ад 10 сімвалаў)",kk:"Мастер-құпия сөз (10 таңбадан бастап)",zh:"主密码 (至少 10 位)",ja:"マスターパスワード (10文字以上)",hi:"मास्टर पासवर्ड (कम से कम 10 वर्ण)"},pwd_empty:{en:"Enter master password",ru:"Введите мастер-пароль",ua:"Введіть майстер-пароль",be:"Увядзіце майстар-пароль",kk:"Мастер-құпия сөзді енгізіңіз",zh:"请输入主密码",ja:"マスターパスワードを入力してください",hi:"मास्टर पासवर्ड दर्ज करें"},pwd_too_short:{en:"Master password must be at least 10 characters long",ru:"Мастер-пароль должен содержать не менее 10 символов",ua:"Майстер-пароль повинен містити не менше 10 символів",be:"Майстар-пароль павінен утрымліваць не менш за 10 сімвалаў",kk:"Мастер-құпия сөз кемінде 10 таңбадан тұруы керек",zh:"主密码长度至少为 10 个字符",ja:"マスターパスワードは10文字以上である必要があります",hi:"मास्टर पासवर्ड कम से कम 10 वर्णों का होना चाहिए"},pwd_needs_special:{en:"Password under 16 characters must include a special character (!@#$%...)",ru:"Пароль короче 16 символов должен содержать спецсимвол (!@#$%...)",ua:"Пароль коротший за 16 символів повинен містити спецсимвол (!@#$%...)",be:"Пароль менш за 16 сімвалаў павінен утрымліваць спецсімвал (!@#$%...)",kk:"16 таңбадан қысқа құпия сөзде арнайы таңба болуы керек (!@#$%...)",zh:"少于 16 位的密码必须包含特殊符号 (!@#$%...)",ja:"16文字未満のパスワードには特殊記号 (!@#$%...) が必要です",hi:"16 वर्णों से कम के पासवर्ड में एक विशेष वर्ण (!@#$%...) होना चाहिए"},repeat_pwd_placeholder:{en:"Repeat master password",ru:"Повторите мастер-пароль",ua:"Повторіть майстер-пароль",be:"Паўтарыце майстар-пароль",kk:"Мастер-құпия сөзді қайталаңыз",zh:"确认主密码",ja:"マスターパスワード (再入力)",hi:"मास्टर पासवर्ड दोहराएं"},create_profile_btn:{en:"Create Profile",ru:"Создать профиль",ua:"Створити профіль",be:"Стварыць сховішча",kk:"Қойма жасау",zh:"创建保管库",ja:"保管庫を作成",hi:"वॉल्ट बनाएं"},locked_title:{en:"SimplePass Locked",ru:"SimplePass заблокирован",ua:"SimplePass заблоковано",be:"Сховішча заблакіравана",kk:"Қойма құлыпталған",zh:"保管库已锁定",ja:"保管庫はロックされています",hi:"वॉल्ट लॉक है"},locked_desc:{en:"Enter master password to unlock passwords",ru:"Введите мастер-пароль для разблокировки записей",ua:"Введіть майстер-пароль для розблокування записів",be:"Увядзіце майстар-пароль для доступу",kk:"Кіру үшін мастер-құпия сөзді енгізіңіз",zh:"请输入主密码以解锁",ja:"アクセスするにはマスターパスワードを入力してください",hi:"एक्सेस के लिए मास्टर पासवर्ड दर्ज करें"},lockout_warning:{en:"🔒 Password entry locked! Exceeded limit of 3 failed attempts. Access is only possible via 12-word recovery key.",ru:"🔒 Ввод пароля заблокирован! Превышен лимит 3 неудачных попыток ввода. Доступ к хранилищу возможен только по секретному ключу восстановления (12 слов).",ua:"🔒 Введення пароля заблоковано! Перевищено ліміт 3 невдалих спроб. Доступ до сховища можливий лише за секретним ключем відновлення (12 слів).",be:"Засталося спроб: {remaining}",kk:"Қалған әрекеттер саны: {remaining}",zh:"剩余尝试次数: {remaining}",ja:"残り試行回数: {remaining}",hi:"शेष प्रयास: {remaining}"},unlock_btn:{en:"Unlock",ru:"Разблокировать",ua:"Розблокувати",be:"Разблакіраваць",kk:"Құлыпты ашу",zh:"解锁",ja:"ロック解除",hi:"अनलॉक करें"},forgot_pwd_btn:{en:"Forgot password?",ru:"Забыли пароль?",ua:"Забули пароль?",be:"Забыліся пароль?",kk:"Құпия сөзді ұмыттыңыз ба?",zh:"忘记密码？",ja:"パスワードをお忘れですか？",hi:"पासवर्ड भूल गए?"},switch_profile_btn:{en:"Log in to another profile",ru:"Войти в другой профиль",ua:"Увійти в інший профіль",be:"Увайсці ў іншы профіль",kk:"Басқа бейінге кіру",zh:"登录其他配置文件",ja:"別のプロファイルにログイン",hi:"अन्य प्रोफ़ाइल में लॉग इन करें"},select_profile_title:{en:"Select Profile",ru:"Выбор профиля",ua:"Вибір профілю",be:"Выбар профілю",kk:"Бейінді таңдау",zh:"选择配置文件",ja:"プロファイルを選択",hi:"प्रोफ़ाइल चुनें"},select_profile_desc:{en:"Select a database profile to log in:",ru:"Выберите профиль базы данных для входа:",ua:"Оберіть профіль бази даних для входу:",be:"Абярыце профіль базы даных для ўваходу:",kk:"Кіру үшін деректер қоры бейінін таңдаңыз:",zh:"选择要登录的数据库配置文件：",ja:"ログインするデータベースプロファイルを選択してください：",hi:"लॉग इन करने के लिए डेटाबेस प्रोफ़ाइल चुनें:"},lockout_attempt_error:{en:"Incorrect master password. Attempt {current} of 3.",ru:"Неверный мастер-пароль. Попытка {current} из 3.",ua:"Невірний майстер-пароль. Спроба {current} з 3.",be:"Засталося {attempts} спроб да блакіроўкі на 60 сек",kk:"60 сек бұғатталуға дейін {attempts} әрекет қалды",zh:"还有 {attempts} 次尝试机会，否则将被锁定 60 秒",ja:"60秒間のロックまで残り {attempts} 回",hi:"60 सेकंड के लिए लॉक होने से पहले {attempts} प्रयास शेष"},restore_by_key_btn:{en:"Restore with 12-word key",ru:"Восстановить по ключу (12 слов)",ua:"Відновити за ключем (12 слів)",be:"Аднавіць з дапамогай ключа (12 слоў)",kk:"Кілт арқылы қалпына келтіру (12 сөз)",zh:"使用 12 个助记词密钥恢复",ja:"12語の復元キーで復旧",hi:"12-शब्दों की कुंजी से पुनर्प्राप्त करें"},recovery_title:{en:"Access Recovery",ru:"Восстановление доступа",ua:"Відновлення доступу",be:"Аднаўленне доступу",kk:"Қолжетімділікті қалпына келтіру",zh:"恢复访问权限",ja:"アクセスの復元",hi:"एक्सेस पुनर्प्राप्त करें"},recovery_desc:{en:"Enter your 12-word secret key and set a new master password.",ru:"Введите ваш секретный ключ из 12 слов и задайте новый мастер-пароль.",ua:"Введіть ваш секретний ключ з 12 слів та задайте новий майстер-пароль.",be:"Увядзіце ваш 12-слоўны ключ аднаўлення",kk:"12 сөзден тұратын қалпына келтіру кілтін енгізіңіз",zh:"输入您的 12 位恢复助记词",ja:"12の単語からなる復元キーを入力してください",hi:"अपनी 12-शब्दों की पुनर्प्राप्ति कुंजी दर्ज करें"},recovery_phrase_placeholder:{en:"12 words separated by spaces (e.g. abandon ability able ...)",ru:"12 слов через пробел (например: abandon ability able ...)",ua:"12 слів через пробіл (наприклад: abandon ability able ...)",be:"12 слоў праз прабел...",kk:"Бос орынмен бөлінген 12 сөз...",zh:"由空格分隔的 12 个单词...",ja:"スペース区切りの12語...",hi:"स्पेस द्वारा अलग किए गए 12 शब्द..."},restore_access_btn:{en:"Restore Access",ru:"Восстановить доступ",ua:"Відновити доступ",be:"Праверыць і аднавіць",kk:"Тексеру және қалпына келтіру",zh:"验证并恢复",ja:"検証して復元",hi:"जांचें और पुनर्प्राप्त करें"},return_to_login_btn:{en:"Back to login",ru:"Вернуться ко входу",ua:"Повернутися до входу",be:"Вярнуцца да ўваходу",kk:"Кіруге оралу",zh:"返回登录",ja:"ログインに戻る",hi:"लॉगिन पर वापस जाएं"},create_new_db_btn:{en:"Create new database",ru:"Создать новую базу данных",ua:"Створити нову базу даних",be:"Стварыць новую базу даных",kk:"Жаңа деректер қорын жасау",zh:"创建新数据库",ja:"新しいデータベースを作成",hi:"नया डेटाबेस बनाएं"},select_db_label:{en:"Database:",ru:"База данных:",ua:"База даних:",be:"База даных:",kk:"Деректер қоры:",zh:"数据库：",ja:"データベース：",hi:"डेटाबेस:"},new_db_title:{en:"New Database",ru:"Новая база данных",ua:"Нова база даних",be:"Новая база даных",kk:"Жаңа деректер қоры",zh:"新数据库",ja:"新しいデータベース",hi:"नया डेटाबेस"},new_db_desc:{en:"Create a new independent database. Existing databases and records will not be deleted.",ru:"Создание новой независимой базы. Существующие базы данных и записи не будут удалены.",ua:"Створення нової незалежної бази. Існуючі бази даних та записи не будуть видалені.",be:"Стварэнне новай незалежнай базы. Старыя базы і запісы захаваюцца.",kk:"Жаңа тәуелсіз қор жасау. Ескі қорлар мен жазбалар жойылмайды.",zh:"创建新的独立数据库。现有的数据库和记录不会被删除。",ja:"新しい独立したデータベースを作成します。既存のデータベースや記録は削除されません。",hi:"एक नया स्वतंत्र डेटाबेस बनाएं। मौजूदा डेटाबेस और रिकॉर्ड हटाए नहीं जाएंगे।"},db_name_placeholder:{en:"Database name (e.g. Work, Personal 2)",ru:"Название базы (напр. Рабочая, Личная 2)",ua:"Назва бази (напр. Робоча, Особиста 2)",be:"Назва базы (напрыклад: Рабочая, Асабістая 2)",kk:"Қор атауы (мысалы: Жұмыс, Жеке 2)",zh:"数据库名称 (例如: 工作, 个人 2)",ja:"データベース名 (例: 仕事, 個人2)",hi:"डेटाबेस का नाम (उदा. काम, व्यक्तिगत 2)"},create_and_enter_btn:{en:"Create and Unlock",ru:"Создать и войти",ua:"Створити та увійти",be:"Стварыць і ўвайсці",kk:"Жасау және кіру",zh:"创建并进入",ja:"作成してログイン",hi:"बनाएं और प्रवेश करें"},cancel_btn:{en:"Cancel",ru:"Отмена",ua:"Скасувати",be:"Адмена",kk:"Болдырмау",zh:"取消",ja:"キャンセル",hi:"रद्द करें"},create_new_db_option:{en:"+ Create new database...",ru:"+ Создать новую базу данных...",ua:"+ Створити нову базу даних...",be:"+ Стварыць новую базу даных...",kk:"+ Жаңа деректер қорын жасау...",zh:"+ 创建新数据库...",ja:"+ 新しいデータベースを作成...",hi:"+ नया डेटाबेस बनाएं..."},pwd_mismatch:{en:"Entered passwords do not match",ru:"Введенные пароли не совпадают",ua:"Введені паролі не збігаються",be:"Уведзеныя паролі не супадаюць",kk:"Енгізілген құпия сөздер сәйкес келмейді",zh:"两次输入的密码不一致",ja:"入力されたパスワードが一致しません",hi:"दर्ज किए गए पासवर्ड मेल नहीं खाते"},lockout_wait:{en:"Too many failed attempts. Please wait {seconds}s.",ru:"Слишком много неверных попыток. Подождите {seconds} сек.",ua:"Забагато невдалих спроб. Зачекайте {seconds} сек.",be:"Занадта шмат няўдалых спроб. Пачакайце {seconds} сек.",kk:"Сәтсіз әрекеттер тым көп. {seconds} секунд күтіңіз.",zh:"失败次数过多，请等待 {seconds} 秒。",ja:"失敗回数が多すぎます。{seconds} 秒お待ちください。",hi:"बहुत अधिक असफल प्रयास। कृपया {seconds} सेकंड प्रतीक्षा करें।"},recovery_exact_words:{en:"Enter exactly 12 words of the recovery key separated by spaces",ru:"Введите ровно 12 слов ключа восстановления через пробел",ua:"Введіть рівно 12 слів ключа відновлення через пробіл",be:"Увядзіце роўна 12 слоў ключа аднаўлення праз прабел",kk:"Қалпына келтіру кілтінің 12 сөзін бос орын арқылы енгізіңіз",zh:"请输入由空格分隔的恰好 12 个助记词",ja:"スペース区切りで正確に12語の復元キーを入力してください",hi:"स्पेस से अलग करके ठीक 12 शब्द दर्ज करें"},recovery_invalid_err:{en:"Invalid recovery key or corrupted data.",ru:"Неверный ключ восстановления или поврежденные данные.",ua:"Невірний ключ відновлення або пошкоджені дані.",be:"Няправільны ключ аднаўлення або пашкоджаныя даныя.",kk:"Қалпына келтіру кілті қате немесе деректер зақымдалған.",zh:"无效的恢复密钥或数据已损坏。",ja:"復元キーが無効であるか、データが破損しています。",hi:"अमान्य पुनर्प्राप्ति कुंजी या दूषित डेटा।"},words_recognized:{en:"✓ {count}/12 words (all recognized)",ru:"✓ {count}/12 слов (все слова распознаны)",ua:"✓ {count}/12 слів (всі слова розпізнані)",be:"✓ {count}/12 слоў (усе словы распазнаныя)",kk:"✓ {count}/12 сөз (барлығы танылды)",zh:"✓ {count}/12 个助记词（全部已识别）",ja:"✓ {count}/12 語（すべて認識されました）",hi:"✓ {count}/12 शब्द (सभी पहचाने गए)"},unknown_word:{en:'⚠️ Unknown word "{word}"',ru:"⚠️ Неизвестное слово «{word}»",ua:"⚠️ Невідоме слово «{word}»",be:"⚠️ Невядомае слова «{word}»",kk:"⚠️ Белгісіз сөз «{word}»",zh:"⚠️ 未知单词 “{word}”",ja:"⚠️ 不明な単語「{word}」",hi:'⚠️ अज्ञात शब्द "{word}"'},suggest_word:{en:" (did you mean: {sugg}?)",ru:" (возможно: {sugg}?)",ua:" (можливо: {sugg}?)",be:" (магчыма: {sugg}?)",kk:" (мүмкін: {sugg}?)",zh:"（您是指：{sugg}？）",ja:"（もしかして: {sugg}？）",hi:" (क्या आपका मतलब है: {sugg}?)"},invalid_master_pwd:{en:"Incorrect current master password",ru:"Неверный текущий мастер-пароль",ua:"Невірний поточний майстер-пароль",be:"Няправільны бягучы майстар-пароль",kk:"Қазіргі шебер құпия сөз қате",zh:"当前主密码错误",ja:"現在のマスターパスワードが正しくありません",hi:"वर्तमान मास्टर पासवर्ड गलत है"}},ia={title:{en:"Your Secret Recovery Key",ru:"Ваш секретный ключ восстановления",ua:"Ваш секретний ключ відновлення",be:"Ключ аднаўлення (12 слоў)",kk:"Қалпына келтіру кілті (12 сөз)",zh:"紧急恢复密钥 (12 助记词)",ja:"復元キー (12語)",hi:"पुनर्प्राप्ति कुंजी (12 शब्द)"},desc:{en:"Save these 12 words in a safe place! It is the only way to recover access if you lose your master password.",ru:"Сохраните эти 12 слов в безопасном месте! Это единственный способ восстановить доступ, если вы забудете мастер-пароль.",ua:"Збережіть ці 12 слів у безпечному місці! Це єдиний спосіб відновити доступ, якщо ви забудете майстер-пароль.",be:"Запішыце або захавайце гэтыя словы ў бяспечным месцы. Толькі з іх дапамогай можна аднавіць сховішча пры страце майстар-пароля.",kk:"Бұл сөздерді қауіпсіз жерде сақтаңыз. Мастер-құпия сөзді ұмытып қалсаңыз, қойманы тек осылар арқылы қалпына келтіруге болады.",zh:"请妥善保管这 12 个单词。如果遗忘主密码，这是恢复数据的唯一凭据。",ja:"この12語を安全な場所に保管してください。マスターパスワードを紛失した場合の唯一の復元手段です。",hi:"इन शब्दों को सुरक्षित स्थान पर लिखकर रखें। मास्टर पासवर्ड भूल जाने पर केवल इसी से वॉल्ट पुनर्प्राप्त किया जा सकता है।"},copy_btn:{en:"Copy 12 words",ru:"Скопировать 12 слов",ua:"Скопіювати 12 слів",be:"Скапіяваць словы",kk:"Сөздерді көшіру",zh:"复制助记词",ja:"単語をコピー",hi:"शब्द कॉपी करें"},download_btn:{en:"Download .txt file",ru:"Скачать файл .txt",ua:"Завантажити файл .txt",be:"Спампаваць .txt",kk:".txt жүктеу",zh:"下载 .txt",ja:".txtを保存",hi:".txt डाउनलोड करें"},confirm_btn:{en:"I saved the key, continue",ru:"Я сохранил ключ, продолжить",ua:"Я зберіг ключ, продовжити",be:"Я захаваў ключ аднаўлення",kk:"Мен қалпына келтіру кілтін сақтадым",zh:"我已安全备份恢复密钥",ja:"復元キーを安全に保存しました",hi:"मैंने पुनर्प्राप्ति कुंजी सहेज ली है"},safe_warning:{en:"IMPORTANT: Keep this file in a safe place. It will restore access if master password is lost.",ru:"ВАЖНО: Храните этот файл в безопасном месте. Он восстановит доступ при утере мастер-пароля.",ua:"ВАЖЛИВО: Зберігайте цей файл у безпечному місці. Він відновить доступ у разі втрати майстер-пароля.",be:"ВАЖНА: Захоўвайце гэты файл у бяспечным месцы. Ён адновіць доступ пры страце майстар-пароля.",kk:"МАҢЫЗДЫ: Бұл файлды қауіпсіз жерде сақтаңыз. Ол шебер құпия сөз жоғалған жағдайда қатынасты қалпына келтіреді.",zh:"重要提示：请将此文件保存在安全的地方。如果主密码丢失，它可以恢复访问权限。",ja:"重要: このファイルを安全な場所に保管してください。マスターパスワードを紛失した場合にアクセスを復元します。",hi:"महत्वपूर्ण: इस फ़ाइल को सुरक्षित स्थान पर रखें। मास्टर पासवर्ड खो जाने पर यह एक्सेस पुनर्स्थापित करेगा।"},file_saved:{en:"File recovery-key.txt saved",ru:"Файл recovery-key.txt сохранён",ua:"Файл recovery-key.txt збережено",be:"Файл recovery-key.txt захаваны",kk:"recovery-key.txt файлы сақталды",zh:"recovery-key.txt 文件已保存",ja:"recovery-key.txt ファイルが保存されました",hi:"फ़ाइल recovery-key.txt सहेजी गई"}},ca={title:{en:"Delete Database",ru:"Удаление базы",ua:"Видалення бази",be:"Выдаленне базы",kk:"Дерекқорды жою",zh:"删除数据库",ja:"データベースの削除",hi:"डेटाबेस हटाएं"},warning_title:{en:"Warning: Cascade deletion!",ru:"Внимание: Каскадное удаление!",ua:"Увага: Каскадне видалення!",be:"Увага!",kk:"Назар аударыңыз!",zh:"警告！",ja:"注意！",hi:"चेतावनी!"},desc:{en:"Database «{name}» and all associated passwords ({count} items) will be deleted permanently.",ru:"База «{name}» и все привязанные к ней пароли ({count} шт.) будут удалены безвозвратно.",ua:"База «{name}» та всі прив'язані до неї паролі ({count} шт.) будуть видалені назавжди.",be:"Вы сапраўды хочаце выдаліць гэтую базу? Усе запісы ў ёй будуць страчаны.",kk:"Бұл дерекқорды жойғыңыз келетініне сенімдісіз бе? Ондағы барлық жазбалар жойылады.",zh:"您确定要删除此数据库吗？其中的所有密码都将被清除。",ja:"このデータベースを本当に削除しますか？含まれるすべてのデータが失われます。",hi:"क्या आप वाकई इस डेटाबेस को हटाना चाहते हैं? इसमें मौजूद सभी प्रविष्टियां नष्ट हो जाएंगी।"},cancel_btn:{en:"Cancel",ru:"Отмена",ua:"Скасувати",be:"Адмена",kk:"Болдырмау",zh:"取消",ja:"キャンセル",hi:"रद्द करें"},confirm_btn:{en:"Delete permanently",ru:"Удалить навсегда",ua:"Видалити назавжди",be:"Выдаліць базу",kk:"Дерекқорды жою",zh:"确认删除",ja:"削除する",hi:"डेटाबेस हटाएं"}},la={title:{en:"Databases (Projects)",ru:"Базы данных (Проекты)",ua:"Бази даних (Проєкти)",be:"Праекты і базы даных",kk:"Жобалар және дерекқорлар",zh:"项目与数据库",ja:"プロジェクトとデータベース",hi:"प्रोजेक्ट और डेटाबेस"},create_new:{en:"Create new database",ru:"Создать новую базу",ua:"Створити нову базу",be:"Стварыць новы праект",kk:"Жаңа жоба жасау",zh:"创建新项目",ja:"新しいプロジェクトを作成",hi:"नया प्रोजेक्ट बनाएं"},name_placeholder:{en:"Database name (e.g. Work)",ru:"Название базы (напр. Work)",ua:"Назва бази (напр. Work)",be:"Назва праекта...",kk:"Жоба атауы...",zh:"项目名称...",ja:"プロジェクト名...",hi:"प्रोजेक्ट का नाम..."},create_btn:{en:"Create",ru:"Создать",ua:"Створити",be:"Стварыць",kk:"Жасау",zh:"创建",ja:"作成",hi:"बनाएं"},browser_type:{en:"Browser (AES-256)",ru:"Браузер (AES-256)",ua:"Браузер (AES-256)",be:"Браўзерная база (лакальна)",kk:"Браузер қоймасы (жергілікті)",zh:"浏览器本地库",ja:"ブラウザローカルDB",hi:"ब्राउज़र वॉल्ट (स्थानीय)"},pass_type:{en:"Local PASS CLI",ru:"Локальный PASS CLI",ua:"Локальний PASS CLI",be:"UNIX pass сховішча",kk:"UNIX pass қоймасы",zh:"UNIX pass 仓库",ja:"UNIX passストレージ",hi:"UNIX pass वॉल्ट"},pass_type_title:{en:"Sync with local ~/.password-store via Native Messaging",ru:"Синхронизация с локальным ~/.password-store через Native Messaging",ua:"Синхронізація з локальним ~/.password-store через Native Messaging",be:"Стварыць базу для сінхранізацыі з UNIX pass",kk:"UNIX pass-пен синхрондалатын дерекқор жасау",zh:"创建与 UNIX pass 同步的数据库",ja:"UNIX passと同期するデータベースを作成",hi:"UNIX pass के साथ सिंक करने के लिए डेटाबेस बनाएं"},rename_prompt:{en:"New database name:",ru:"Новое имя базы данных:",ua:"Нова назва бази даних:",be:"Увядзіце новую назву праекта:",kk:"Жобаның жаңа атауын енгізіңіз:",zh:"输入项目新名称:",ja:"新しいプロジェクト名を入力してください:",hi:"नया प्रोजेक्ट नाम दर्ज करें:"}},da={All:{en:"All",ru:"Все",ua:"Всі",be:"Усе",kk:"Барлығы",zh:"全部",ja:"すべて",hi:"सभी"},Work:{en:"Work",ru:"Work",ua:"Work",be:"Праца",kk:"Жұмыс",zh:"工作",ja:"ワーク",hi:"कार्य"},Personal:{en:"Personal",ru:"Personal",ua:"Personal",be:"Асабістае",kk:"Жеке",zh:"个人",ja:"プライベート",hi:"व्यक्तिगत"}},pa={save_failed:{en:"Failed to save vault data",ru:"Не удалось сохранить данные хранилища",ua:"Не вдалося зберегти дані сховища",be:"Не ўдалося захаваць даныя сховішча",kk:"Қойма деректерін сақтау сәтсіз аяқталды",zh:"保存密码库数据失败",ja:"保管庫データの保存に失敗しました",hi:"वॉल्ट डेटा सहेजने में विफल"},session_invalid:{en:"Session invalid or expired. Please unlock again.",ru:"Сессия недействительна. Пожалуйста, разблокируйте заново.",ua:"Сесія недійсна. Будь ласка, розблокуйте знову.",be:"Сесія несапраўдная. Калі ласка, разблакуйце зноў.",kk:"Сессия жарамсыз. Қайта құлпын ашыңыз.",zh:"会话无效或已过期，请重新解锁。",ja:"セッションが無効または期限切れです。再度ロックを解除してください。",hi:"सत्र अमान्य या समाप्त हो गया है। कृपया पुनः अनलॉक करें।"},copied:{en:"Copied to clipboard",ru:"Скопировано в буфер",ua:"Скопійовано в буфер",be:"Скапіявана ў буфер",kk:"Алмасу буферіне көшірілді",zh:"已复制到剪贴板",ja:"クリップボードにコピーしました",hi:"क्लिपबोर्ड पर कॉपी किया गया"},password_copied:{en:"Password copied to clipboard",ru:"Пароль скопирован в буфер",ua:"Пароль скопійовано в буфер",be:"Пароль скапіяваны ў буфер",kk:"Құпия сөз алмасу буферіне көшірілді",zh:"密码已复制",ja:"パスワードをコピーしました",hi:"पासवर्ड क्लिपबोर्ड पर कॉपी किया गया"},login_copied:{en:"Username copied to clipboard",ru:"Логин скопирован в буфер",ua:"Логін скопійовано в буфер",be:"Лагін скапіяваны ў буфер",kk:"Логин алмасу буферіне көшірілді",zh:"用户名已复制",ja:"ユーザー名をコピーしました",hi:"लॉगिन क्लिपबोर्ड पर कॉपी किया गया"},recovery_words_copied:{en:"12 words copied to clipboard",ru:"12 слов скопированы в буфер",ua:"12 слів скопійовано в буфер",be:"12 слоў аднаўлення скапіяваны",kk:"12 қалпына келтіру сөзі көшірілді",zh:"12 个恢复助记词已复制",ja:"12語の復元キーをコピーしました",hi:"12 पुनर्प्राप्ति शब्द कॉपी किए गए"},language_changed:{en:"Language changed to English",ru:"Язык переключен на Русский",ua:"Мову змінено на Українську",be:"Мова інтэрфейсу зменена",kk:"Интерфейс тілі өзгертілді",zh:"界面语言已更改",ja:"言語を変更しました",hi:"इंटरफ़ेस भाषा बदली गई"},item_csv_exported:{en:"Password exported to CSV",ru:"Запись экспортирована в CSV",ua:"Запис експортовано в CSV",be:"Запіс экспартаваны ў CSV",kk:"Жазба CSV пішімінде экспортталды",zh:"已导出为 CSV 文件",ja:"CSVファイルをエクスポートしました",hi:"CSV फ़ाइल निर्यात की गई"},bitwarden_import_success:{en:"Imported {count} passwords from Bitwarden",ru:"Импортировано {count} паролей из Bitwarden",ua:"Імпортовано {count} паролів із Bitwarden",be:"Імпартавана {count} пароляў з Bitwarden",kk:"Bitwarden-нен {count} құпия сөз импортталды",zh:"已从 Bitwarden 导入 {count} 个密码",ja:"Bitwardenから {count} 件のパスワードをインポートしました",hi:"Bitwarden से {count} पासवर्ड आयात किए गए"},bitwarden_export_success:{en:"Exported to Bitwarden JSON format",ru:"Экспортировано в формате Bitwarden JSON",ua:"Експортовано у форматі Bitwarden JSON",be:"Экспартавана ў фармаце Bitwarden JSON",kk:"Bitwarden JSON форматында экспортталды",zh:"已导出为 Bitwarden JSON 格式",ja:"Bitwarden JSON形式でエクスポートしました",hi:"Bitwarden JSON प्रारूप में निर्यात किया गया"},bitwarden_encrypted_err:{en:"Bitwarden file is encrypted. Please export as unencrypted JSON.",ru:"Файл Bitwarden зашифрован. Экспортируйте из Bitwarden в формате JSON (не зашифровано).",ua:"Файл Bitwarden зашифрований. Будь ласка, експортуйте як незашифрований JSON.",be:"Файл Bitwarden зашыфраваны. Калі ласка, экспартуйце як незашыфраваны JSON.",kk:"Bitwarden файлы шифрленген. Шифрленбеген JSON ретінде экспорттаңыз.",zh:"Bitwarden 文件已加密。请导出为未加密的 JSON。",ja:"Bitwardenファイルは暗号化されています。暗号化されていないJSONとしてエクスポートしてください。",hi:"Bitwarden फ़ाइल एन्क्रिप्टेड है। कृपया अनएन्क्रिप्टेड JSON के रूप में निर्यात करें।"},card_tags_shown:{en:"Tags are now shown on cards",ru:"Метки отображаются на карточках",ua:"Мітки відображаються на картках",be:"Пазнакі адлюстроўваюцца на картках",kk:"Карточкаларда белгілер көрсетіледі",zh:"卡片标签已显示",ja:"カードにタグを表示するように設定しました",hi:"कार्डों पर टैग अब दिखाई दे रहे हैं"},card_tags_hidden:{en:"Tags are now hidden on cards",ru:"Метки скрыты на карточках",ua:"Мітки приховані на картках",be:"Пазнакі схаваныя на картках",kk:"Карточкаларда белгілер жасырылды",zh:"卡片标签已隐藏",ja:"カードのタグを非表示に設定しました",hi:"कार्डों पर टैग अब छिपा दिए गए हैं"},favicons_shown:{en:"Favicons are now shown on cards",ru:"Иконки сайтов отображаются на карточках",ua:"Іконки сайтів відображаються на картках",be:"Іконкі сайтаў адлюстроўваюцца на картках",kk:"Карточкаларда сайт белгішелері көрсетіледі",zh:"已开启卡片网站图标显示",ja:"カードのアイコンを表示に設定しました",hi:"कार्डों पर वेबसाइट आइकन अब दिखाई दे रहे हैं"},favicons_hidden:{en:"Favicons are now hidden on cards",ru:"Иконки сайтов скрыты на карточках",ua:"Іконки сайтів приховані на картках",be:"Іконкі сайтаў схаваныя на картках",kk:"Карточкаларда сайт белгішелері жасырылды",zh:"已隐藏卡片网站图标",ja:"カードのアイコンを非表示に設定しました",hi:"कार्डों पर वेबसाइट आइकन अब छिपा दिए गए हैं"},external_icons_enabled:{en:"External icon services enabled",ru:"Внешние сервисы иконок включены",ua:"Зовнішні сервіси іконок увімкнено",be:"Вонкавыя сэрвісы іконак уключаны",kk:"Сыртқы белгіше қызметтері қосылды",zh:"外部图标服务已启用",ja:"外部アイコンサービスが有効になりました",hi:"बाहरी आइकन सेवाएं सक्षम"},external_icons_disabled:{en:"External icon services disabled",ru:"Внешние сервисы иконок отключены",ua:"Зовнішні сервіси іконок вимкнено",be:"Вонкавыя сэрвісы іконак адключаны",kk:"Сыртқы белгіше қызметтері өшірілді",zh:"外部图标服务已停用",ja:"外部アイコンサービスが無効になりました",hi:"बाहरी आइकन सेवाएं अक्षम"},favicon_updated:{en:"Favicon updated",ru:"Фавикон успешно обновлён",ua:"Фавікон успішно оновлено",be:"Фавікон паспяхова абноўлены",kk:"Фавикон сәтті жаңартылды",zh:"网站图标已更新",ja:"ファビコンを更新しました",hi:"फ़ेविकॉन सफलतापूर्वक अपडेट किया गया"},favicon_empty_url:{en:"Please enter a valid website URL",ru:"Укажите корректный URL сайта",ua:"Вкажіть коректний URL сайту",be:"Пакажыце карэктны URL сайта",kk:"Сайттың дұрыс URL мекенжайын енгізіңіз",zh:"请输入有效的网站网址",ja:"有効なウェブサイトURLを入力してください",hi:"कृपया एक मान्य वेबसाइट URL दर्ज करें"},favicon_fetch_failed:{en:"Could not fetch favicon for this site",ru:"Не удалось загрузить фавикон сайта",ua:"Не вдалося завантажити фавікон сайту",be:"Не ўдалося загрузіць фавікон сайта",kk:"Сайттың фавиконын жүктеу мүмкін болмады",zh:"无法获取该网站的图标",ja:"このサイトのファビコンを取得できませんでした",hi:"इस साइट के लिए फ़ेविकॉन लोड नहीं हो सका"},fill_required_fields:{en:"Please fill in all required fields",ru:"Заполните обязательные поля",ua:"Заповніть обов'язкові поля",be:"Запоўніце абавязковыя палі",kk:"Міндетті өрістерді толтырыңыз",zh:"请填写所有必填字段",ja:"すべての必須項目を入力してください",hi:"कृपया सभी आवश्यक फ़ील्ड भरें"},vault_migrated_v3:{en:"Vault upgraded to v3. Please save the new recovery key!",ru:"Хранилище обновлено до v3. Сохраните новый ключ восстановления!",ua:"Сховище оновлено до v3. Збережіть новий ключ відновлення!",be:"Сховішча абноўлена да v3. Захавайце новы ключ аднаўлення!",kk:"Қойма v3 нұсқасына жаңартылды. Жаңа қалпына келтіру кілтін сақтаңыз!",zh:"保管库已升级至 v3。请保存新的恢复密钥！",ja:"保管庫が v3 にアップグレードされました。新しい復元キーを保存してください！",hi:"वॉल्ट v3 में अपग्रेड हो गया। कृपया नई पुनर्प्राप्ति कुंजी सहेजें!"},access_restored:{en:"Access restored! Save your new recovery key.",ru:"Доступ восстановлен! Сохраните новый ключ восстановления.",ua:"Доступ відновлено! Збережіть новий ключ відновлення.",be:"Доступ адноўлены! Захавайце новы ключ аднаўлення.",kk:"Қолжетімділік қалпына келтірілді! Жаңа кілтті сақтаңыз.",zh:"访问权限已恢复！请保存您的新恢复密钥。",ja:"アクセスが復元されました！新しい復元キーを保存してください。",hi:"एक्सेस पुनर्स्थापित हो गया! अपनी नई कुंजी सहेजें।"},pass_saved_sync:{en:"Saved and synchronized with PASS CLI",ru:"Сохранено и синхронизировано с PASS CLI",ua:"Збережено та синхронізовано з PASS CLI",be:"Захавана і сінхранізавана з PASS CLI",kk:"Сақталды және PASS CLI-мен үндестірілді",zh:"已保存并与 PASS CLI 同步",ja:"保存し、PASS CLI と同期しました",hi:"सहेजा गया और PASS CLI के साथ समन्वयित किया गया"},pass_saved:{en:"Password saved",ru:"Пароль сохранён",ua:"Пароль збережено",be:"Пароль захаваны",kk:"Құпия сөз сақталды",zh:"密码已保存",ja:"パスワードを保存しました",hi:"पासवर्ड सहेजा गया"},delete_confirm:{en:"Are you sure you want to delete this password?",ru:"Вы уверены, что хотите удалить этот пароль?",ua:"Ви впевнені, що хочете видалити цей пароль?",be:"Ці сапраўды вы хочаце выдаліць гэты пароль?",kk:"Бұл құпия сөзді жойғыңыз келетініне сенімдісіз бе?",zh:"确定要删除此密码吗？",ja:"このパスワードを削除してもよろしいですか？",hi:"क्या आप वाकई यह पासवर्ड हटाना चाहते हैं?"},pass_deleted_sync:{en:"Deleted from storage and PASS CLI",ru:"Удалено из хранилища и PASS CLI",ua:"Видалено зі сховища та PASS CLI",be:"Выдалена са сховішча і PASS CLI",kk:"Қоймадан және PASS CLI-ден жойылды",zh:"已从保管库和 PASS CLI 中删除",ja:"保管庫および PASS CLI から削除しました",hi:"वॉल्ट और PASS CLI से हटाया गया"},pass_deleted:{en:"Password deleted",ru:"Пароль удалён",ua:"Пароль видалено",be:"Пароль выдалены",kk:"Құпия сөз жойылды",zh:"密码已删除",ja:"パスワードを削除しました",hi:"पासवर्ड हटा दिया गया"},phishing_warning:{en:`Warning! Potential phishing:
This credential is for "{itemDomain}", but active tab is "{tabDomain}".

Autofill anyway?`,ru:`Внимание! Возможен фишинг:
Запись предназначена для «{itemDomain}», а активная страница — «{tabDomain}».

Заполнить форму всё равно?`,ua:`Увага! Можливий фішинг:
Запис призначений для «{itemDomain}», а активна сторінка — «{tabDomain}».

Заповнити форму все одно?`,be:`Увага! Магчымы фішынг:
Запіс прызначаны для «{itemDomain}», а актыўная старонка — «{tabDomain}».

Запоўніць форму ўсё адно?`,kk:`Назар аударыңыз! Фишинг қаупі бар:
Жазба «{itemDomain}» үшін, ал белсенді бет — «{tabDomain}».

Бәрібір толтыру керек пе?`,zh:`警告！疑似网络钓鱼：
该密码适用于“{itemDomain}”，但当前页面是“{tabDomain}”。

仍要自动填充吗？`,ja:`警告！フィッシングの可能性があります：
この情報は「{itemDomain}」用ですが、現在のページは「{tabDomain}」です。

入力を続行しますか？`,hi:`चेतावनी! संभावित फ़िशिंग:
यह क्रेडेंशियल "{itemDomain}" के लिए है, लेकिन सक्रिय टैब "{tabDomain}" है।

क्या फिर भी ऑटोफ़िल करें?`},tag_exists:{en:"A tag with this name already exists",ru:"Метка с таким именем уже существует",ua:"Мітка з такою назвою вже існує",be:"Пазнака з такой назвай ужо існуе",kk:"Бұл атаумен белгі бар",zh:"同名标签已存在",ja:"同じ名前のタグが既に存在します",hi:"इस नाम का टैग पहले से मौजूद है"},tag_added:{en:'Tag "{name}" added',ru:"Метка «{name}» добавлена",ua:"Мітку «{name}» додано",be:"Пазнака «{name}» дададзена",kk:"«{name}» белгісі қосылды",zh:"标签“{name}”已添加",ja:"タグ「{name}」を追加しました",hi:'टैग "{name}" जोड़ा गया'},tag_deleted:{en:'Tag "{name}" deleted',ru:"Метка «{name}» удалена",ua:"Мітку «{name}» видалено",be:"Пазнака «{name}» выдалена",kk:"«{name}» белгісі жойылды",zh:"标签“{name}”已删除",ja:"タグ「{name}」を削除しました",hi:'टैग "{name}" हटा दिया गया'},db_created:{en:'Database "{name}" created',ru:"База «{name}» создана",ua:"Базу «{name}» створено",be:"База «{name}» створана",kk:"«{name}» қоймасы жасалды",zh:"数据库“{name}”已创建",ja:"データベース「{name}」を作成しました",hi:'डेटाबेस "{name}" बनाया गया'},db_created_pass:{en:'Database "{name}" created (PASS CLI)',ru:"База «{name}» создана (PASS CLI)",ua:"Базу «{name}» створено (PASS CLI)",be:"База «{name}» створана (PASS CLI)",kk:"«{name}» қоймасы жасалды (PASS CLI)",zh:"数据库“{name}”已创建 (PASS CLI)",ja:"データベース「{name}」を作成しました (PASS CLI)",hi:'डेटाबेस "{name}" बनाया गया (PASS CLI)'},db_deleted:{en:"Database and associated credentials deleted",ru:"База данных и связанные пароли удалены",ua:"Базу даних та пов'язані паролі видалено",be:"База даных і звязаныя паролі выдалены",kk:"Деректер қоры мен оған байланысты құпия сөздер жойылды",zh:"数据库及关联凭证已删除",ja:"データベースと関連するパスワードを削除しました",hi:"डेटाबेस और संबद्ध क्रेडेंशियल हटा दिए गए"},native_checking:{en:"Checking Native Host...",ru:"Проверка Native Host...",ua:"Перевірка Native Host...",be:"Праверка Native Host...",kk:"Native Host тексерілуде...",zh:"正在检查原生主机...",ja:"Native Host を確認中...",hi:"नेटिव होस्ट की जाँच की जा रही है..."},native_connected:{en:"PASS connected: found {count} entries",ru:"PASS подключен: найдено {count} записей",ua:"PASS підключено: знайдено {count} записів",be:"PASS падключаны: знойдзена {count} запісаў",kk:"PASS қосылды: {count} жазба табылды",zh:"PASS 已连接：找到 {count} 条条目",ja:"PASS が接続されました: {count} 件のエントリが見つかりました",hi:"PASS कनेक्ट हो गया: {count} प्रविष्टियाँ मिलीं"},native_unresponsive:{en:"Native Host not responding: run ./install.sh",ru:"Native Host не отвечает: требуется ./install.sh",ua:"Native Host не відповідає: потрібен ./install.sh",be:"Native Host не адказвае: патрабуецца ./install.sh",kk:"Native Host жауап бермейді: ./install.sh орындау қажет",zh:"原生主机未响应：请运行 ./install.sh",ja:"Native Host が応答しません: ./install.sh を実行してください",hi:"नेटिव होस्ट प्रतिक्रिया नहीं दे रहा है: ./install.sh चलाएं"},theme_dark_enabled:{en:"Dark theme enabled",ru:"Включена тёмная тема",ua:"Увімкнено темну тему",be:"Уключана цёмная тэма",kk:"Күңгірт тақырып қосылды",zh:"已启用深色主题",ja:"ダークテーマを有効にしました",hi:"डार्क थीम सक्षम"},theme_light_enabled:{en:"Light theme enabled",ru:"Включена светлая тема",ua:"Увімкнено світлу тему",be:"Уключана светлая тэма",kk:"Ашық тақырып қосылды",zh:"已启用浅色主题",ja:"ライトテーマを有効にしました",hi:"लाइट थीम सक्षम"},csv_header_err:{en:"Could not recognize CSV headers (requires at least Title/Name or Password)",ru:"Не удалось распознать заголовки CSV (требуются хотя бы Title/Name или Password)",ua:"Не вдалося розпізнати заголовки CSV (потрібні хоча б Title/Name або Password)",be:"Не атрымалася распазнаць загалоўкі CSV (патрабуюцца хаця б Title/Name або Password)",kk:"CSV тақырыптары анықталмады (кемінде Title/Name немесе Password қажет)",zh:"无法识别 CSV 标题（至少需要 Title/Name 或 Password）",ja:"CSVヘッダーを認識できませんでした（Title/NameまたはPasswordが必要です）",hi:"CSV हेडर पहचाने नहीं जा सके (कम से कम Title/Name या Password आवश्यक है)"},json_invalid_format:{en:"Unknown JSON file format",ru:"Неизвестный формат JSON файла",ua:"Невідомий формат JSON файлу",be:"Невядомы фармат файла JSON",kk:"Белгісіз JSON файл пішімі",zh:"未知的 JSON 文件格式",ja:"不明なJSONファイル形式です",hi:"अज्ञात JSON फ़ाइल प्रारूप"},import_error:{en:"Import error",ru:"Ошибка при импорте",ua:"Помилка при імпорті",be:"Памылка пры імпарце",kk:"Импорттау қатесі",zh:"导入错误",ja:"インポートエラー",hi:"आयात त्रुटि"},pass_syncing:{en:"Syncing with ~/.password-store...",ru:"Синхронизация с ~/.password-store...",ua:"Синхронізація з ~/.password-store...",be:"Сінхранізацыя з ~/.password-store...",kk:"~/.password-store қалтасымен үндестірілуде...",zh:"正在与 ~/.password-store 同步...",ja:"~/.password-store と同期中...",hi:"~/.password-store के साथ सिंक हो रहा है..."},pass_sync_loaded:{en:"Loaded {count} entries from pass",ru:"Загружено {count} записей из pass",ua:"Завантажено {count} записів з pass",be:"Загружана {count} запісаў з pass",kk:"pass-тен {count} жазба жүктелді",zh:"从 pass 加载了 {count} 个条目",ja:"passから {count} 件のエントリを読み込みました",hi:"pass से {count} प्रविष्टियां लोड की गईं"},pass_conn_err:{en:`PASS CLI connection error:
{message}

To connect, run in terminal:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,ru:`Ошибка подключения к PASS CLI:
{message}

Для подключения выполните в терминале:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,ua:`Помилка підключення до PASS CLI:
{message}

Для підключення виконайте в терміналі:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,be:`Памылка падключэння да PASS CLI:
{message}

Для падключэння выканайце ў тэрмінале:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,kk:`PASS CLI қосылу қатесі:
{message}

Қосылу үшін терминалда орындаңыз:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,zh:`PASS CLI 连接错误：
{message}

如需连接，请在终端中运行：
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,ja:`PASS CLI 接続エラー:
{message}

接続するにはターミナルで実行してください:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`,hi:`PASS CLI कनेक्शन त्रुटि:
{message}

कनेक्ट करने के लिए टर्मिनल में चलाएं:
cd /Users/dima/Projects/SimplePassManager/native-host && ./install.sh`},csv_import_error:{en:"CSV import error",ru:"Ошибка импорта CSV",ua:"Помилка імпорту CSV",be:"Памылка імпарту CSV",kk:"CSV импорттау қатесі",zh:"CSV 导入错误",ja:"CSVインポートエラー",hi:"CSV आयात त्रुटि"},tabs_permission_denied:{en:"Tab access was not granted",ru:"Доступ к вкладкам не был предоставлен",ua:"Доступ до вкладок не було надано",be:"Доступ да ўкладак не быў прадастаўлены",kk:"Қойындыларға қатынау берілмеді",zh:"未授予标签页访问权限",ja:"タブへのアクセスが許可されませんでした",hi:"टैब एक्सेस नहीं दिया गया"},native_permission_denied:{en:"Native Messaging permission was not granted",ru:"Разрешение на работу с Native Messaging не предоставлено",ua:"Дозвіл на роботу з Native Messaging не надано",be:"Дазвол на працу з Native Messaging не прадастаўлены",kk:"Native Messaging қолдануға рұқсат берілмеді",zh:"未授予本地消息通信 (Native Messaging) 权限",ja:"Native Messaging の権限が付与されませんでした",hi:"नेटिव मैसेजिंग अनुमति नहीं दी गई"}},ua={title:{en:"UNIX PASS CLI Connection",ru:"Подключение UNIX PASS CLI",ua:"Підключення UNIX PASS CLI",be:"Падключэнне UNIX PASS CLI",kk:"UNIX PASS CLI қосылымы",zh:"UNIX PASS CLI 连接",ja:"UNIX PASS CLI 接続",hi:"UNIX PASS CLI कनेक्शन"},desc:{en:"SimplePass can work directly with your local ~/.password-store via Native Messaging.",ru:"SimplePass может работать напрямую с вашим локальным хранилищем ~/.password-store через Native Messaging.",ua:"SimplePass може працювати безпосередньо з вашим локальним сховищем ~/.password-store через Native Messaging.",be:"SimplePass можа працаваць напрамую з вашым лакальным сховішчам ~/.password-store праз Native Messaging.",kk:"SimplePass сіздің жергілікті ~/.password-store қоймаңызбен Native Messaging арқылы тікелей жұмыс істей алады.",zh:"SimplePass 可以通过原生消息直接与您的本地 ~/.password-store 协同工作。",ja:"SimplePass は Native Messaging を介してローカルの ~/.password-store と直接連携できます。",hi:"SimplePass नेटिव मैसेजिंग के माध्यम से आपके स्थानीय ~/.password-store के साथ सीधे काम कर सकता है।"},step1:{en:"1. Install pass and GPG (if not installed):",ru:"1. Установите pass и GPG (если не установлены):",ua:"1. Встановіть pass та GPG (якщо не встановлені):",be:"1. Усталюйце pass і GPG (калі не ўсталяваны):",kk:"1. pass және GPG орнатыңыз (орнатылмаған болса):",zh:"1. 安装 pass 和 GPG（如果尚未安装）：",ja:"1. pass と GPG をインストールします（未インストールの場合）:",hi:"1. pass और GPG स्थापित करें (यदि पहले से स्थापित नहीं है):"},step2:{en:"2. Run Native Host registration script:",ru:"2. Запустите скрипт регистрации Native Host:",ua:"2. Запустіть скрипт реєстрації Native Host:",be:"2. Запусціце скрыпт рэгістрацыі Native Host:",kk:"2. Native Host тіркеу сценарийін іске қосыңыз:",zh:"2. 运行原生主机注册脚本：",ja:"2. Native Host 登録スクリプトを実行します:",hi:"2. नेटिव होस्ट पंजीकरण स्क्रिप्ट चलाएं:"},step3:{en:"3. Verify connection:",ru:"3. Проверьте подключение:",ua:"3. Перевірте підключення:",be:"3. Праверце падключэнне:",kk:"3. Қосылымды тексеріңіз:",zh:"3. 验证连接：",ja:"3. 接続を確認:",hi:"3. कनेक्शन सत्यापित करें:"},step3_desc:{en:'After running the script, restart the extension or click "Check Connection" in Settings.',ru:"После запуска скрипта перезапустите расширение или нажмите «Проверить подключение» в настройках.",ua:"Після запуску скрипту перезапустіть розширення або натисніть «Перевірити підключення» у налаштуваннях.",be:"Пасля запуску скрыпта перазапусціце пашырэнне або націсніце «Праверыць падключэнне» у наладах.",kk:"Сценарийді іске қосқаннан кейін кеңейтімді қайта қосыңыз немесе параметрлерде «Қосылымды тексеру» түймесін басыңыз.",zh:"运行脚本后，重启扩展或在设置中点击“检查连接”。",ja:"スクリプト実行後、拡張機能を再起動するか、設定で「接続を確認」をクリックしてください。",hi:'स्क्रिप्ट चलाने के बाद, एक्सटेंशन को पुनः आरंभ करें या सेटिंग्स में "कनेक्शन जांचें" पर क्लिक करें।'},got_it:{en:"Got it",ru:"Понятно",ua:"Зрозуміло",be:"Зразумела",kk:"Түсінікті",zh:"我知道了",ja:"了解",hi:"समझ गया"}},ma={title:{en:"Trash",ru:"Корзина",ua:"Кошик",be:"Сметніца",kk:"Себет",zh:"回收站",ja:"ゴミ箱",hi:"कचरा पेटी"},desc:{en:"Deleted items are stored for 30 days before permanent deletion",ru:"Удалённые записи хранятся 30 дней перед окончательным удалением",ua:"Видалені записи зберігаються 30 днів перед остаточним видаленням",be:"Выдаленыя запісы захоўваюцца 30 дзён перад канчатковым выдаленнем",kk:"Жойылған жазбалар біржола жойылғанға дейін 30 күн сақталады",zh:"删除的密码保留 30 天后自动彻底删除",ja:"削除された項目は30日間保持された後、完全に削除されます",hi:"हटाए गए आइटम स्थायी रूप से हटाए जाने से पहले 30 दिनों तक रखे जाते हैं"},empty:{en:"Trash is empty",ru:"Корзина пуста",ua:"Кошик порожній",be:"Сметніца пустая",kk:"Себет бос",zh:"回收站为空",ja:"ゴミ箱は空です",hi:"कचरा पेटी खाली है"},empty_btn:{en:"Empty Trash",ru:"Очистить корзину",ua:"Очистити кошик",be:"Ачысціць сметніцу",kk:"Себетті тазалау",zh:"清空回收站",ja:"ゴミ箱を空にする",hi:"कचरा पेटी खाली करें"},empty_confirm:{en:"Are you sure you want to permanently delete all items in trash?",ru:"Вы уверены, что хотите окончательно удалить все записи из корзины?",ua:"Ви впевнені, що хочете остаточно видалити всі записи з кошика?",be:"Вы ўпэўненыя, што хочаце канчаткова выдаліць усе запісы са сметніцы?",kk:"Себеттегі барлық жазбаларды біржола жойғыңыз келетініне сенімдісіз бе?",zh:"确定要彻底删除回收站中的所有密码吗？",ja:"ゴミ箱内のすべてのアイテムを完全に削除してもよろしいですか？",hi:"क्या आप वाकई कचरा पेटी के सभी आइटम स्थायी रूप से हटाना चाहते हैं?"},restore_btn:{en:"Restore",ru:"Восстановить",ua:"Відновити",be:"Аднавіць",kk:"Қалпына келтіру",zh:"恢复",ja:"復元",hi:"पुनर्स्थापित करें"},delete_perm_btn:{en:"Delete permanently",ru:"Удалить навсегда",ua:"Видалити назавжди",be:"Выдаліць назаўжды",kk:"Біржола жою",zh:"永久删除",ja:"完全に削除",hi:"स्थायी रूप से हटाएं"},delete_perm_confirm:{en:"Permanently delete this entry? This action cannot be undone.",ru:"Окончательно удалить эту запись? Действие нельзя отменить.",ua:"Остаточно видалити цей запис? Дію не можна скасувати.",be:"Канчаткова выдаліць гэты запіс? Дзеянне нельга адмяніць.",kk:"Бұл жазбаны біржола жою керек пе? Бұл әрекетті қайтару мүмкін емес.",zh:"彻底删除此条目？此操作无法撤消。",ja:"このエントリを完全に削除しますか？この操作は元に戻せません。",hi:"क्या इस प्रвиष्टि को स्थायी रूप से हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।"},days_left:{en:"{count} days left",ru:"Осталось {count} дн.",ua:"Залишилося {count} дн.",be:"Засталося {count} дн.",kk:"{count} күн қалды",zh:"剩余 {count} 天",ja:"残り {count} 日",hi:"{count} दिन शेष"},restored_toast:{en:"Entry restored from trash",ru:"Запись восстановлена из корзины",ua:"Запис відновлено з кошика",be:"Запіс адноўлены са сметніцы",kk:"Жазба себеттен қалпына келтірілді",zh:"密码已从回收站恢复",ja:"ゴミ箱から復元しました",hi:"प्रविष्टि कचरा पेटी से पुनर्स्थापित की गई"},deleted_toast:{en:"Moved to trash (30 days)",ru:"Перемещено в корзину (на 30 дней)",ua:"Переміщено в кошик (на 30 днів)",be:"Перанесена ў сметніцу (на 30 дзён)",kk:"Себетке көшірілді (30 күнге)",zh:"已移至回收站（保留30天）",ja:"ゴミ箱に移動しました（30日間保持）",hi:"कचरा पेटी में ले जाया गया (30 दिन)"},perm_deleted_toast:{en:"Entry permanently deleted",ru:"Запись окончательно удалена",ua:"Запис остаточно видалено",be:"Запіс канчаткова выдалены",kk:"Жазба біржола жойылды",zh:"密码已彻底删除",ja:"完全に削除されました",hi:"प्रविष्टि स्थायी रूप से हटा दी गई"},emptied_toast:{en:"Trash emptied",ru:"Корзина очищена",ua:"Кошик очищено",be:"Сметніца ачышчана",kk:"Себет тазартылды",zh:"回收站已清空",ja:"ゴミ箱を空にしました",hi:"कचरा पेटी खाली कर दी गई"}},ga={title:{en:"Security",ru:"Безопасность",ua:"Безпека",be:"Бяспека",kk:"Қауіпсіздік",zh:"安全",ja:"セキュリティ",hi:"सुरक्षा"},experimental:{en:"experimental",ru:"экспериментально",ua:"експериментально",be:"эксперыментальна",kk:"тәжірибелік",zh:"实验性",ja:"実験的",hi:"प्रायोगिक"},run_audit_btn:{en:"Quick Audit",ru:"Быстрый аудит",ua:"Швидкий аудит",be:"Хуткі аўдыт",kk:"Жылдам аудит",zh:"快速审计",ja:"クイック監査",hi:"त्वरित ऑडिट"},health_score:{en:"Vault Health Score",ru:"Индекс безопасности",ua:"Індекс безпеки",be:"Індэкс бяспекі",kk:"Қауіпсіздік индексі",zh:"密码库健康评分",ja:"セキュリティスコア",hi:"सुरक्षा स्कोर"},audited_count:{en:"Audited: {count} passwords",ru:"Проверено: {count} паролей",ua:"Перевірено: {count} паролів",be:"Праверана: {count} пароляў",kk:"Тексерілді: {count} құпия сөз",zh:"已审计：{count} 个密码",ja:"監査済み: {count} 件",hi:"ऑडिट किया गया: {count} पासवर्ड"},legend_title:{en:"Security Status Legend & Color Codes",ru:"Легенда цветовых обозначений статусов",ua:"Легенда кольорових позначень статусів",be:"Легенда колеравых пазначэнняў статусаў",kk:"Түсті белгілер мен күйлердің сипаттамасы",zh:"安全状态颜色说明",ja:"ステータスの凡例と色分け",hi:"सुरक्षा स्थिति लीजेंड और रंग कोड"},legend_reused_title:{en:"Red (Reused)",ru:"Красный (Дубликаты)",ua:"Червоний (Дублікати)",be:"Чырвоны (Дублікаты)",kk:"Қызыл (Қайталанатын)",zh:"红色（重复使用）",ja:"赤（再利用）",hi:"लाल (पुन: उपयोग)"},legend_reused_desc:{en:"Identical password used across multiple accounts. High risk if one service leaks.",ru:"Одинаковый пароль на нескольких сайтах. Высокий риск взлома всех аккаунтов при утечке одной базы.",ua:"Однаковий пароль на кількох сайтах. Високий ризик зламу всіх облікових записів при витоку однієї бази.",be:"Аднолькавы пароль на некалькіх сайтах. Высокая рызыка ўзлому пры ўцечцы адной базы.",kk:"Бірнеше сайттағы бірдей құпия сөз. Бір дерекқор ағып кетсе барлық есептік жазба қауіпке түседі.",zh:"在多个账户中使用相同密码。如果某服务泄露，其他账户风险极高。",ja:"複数のアカウントで同じパスワードが使い回されています。1つのサービスが漏洩すると高リスクです。",hi:"एकाधिक खातों में समान पासवर्ड का उपयोग। यदि एक सेवा लीक होती है तो अत्यधिक जोखिम।"},legend_weak_title:{en:"Orange (Weak)",ru:"Оранжевый (Слабый)",ua:"Помаранчевий (Слабкий)",be:"Аранжавы (Слабкі)",kk:"Қызғылт сары (Әлсіз)",zh:"橙色（弱密码）",ja:"オレンジ（脆弱）",hi:"नारंगी (कमजोर)"},legend_weak_desc:{en:"Short or simple password. Easy to crack via dictionary attack.",ru:"Короткий (<10 симв.) или простой пароль. Легко подбирается по словарю.",ua:"Короткий (<10 симв.) або простий пароль. Легко підбирається за словником.",be:"Кароткі (<10 сімв.) або просты пароль. Лёгка падбіраецца па слоўніку.",kk:"Қысқа (<10 таңба) немесе қарапайым құпия сөз. Сөздік бойынша оңай табылады.",zh:"过短（<10个字符）或过于简单。容易被字典攻击破解。",ja:"短すぎる（10文字未満）または単純なパスワード。辞書攻撃で容易に突破されます。",hi:"छोटा (<10 वर्ण) या सरल पासवर्ड। शब्दकोश हमले के माध्यम से आसानी से क्रैक हो सकता है।"},legend_old_title:{en:"Yellow (Stale)",ru:"Жёлтый (Устаревший)",ua:"Жовтий (Застарілий)",be:"Жоўты (Састарэлы)",kk:"Сары (Ескірген)",zh:"黄色（旧密码）",ja:"黄（古い）",hi:"पीला (पुराना)"},legend_old_desc:{en:"Password has not been updated in over 6 months.",ru:"Пароль не обновлялся более 6 месяцев.",ua:"Пароль не оновлювався понад 6 місяців.",be:"Пароль не абнаўляўся больш за 6 месяцаў.",kk:"Құпия сөз 6 айдан астам уақыт бойы жаңартылмаған.",zh:"密码已超过 6 个月未更换。",ja:"パスワードが6か月以上変更されていません。",hi:"पासवर्ड 6 महीने से अधिक समय से अपडेट नहीं किया गया है।"},legend_strong_title:{en:"Green (Strong)",ru:"Зелёный (Надёжный)",ua:"Зелений (Надійний)",be:"Зялёны (Надзейны)",kk:"Жасыл (Сенімді)",zh:"绿色（强密码）",ja:"緑（強力）",hi:"हरा (मजबूत)"},legend_strong_desc:{en:"Unique, high-entropy password with letters, digits, and symbols.",ru:"Уникальный сложный пароль высокой энтропии с цифрами и символами.",ua:"Унікальний складний пароль високої ентропії з цифрами та символами.",be:"Унікальны складаны пароль высокай энтапіі з лічбамі і сімваламі.",kk:"Әріптер, сандар және белгілерден тұратын бірегей, күрделі құпия сөз.",zh:"唯一且具有高熵的强密码，包含字母、数字和符号。",ja:"英数字や記号を含むユニークで安全性の高いパスワード。",hi:"अक्षरों, अंकों और प्रतीकों के साथ अद्वितीय, मजबूत पासवर्ड।"},search_placeholder:{en:"Search audited passwords...",ru:"Поиск по паролям...",ua:"Пошук за паролями...",be:"Пошук па паролях...",kk:"Құпия сөздер бойынша іздеу...",zh:"搜索密码...",ja:"パスワードを検索...",hi:"ऑडिट किए गए पासवर्ड खोजें..."},filter_all:{en:"All",ru:"Все",ua:"Всі",be:"Усе",kk:"Барлығы",zh:"全部",ja:"すべて",hi:"सभी"},filter_reused:{en:"Reused",ru:"Повторы",ua:"Повтори",be:"Паўторы",kk:"Қайталанатындар",zh:"重复",ja:"使い回し",hi:"पुन: उपयोग"},filter_weak:{en:"Weak",ru:"Слабые",ua:"Слабкі",be:"Слабкія",kk:"Әлсіз",zh:"弱密码",ja:"脆弱",hi:"कमजोर"},filter_old:{en:"Stale",ru:"Устаревшие",ua:"Застарілі",be:"Састарэлыя",kk:"Ескірген",zh:"旧密码",ja:"古い",hi:"पुराने"},filter_strong:{en:"Strong",ru:"Надёжные",ua:"Надійні",be:"Надзейныя",kk:"Сенімді",zh:"强密码",ja:"強力",hi:"मजबूत"},risk_reused:{en:"Reused ({count})",ru:"Повтор ({count})",ua:"Повтор ({count})",be:"Паўтор ({count})",kk:"Қайталанған ({count})",zh:"重复 ({count})",ja:"使い回し ({count})",hi:"पुन: उपयोग ({count})"},risk_weak:{en:"Weak",ru:"Слабый",ua:"Слабкий",be:"Слабкі",kk:"Әлсіз",zh:"弱密码",ja:"脆弱",hi:"कमजोर"},risk_old:{en:"Stale",ru:"Устаревший",ua:"Застарілий",be:"Састарэлы",kk:"Ескірген",zh:"旧密码",ja:"古い",hi:"पुराना"},risk_strong:{en:"Safe",ru:"Надёжный",ua:"Надійний",be:"Надзейны",kk:"Сенімді",zh:"安全",ja:"安全",hi:"सुरक्षित"},fix_pwd_btn:{en:"Change",ru:"Изменить",ua:"Змінити",be:"Змяніць",kk:"Өзгерту",zh:"修改",ja:"変更",hi:"बदलें"},no_issues_found:{en:"No passwords found in this filter",ru:"Паролей по этому фильтру не найдено",ua:"Паролів за цим фільтром не знайдено",be:"Пароляў па гэтым фільтры не знойдзена",kk:"Бұл сүзгі бойынша құпия сөздер табылған жоқ",zh:"在此筛选条件下未找到密码",ja:"このフィルターに一致するパスワードはありません",hi:"इस फ़िल्टर में कोई पासवर्ड नहीं मिला"},filter_empty_hint:{en:"Try changing tag, search query, or risk level filter",ru:"Попробуйте изменить тег, строку поиска или фильтр риска",ua:"Спробуйте змінити тег, рядок пошуку або фільтр ризику",be:"Паспрабуйце змяніць тэг, радок пошуку або фільтр рызыкі",kk:"Тегті, іздеу жолын немесе қауіп сүзгісін өзгертіп көріңіз",zh:"尝试更改标签、搜索词或风险级别筛选",ja:"タグや検索キーワード、フィルターを変更してみてください",hi:"टैग, खोज क्वेरी या जोखिम फ़िल्टर बदलने का प्रयास करें"},audit_completed:{en:"Audit completed: score {score}%, {issues} issues found",ru:"Аудит завершён: индекс {score}%, найдено {issues} замечаний",ua:"Аудит завершено: індекс {score}%, знайдено {issues} зауважень",be:"Аўдыт завершаны: індэкс {score}%, знойдзена {issues} праблем",kk:"Аудит аяқталды: индекс {score}%, {issues} мәселе табылды",zh:"审计完成：评分 {score} %，发现 {issues} 个问题",ja:"監査完了: スコア {score}%、{issues} 件の改善点が見つかりました",hi:"ऑडिट पूर्ण: स्कोर {score}%, {issues} समस्याएं पाई गईं"}},ha={app:Zs,nav:ea,footer:ta,vault:sa,generator:aa,form:na,settings:oa,auth:ra,recovery_modal:ia,delete_modal:ca,project_switcher:la,categories:da,toasts:pa,pass_modal:ua,trash:ma,security:ga},Ft=["en","ru","ua","be","kk","zh","ja","hi"],It="en";function fa(e=typeof navigator<"u"?navigator.language:"en"){if(!e)return It;let t=String(e).slice(0,2).toLowerCase();return t==="uk"&&(t="ua"),Ft.includes(t)?t:It}const _t=[{code:"ru",name:"Русский",flag:"🇷🇺"},{code:"en",name:"English",flag:"🇬🇧"},{code:"ua",name:"Українська",flag:"🇺🇦"},{code:"be",name:"Беларуская",flag:"🇧🇾"},{code:"kk",name:"Қазақша",flag:"🇰🇿"},{code:"zh",name:"中文",flag:"🇨🇳"},{code:"ja",name:"日本語",flag:"🇯🇵"},{code:"hi",name:"हिन्दी",flag:"🇮🇳"}];let Ut=It;function os(e){e&&Ft.includes(e.toLowerCase())&&(Ut=e.toLowerCase())}function va(){return Ut}function s(e,t={}){if(!e)return"";const a=e.split(".");let o=ha;for(const r of a)if(o&&typeof o=="object"&&r in o)o=o[r];else{o=null;break}let i="";return o&&typeof o=="object"?i=o[Ut]||o.en||o.ru||e:typeof o=="string"?i=o:i=e,t&&typeof t=="object"&&Object.entries(t).forEach(([r,d])=>{i=i.replace(new RegExp(`\\{${r}\\}`,"g"),d??"")}),i}function C(e){return typeof e!="string"?"":e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function S(e,t=2200){let a=document.getElementById("sp-toast");a||(a=document.createElement("div"),a.id="sp-toast",a.style.cssText=`
      position: fixed; bottom: 50px; left: 50%; transform: translateX(-50%);
      background: var(--text-main); color: var(--bg-main); font-size: 12px; font-weight: 600;
      border: 1px solid var(--border-subtle);
      padding: 8px 16px; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.3);
      z-index: 9999; transition: opacity 0.2s ease; pointer-events: none;
    `,document.body.appendChild(a)),a.innerText=e,a.style.opacity="1",clearTimeout(a._timer),a._timer=setTimeout(()=>{a.style.opacity="0"},t)}function oe(e,t,a){const o=document.getElementById(e),i=document.getElementById(t);o&&o.classList.add("has-error"),i&&(i.innerText=a,i.style.display="block")}function ft(){document.querySelectorAll(".sp-field-error").forEach(e=>{e.innerText="",e.style.display="none"}),document.querySelectorAll(".sp-input.has-error").forEach(e=>{e.classList.remove("has-error")})}function rs(e){const t=e==="dark"?"dark":"light";document.body.classList.remove("theme-light","theme-dark"),document.body.classList.add(`theme-${t}`)}function ot(e,t){const a=document.getElementById(e),o=document.getElementById(t);if(!a||!o)return;const i=()=>{const r=a.value||"";if(!r){o.innerHTML="";return}const d=ns(r);let u="var(--danger, #ef4444)",l="25%",p=s("generator.weak");d>=4?(u="var(--success, #10b981)",l="100%",p=s("generator.strong")):d>=2&&(u="#f59e0b",l="60%",p=s("generator.medium")),o.innerHTML=`
      <div style="margin-top: 4px; display: flex; flex-direction: column; gap: 2px;">
        <div style="height: 3px; width: 100%; background: var(--border-subtle); border-radius: 2px; overflow: hidden;">
          <div style="height: 100%; width: ${l}; background: ${u}; transition: width 0.2s ease, background 0.2s ease;"></div>
        </div>
        <div style="font-size: 10px; color: ${u}; font-weight: 500; text-align: right;">${p}</div>
      </div>
    `};a.addEventListener("input",i),i()}function is(e){if(!e||typeof e!="string")return null;const t=e.trim();if(!t||t==="about:blank"||t.startsWith("chrome")||t.startsWith("edge")||t==="newtab")return null;const a=Xt(t),r=t.startsWith("http://")||t.startsWith("https://")?t:`${a?"http://":"https://"}${t}`;try{const d=new URL(r),u=d.protocol,l=d.hostname.replace(/^www\./,"").toLowerCase(),p=d.port&&d.port!=="80"&&d.port!=="443"?d.port:"",m=p?`${l}:${p}`:l,h=`${u}//${d.host}`;return{url:d.href,origin:h,protocol:u,hostname:l,port:p,host:m,isLocal:a,pathname:d.pathname}}catch{const u=t.split("/")[0].replace(/^www\./,"").toLowerCase(),l=u.split(":");return{url:`http://${u}`,origin:`http://${u}`,protocol:"http:",hostname:l[0],port:l[1]||"",host:u,isLocal:a,pathname:"/"}}}async function ya(e,t=""){if(!e)return null;let a=e.type||"";if(!a||a==="application/octet-stream"||a==="text/plain"){const o=(t||"").toLowerCase();o.includes(".svg")?a="image/svg+xml":o.includes(".ico")?a="image/x-icon":o.includes(".png")?a="image/png":o.includes(".webp")?a="image/webp":a="image/png"}if(typeof FileReader<"u")return new Promise((o,i)=>{const r=new FileReader;r.onloadend=()=>{let d=r.result;typeof d=="string"&&a&&!d.startsWith(`data:${a}`)&&(d=d.replace(/^data:[^;]*;/,`data:${a};`)),o(d)},r.onerror=i,r.readAsDataURL(e)});if(typeof e.arrayBuffer=="function"){const o=await e.arrayBuffer(),i=Buffer.from(o);return`data:${a};base64,${i.toString("base64")}`}return null}async function qe(e,t=3e3){try{const a=typeof AbortController<"u"?new AbortController:null;let o=null;a&&(o=setTimeout(()=>a.abort(),t));const i=await fetch(e,{signal:a?a.signal:void 0,mode:"cors"});if(o&&clearTimeout(o),i&&i.ok){const r=await i.blob();if(r&&r.size>20){const d=await ya(r,e);if(d&&d.startsWith("data:image/"))return d}}}catch{}return null}async function ba(e,t=3e3){try{const a=typeof AbortController<"u"?new AbortController:null;let o=null;a&&(o=setTimeout(()=>a.abort(),t));const i=await fetch(e,{signal:a?a.signal:void 0,mode:"cors"});if(o&&clearTimeout(o),i&&i.ok){const d=[...(await i.text()).matchAll(/<link\s+[^>]*rel=["']([^"']*(?:icon|shortcut\s+icon|apple-touch-icon)[^"']*)["'][^>]*>/gi)];for(const u of d){const p=u[0].match(/href=["']([^"']+)["']/i);if(p&&p[1]){const m=new URL(p[1].trim(),e).href,h=await qe(m,2500);if(h)return h}}}}catch{}return null}async function wa(e,{useExternalServices:t=!1}={}){if(!e||typeof e!="string")return null;if(e.startsWith("data:image/"))return e;const a=is(e);if(!a)return null;if(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.getURL&&!a.isLocal)try{const l=chrome.runtime.getURL("/_favicon/?pageUrl="+encodeURIComponent(a.url||a.origin)+"&size=32"),p=await qe(l,1500);if(p)return p}catch{}if(/\.(ico|svg|png|jpg|jpeg|webp)($|\?)/i.test(a.url)){const l=await qe(a.url);if(l)return l}const o=a.origin,i=a.host,r=a.hostname,d=[`${o}/favicon.ico`,`${o}/favicon.svg`,`${o}/favicon.png`,`${o}/icon.svg`,`${o}/apple-touch-icon.png`];if(!a.port){const l=a.protocol==="https:"?"http:":"https:";d.push(`${l}//${i}/favicon.ico`),d.push(`${l}//${i}/favicon.svg`)}!a.isLocal&&t&&(d.push(`https://www.google.com/s2/favicons?domain=${encodeURIComponent(i)}&sz=64`),d.push(`https://icons.duckduckgo.com/ip3/${encodeURIComponent(i)}.ico`),r!==i&&d.push(`https://www.google.com/s2/favicons?domain=${encodeURIComponent(r)}&sz=64`));for(const l of d){const p=await qe(l,2500);if(p)return p}const u=await ba(a.url||a.origin);return u||null}async function it(e,{forceRefresh:t=!1,activeTabFavIconUrl:a=null,useExternalServices:o=!1}={}){const i=is(e);if(!i)return{domain:ce(e),favicon:null,fromCache:!1};const r=i.host,d=i.hostname;if(!t){const p=await ye(r)||await ye(d);if(p)return{domain:r,favicon:p,fromCache:!0}}if(a)try{const p=await qe(a,2500);if(p)return await st(r,p),d!==r&&await st(d,p),{domain:r,favicon:p,fromCache:!1}}catch{}const u=await wa(e,{useExternalServices:o});if(u)return await st(r,u),d!==r&&await st(d,u),{domain:r,favicon:u,fromCache:!1};const l=await ye(r)||await ye(d);return{domain:r,favicon:l||null,fromCache:!!l,failed:!u}}function Rt(){return typeof chrome<"u"&&!!chrome.permissions}async function Ct(e){return Rt()?new Promise(t=>{try{chrome.permissions.contains({permissions:[e]},a=>{var o;if((o=chrome.runtime)!=null&&o.lastError){t(!1);return}t(!!a)})}catch{t(!1)}}):!1}async function Me(e){return Rt()?new Promise(t=>{try{chrome.permissions.request({permissions:[e]},a=>{var o;if((o=chrome.runtime)!=null&&o.lastError){t(!1);return}t(!!a)})}catch{t(!1)}}):!1}async function ka(e){return!Rt()||!Array.isArray(e)||e.length===0?!1:new Promise(t=>{try{chrome.permissions.request({origins:e},a=>{var o;if((o=chrome.runtime)!=null&&o.lastError){t(!1);return}t(!!a)})}catch{t(!1)}})}function _a(e){if(!e)return[];const t=e.trim().toLowerCase().replace(/^https?:\/\//,"").split("/")[0].split(":")[0];return!t||t==="about:blank"||t.includes("localhost")||t.startsWith("127.")?[]:[`https://${t}/*`,`https://*.${t}/*`,`http://${t}/*`]}const xa="com.simplepass.pass_host";async function vt(e,t={},a=6e3){return typeof chrome<"u"&&chrome.permissions&&!await Ct("nativeMessaging")?{ok:!1,permissionRequired:!0,errorCode:"permission_required",error:"Permission nativeMessaging is required"}:new Promise(o=>{if(typeof chrome>"u"||!chrome.runtime||!chrome.runtime.sendNativeMessage){o({ok:!1,notFound:!0,errorCode:"native_api_unavailable",error:"Chrome Native Messaging API is not available in current environment"});return}let i=!1;const r=setTimeout(()=>{i||(i=!0,o({ok:!1,timeout:!0,errorCode:"native_timeout",error:"Native Messaging Host response timed out (6s)"}))},a);try{chrome.runtime.sendNativeMessage(xa,{action:e,...t},d=>{if(i)return;clearTimeout(r),i=!0;const u=chrome.runtime.lastError;if(u){const l=u.message||"Native Messaging Host error";o({ok:!1,errorCode:"native_host_error",error:l,notFound:l.includes("not found")||l.includes("Specified native messaging host not found")});return}if(!d){o({ok:!1,errorCode:"native_empty_response",error:"Empty response from Native Host"});return}o(d)})}catch(d){i||(clearTimeout(r),i=!0,o({ok:!1,error:d.message}))}})}async function cs(){return await vt("check")}async function Sa(e,t){return await vt("insert",{path:e,content:t})}async function ja(e){return await vt("delete",{path:e})}async function $a(e){const t=await vt("sync_all");if(!t.ok||!Array.isArray(t.items))throw new Error(t.error||"Failed to sync entries from PASS CLI");return t.items.map(o=>{const i=o.path.split("/");let r=i[i.length-1],d=i.length>1?i.slice(0,i.length-1).join("/"):"General";const u=Rs(r,o.content,e);return u.category=d,u.entryPath=o.path,u})}async function Ea(e){const t=e.category&&e.category!=="General"&&e.category!=="All"?`${e.category}/`:"",a=e.title.replace(/[\/\\]/g,"-"),o=e.entryPath||`${t}${a}`,i=Us(e),r=await Sa(o,i);if(!r.ok)throw new Error(r.error||`Failed to save entry "${o}" in pass`);return{...e,entryPath:o}}async function Ia(e){if(!e.entryPath&&!e.title)return;const t=e.entryPath||e.title,a=await ja(t);if(!a.ok)throw new Error(a.error||`Failed to delete entry "${t}" from pass`)}let xt=Promise.resolve();async function Ca(){if(!c.rawMek||!c.keySlots){S(s("toasts.session_invalid")||"Session invalid or expired"),await je();return}const t={version:!!(c.keySlots&&c.keySlots.keyByPassword&&c.keySlots.keyByPassword.aad)?3:2,updatedAt:new Date().toISOString(),projects:c.projects,items:c.items,trash:c.trash||[]},a=await xe(t,c.rawMek,c.keySlots);await De(a);const o=await q();await W({...o,activeProjectId:c.activeProjectId,latestProjectId:c.activeProjectId})}function J(){return xt=xt.then(()=>Ca()).catch(e=>{throw console.error("persistVaultChanges failed:",e),S(s("toasts.save_failed")||"Failed to save vault data"),e}),xt}async function Pa(e,{renderApp:t}={}){const a=me(),o=e.projectId||(a?a.id:"proj_default"),i=c.projects.find(g=>g.id===o),r=c.items.findIndex(g=>g.id===e.id);let d=[...c.items],u=[];if(r>=0){const g=c.items[r];u=Array.isArray(g.passwordHistory)?[...g.passwordHistory]:[],g.password&&e.password&&g.password!==e.password&&(u.unshift({password:g.password,createdAt:g.updatedAt||new Date().toISOString()}),u.length>5&&(u=u.slice(0,5)))}else Array.isArray(e.passwordHistory)&&(u=e.passwordHistory);const l=ce(e.url),p=l?l.split(":")[0]:"";let m=e.favicon||"";!m&&l&&(m=n.cachedFavicons[l]||n.cachedFavicons[p]||await ye(l)||await ye(p)||"");let h={...e,passwordHistory:u,domain:l||e.domain||"",favicon:m||(r>=0?c.items[r].favicon:"")||"",projectId:o,updatedAt:new Date().toISOString()};if(h.domain&&h.favicon&&(n.cachedFavicons[h.domain]=h.favicon,p&&(n.cachedFavicons[p]=h.favicon)),r>=0?d[r]=h:(h.id="item_"+Date.now(),d.unshift(h)),P({items:d,activeTab:"vault",selectedItem:null,isEditing:!1}),await J(),t&&t(),c.showFavicons&&l&&!h.favicon&&it(e.url,{forceRefresh:!1,activeTabFavIconUrl:n.activeTabFavicon,useExternalServices:c.useExternalIcons===!0}).then(async g=>{if(g&&g.favicon){n.cachedFavicons[l]=g.favicon,p&&(n.cachedFavicons[p]=g.favicon);const k=c.items.findIndex(y=>y.id===h.id);k>=0&&(c.items[k].favicon=g.favicon,c.items[k].domain=l,await J(),t&&t())}}).catch(()=>{}),i&&i.type==="pass_cli")try{await Ea(h),S(s("toasts.pass_saved_sync"))}catch(g){console.warn("PASS CLI sync error:",g),S(s("toasts.pass_saved")+" (PASS: "+g.message+")")}else S(s("toasts.pass_saved"))}async function za(e,{renderApp:t}={}){const a=c.items.find(u=>u.id===e);if(!a)return;const o=c.projects.find(u=>u.id===a.projectId),r=[{...a,deletedAt:new Date().toISOString()},...c.trash||[]],d=c.items.filter(u=>u.id!==e);if(P({items:d,trash:r,activeTab:"vault",selectedItem:null,isEditing:!1}),await J(),t&&t(),o&&o.type==="pass_cli"&&a)try{await Ia(a),S(s("toasts.pass_deleted_sync"))}catch(u){console.warn("PASS CLI delete error:",u),S(s("trash.deleted_toast")||s("toasts.item_deleted"))}else S(s("trash.deleted_toast")||s("toasts.item_deleted"))}async function La(e,{renderApp:t}={}){const a=(c.trash||[]).find(u=>u.id===e);if(!a)return;const{deletedAt:o,...i}=a;i.updatedAt=new Date().toISOString();const r=(c.trash||[]).filter(u=>u.id!==e),d=[i,...c.items];P({items:d,trash:r}),await J(),S(s("trash.restored_toast")||"Restored from trash"),t&&t()}async function Aa(e,{renderApp:t}={}){if(!confirm(s("trash.delete_perm_confirm")||s("toasts.delete_confirm")))return;const a=(c.trash||[]).filter(o=>o.id!==e);P({trash:a}),await J(),S(s("trash.perm_deleted_toast")||"Item permanently deleted"),t&&t()}async function Ta({renderApp:e}={}){confirm(s("trash.empty_confirm")||"Empty trash?")&&(P({trash:[]}),await J(),S(s("trash.emptied_toast")||"Trash emptied"),e&&e())}function Ba(e,{renderApp:t}={}){if(!e)return;const a=(e.title||"password").replace(/[^a-zA-Z0-9_\u0400-\u04FF-]/g,"_");n.exportModalData={format:"csv",items:[e],fileName:`password-${a}`},t&&t()}function Da(e){Array.isArray(e)&&e.forEach(t=>{if(t.domain&&t.favicon){n.cachedFavicons[t.domain]=t.favicon;const a=t.domain.split(":")[0];a!==t.domain&&(n.cachedFavicons[a]=t.favicon)}})}function Ma(e){const t=[];let a=[],o="",i=!1;for(let y=0;y<e.length;y++){const b=e[y],j=e[y+1];i?b==='"'&&j==='"'?(o+='"',y++):b==='"'?i=!1:o+=b:b==='"'?i=!0:b===","?(a.push(o.trim()),o=""):b==="\r"||(b===`
`?(a.push(o.trim()),a.some(F=>F.length>0)&&t.push(a),a=[],o=""):o+=b)}if((o||a.length)&&(a.push(o.trim()),a.some(y=>y.length>0)&&t.push(a)),t.length<2)throw new Error(s("settings.csv_import_empty")||"CSV file is empty");const r=t[0].map(y=>y.toLowerCase().replace(/[^a-z0-9_]/g,"")),d=(...y)=>r.findIndex(b=>y.some(j=>b===j||b.includes(j))),u=d("name","title","site"),l=d("url","uri","website","login_uri"),p=d("username","login","email","user"),m=d("password","pass"),h=d("notes","note","comment"),g=d("category","folder","group");if(m===-1&&u===-1)throw new Error(s("toasts.csv_header_err"));const k=[];for(let y=1;y<t.length;y++){const b=t[y],j=m!==-1&&b[m]||"",F=u!==-1&&b[u]||"";!j&&!F||k.push({id:"item_"+Date.now()+"_"+Math.random().toString(36).substr(2,6),title:F||"Untitled",password:j,username:p!==-1&&b[p]||"",url:l!==-1&&b[l]||"",notes:h!==-1&&b[h]||"",category:g!==-1&&b[g]?b[g].trim():"",tags:g!==-1&&b[g]?[b[g].trim()]:[],updatedAt:new Date().toISOString()})}return k}async function ls(e){if(c.projects.find(a=>a.id===e)){if(!c.hasNativeMessagingPermission){if(!await Me("nativeMessaging")){S(s("toasts.native_permission_denied"));return}P({hasNativeMessagingPermission:!0})}S(s("toasts.pass_syncing"));try{const a=await $a(e),i=[...c.items.filter(r=>r.projectId!==e),...a];P({items:i}),await J(),S(s("toasts.pass_sync_loaded",{count:a.length}))}catch(a){alert(s("toasts.pass_conn_err",{message:a.message}))}}}let Te=null,ct=15,Pt=null,Ht=!1;function Re(){!Ht||ct<=0||(Te&&clearTimeout(Te),Te=setTimeout(()=>{typeof Pt=="function"&&Pt()},ct*60*1e3))}const ds=["pointerdown","keydown","wheel"];function zt({idleMinutes:e=15,onLock:t}){return Lt(),ct=Number(e)||0,Pt=t,Ht=!0,typeof document<"u"&&ds.forEach(a=>{document.addEventListener(a,Re,{passive:!0})}),Re(),{stop:Lt,reset:Re,updateInterval:a=>{ct=Number(a)||0,Re()}}}function Lt(){Ht=!1,Te&&(clearTimeout(Te),Te=null),typeof document<"u"&&ds.forEach(e=>{document.removeEventListener(e,Re)})}const lt={amber:{id:"amber",name:"Amber",color:"#F59E0B",darkText:"#FBBF24",lightText:"#B45309",bgDark:"rgba(245, 158, 11, 0.16)",bgLight:"rgba(245, 158, 11, 0.12)",borderDark:"rgba(245, 158, 11, 0.35)",borderLight:"rgba(245, 158, 11, 0.3)",bgDarkActive:"rgba(245, 158, 11, 0.32)",bgLightActive:"rgba(245, 158, 11, 0.24)"},blue:{id:"blue",name:"Blue",color:"#3B82F6",darkText:"#60A5FA",lightText:"#1D4ED8",bgDark:"rgba(59, 130, 246, 0.16)",bgLight:"rgba(59, 130, 246, 0.12)",borderDark:"rgba(59, 130, 246, 0.35)",borderLight:"rgba(59, 130, 246, 0.3)",bgDarkActive:"rgba(59, 130, 246, 0.32)",bgLightActive:"rgba(59, 130, 246, 0.24)"},purple:{id:"purple",name:"Purple",color:"#8B5CF6",darkText:"#C084FC",lightText:"#7C3AED",bgDark:"rgba(139, 92, 246, 0.16)",bgLight:"rgba(139, 92, 246, 0.12)",borderDark:"rgba(139, 92, 246, 0.35)",borderLight:"rgba(139, 92, 246, 0.3)",bgDarkActive:"rgba(139, 92, 246, 0.32)",bgLightActive:"rgba(139, 92, 246, 0.24)"},yellow:{id:"yellow",name:"Yellow",color:"#EAB308",darkText:"#FACC15",lightText:"#A16207",bgDark:"rgba(234, 179, 8, 0.16)",bgLight:"rgba(234, 179, 8, 0.12)",borderDark:"rgba(234, 179, 8, 0.35)",borderLight:"rgba(234, 179, 8, 0.3)",bgDarkActive:"rgba(234, 179, 8, 0.32)",bgLightActive:"rgba(234, 179, 8, 0.24)"},green:{id:"green",name:"Lime",color:"#BADC00",darkText:"#D9F230",lightText:"#4D5E00",bgDark:"rgba(186, 220, 0, 0.16)",bgLight:"rgba(186, 220, 0, 0.14)",borderDark:"rgba(186, 220, 0, 0.35)",borderLight:"rgba(186, 220, 0, 0.35)",bgDarkActive:"rgba(186, 220, 0, 0.32)",bgLightActive:"rgba(186, 220, 0, 0.26)"},red:{id:"red",name:"Red",color:"#EF4444",darkText:"#F87171",lightText:"#B91C1C",bgDark:"rgba(239, 68, 68, 0.16)",bgLight:"rgba(239, 68, 68, 0.12)",borderDark:"rgba(239, 68, 68, 0.35)",borderLight:"rgba(239, 68, 68, 0.3)",bgDarkActive:"rgba(239, 68, 68, 0.32)",bgLightActive:"rgba(239, 68, 68, 0.24)"},teal:{id:"teal",name:"Teal",color:"#14B8A6",darkText:"#2DD4BF",lightText:"#0F766E",bgDark:"rgba(20, 184, 166, 0.16)",bgLight:"rgba(20, 184, 166, 0.12)",borderDark:"rgba(20, 184, 166, 0.35)",borderLight:"rgba(20, 184, 166, 0.3)",bgDarkActive:"rgba(20, 184, 166, 0.32)",bgLightActive:"rgba(20, 184, 166, 0.24)"},pink:{id:"pink",name:"Pink",color:"#EC4899",darkText:"#F472B6",lightText:"#BE185D",bgDark:"rgba(236, 72, 153, 0.16)",bgLight:"rgba(236, 72, 153, 0.12)",borderDark:"rgba(236, 72, 153, 0.35)",borderLight:"rgba(236, 72, 153, 0.3)",bgDarkActive:"rgba(236, 72, 153, 0.32)",bgLightActive:"rgba(236, 72, 153, 0.24)"},slate:{id:"slate",name:"Slate",color:"#64748B",darkText:"#CBD5E1",lightText:"#475569",bgDark:"rgba(100, 116, 139, 0.16)",bgLight:"rgba(100, 116, 139, 0.12)",borderDark:"rgba(100, 116, 139, 0.35)",borderLight:"rgba(100, 116, 139, 0.3)",bgDarkActive:"rgba(100, 116, 139, 0.32)",bgLightActive:"rgba(100, 116, 139, 0.24)"}},dt={Work:"blue",Personal:"green"};function Oe(e,t={}){const a=t&&t[e]||dt[e]||"slate";return lt[a]||lt.slate}function Ve(e){return e?[`--pill-color:${e.color}`,`--pill-bg-dark:${e.bgDark}`,`--pill-bg-light:${e.bgLight}`,`--pill-border-dark:${e.borderDark}`,`--pill-border-light:${e.borderLight}`,`--pill-text-dark:${e.darkText}`,`--pill-text-light:${e.lightText}`,`--pill-bg-dark-active:${e.bgDarkActive}`,`--pill-bg-light-active:${e.bgLightActive}`].join(";"):""}function At(e){if(!e||typeof e!="string")return{valid:!1,errorCode:"tag_empty",error:"Tag name cannot be empty"};const t=e.trim();return t.length===0?{valid:!1,errorCode:"tag_empty",error:"Tag name cannot be empty"}:t.length>30?{valid:!1,errorCode:"tag_too_long",error:"Maximum tag length is 30 characters"}:/^[\p{L}\p{N}]+(?: [\p{L}\p{N}]+)*$/u.test(t)?{valid:!0,name:t}:{valid:!1,errorCode:"tag_invalid_chars",error:"Only letters, numbers, and single spaces are allowed"}}function le(e){return e?Array.isArray(e.tags)?e.tags.filter(t=>typeof t=="string"&&t.trim().length>0):e.category&&typeof e.category=="string"&&e.category.trim().length>0?[e.category.trim()]:[]:[]}const Gt='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',Tt='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>',Xe='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>',ps='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',Qe='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',yt='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',G='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',_e='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',pe='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',qt='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',us='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',ms='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>',Oa='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',bt='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',gs='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 8h.01"/><path d="M8 8h.01"/><path d="M8 16h.01"/><path d="M16 16h.01"/><path d="M12 12h.01"/></svg>',wt='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',Bt='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',X='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',Va='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',Ie='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',ie='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>',Na='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',Fa='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>',Ua='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>',Ra='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>',Ha='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';function Ga(){if(!c.isInitialized)return`
      <div class="sp-auth-screen">
        <div class="sp-auth-box">
          <div class="sp-auth-logo"><img src="icons/icon-128.png" style="width:52px;height:52px;display:block;object-fit:contain;" alt="Logo" /></div>
          <h2 class="sp-auth-title">${s("auth.create_profile_title")}</h2>
          <p class="sp-auth-desc">${s("auth.create_profile_desc")}</p>
          <form class="sp-auth-form" id="sp-init-form" novalidate>
            <div>
              <input type="text" id="sp-init-proj-name" class="sp-input" placeholder="${s("auth.profile_name_placeholder")}" />
              <div class="sp-field-error" id="sp-err-proj-name"></div>
            </div>
            <div>
              <input type="password" id="sp-init-pwd" class="sp-input" placeholder="${s("auth.master_pwd_placeholder")}" />
              <div class="sp-field-error" id="sp-err-pwd"></div>
              <div id="sp-init-pwd-strength"></div>
            </div>
            <div>
              <input type="password" id="sp-init-pwd2" class="sp-input" placeholder="${s("auth.repeat_pwd_placeholder")}" />
              <div class="sp-field-error" id="sp-err-pwd2"></div>
            </div>
            <button type="submit" class="sp-btn-primary" style="justify-content:center; margin-top: 6px;">
              ${s("auth.create_profile_btn")}
            </button>
          </form>
        </div>
      </div>
    `;if(n.isCreatingNewVaultFromLock)return`
      <div class="sp-auth-screen">
        <div class="sp-auth-box" style="max-width: 360px;">
          <div class="sp-auth-logo"><img src="icons/icon-128.png" style="width:48px;height:48px;display:block;object-fit:contain;" alt="Logo" /></div>
          <h2 class="sp-auth-title">${s("auth.new_db_title")}</h2>
          <p class="sp-auth-desc">${s("auth.new_db_desc")}</p>

          <form class="sp-auth-form" id="sp-new-db-form" novalidate>
            <div>
              <input type="text" id="sp-new-db-name" class="sp-input" placeholder="${s("auth.db_name_placeholder")}" autofocus />
              <div class="sp-field-error" id="sp-err-new-db-name"></div>
            </div>
            <div>
              <input type="password" id="sp-new-db-pwd" class="sp-input" placeholder="${s("auth.master_pwd_placeholder")}" />
              <div class="sp-field-error" id="sp-err-new-db-pwd"></div>
              <div id="sp-new-db-pwd-strength"></div>
            </div>
            <div>
              <input type="password" id="sp-new-db-pwd2" class="sp-input" placeholder="${s("auth.repeat_pwd_placeholder")}" />
              <div class="sp-field-error" id="sp-err-new-db-pwd2"></div>
            </div>
            <button type="submit" class="sp-btn-primary" style="justify-content:center; margin-top: 6px;">
              ${_e} ${s("auth.create_and_enter_btn")}
            </button>
            <div style="text-align:center; margin-top: 8px;">
              <button type="button" class="sp-link-btn" id="sp-btn-cancel-new-db">${s("auth.cancel_btn")}</button>
            </div>
          </form>
        </div>
      </div>
    `;if(n.isRecoveryViewActive)return`
      <div class="sp-auth-screen">
        <div class="sp-auth-box" style="max-width: 360px;">
          <div class="sp-auth-logo"><img src="icons/icon-128.png" style="width:48px;height:48px;display:block;object-fit:contain;" alt="Logo" /></div>
          <h2 class="sp-auth-title">${s("auth.recovery_title")}</h2>
          <p class="sp-auth-desc">${s("auth.recovery_desc")}</p>

          <form class="sp-auth-form" id="sp-recovery-form" novalidate>
            <div>
              <textarea id="sp-recover-phrase" class="sp-input" style="height: 72px; resize:none; font-family:monospace; font-size:12px; line-height:1.4;" placeholder="${s("auth.recovery_phrase_placeholder")}"></textarea>
              <div class="sp-field-error" id="sp-err-recover-phrase"></div>
              <div id="sp-recover-phrase-hints" style="font-size:11px; margin-top:4px;"></div>
            </div>
            <div>
              <input type="password" id="sp-recover-new-pwd" class="sp-input" placeholder="${s("auth.master_pwd_placeholder")}" />
              <div class="sp-field-error" id="sp-err-recover-pwd"></div>
              <div id="sp-recover-new-pwd-strength"></div>
            </div>
            <div>
              <input type="password" id="sp-recover-new-pwd2" class="sp-input" placeholder="${s("auth.repeat_pwd_placeholder")}" />
              <div class="sp-field-error" id="sp-err-recover-pwd2"></div>
            </div>
            <button type="submit" class="sp-btn-primary" style="justify-content:center; margin-top: 6px;">
              ${Tt} ${s("auth.restore_access_btn")}
            </button>
            <button type="button" class="sp-btn-secondary" id="sp-btn-create-new-vault" style="width:100%; justify-content:center; margin-top: 8px;">
              ${_e} ${s("auth.create_new_db_btn")}
            </button>
            <div style="text-align:center; margin-top: 8px;">
              <button type="button" class="sp-link-btn" id="sp-btn-cancel-recovery">${s("auth.return_to_login_btn")}</button>
            </div>
          </form>
        </div>
      </div>
    `;if(n.isProfileSelectorViewActive)return`
      <div class="sp-auth-screen">
        <div class="sp-auth-box" style="max-width: 360px;">
          <div class="sp-auth-logo"><img src="icons/icon-128.png" style="width:48px;height:48px;display:block;object-fit:contain;" alt="Logo" /></div>
          <h2 class="sp-auth-title">${s("auth.select_profile_title")}</h2>
          <p class="sp-auth-desc">${s("auth.select_profile_desc")}</p>

          <div class="sp-profile-list" style="display:flex; flex-direction:column; gap:8px; margin-bottom:14px; width:100%;">
            ${n.cachedVaultProfiles.map(a=>`
              <div class="sp-profile-select-item ${a.id===n.cachedActiveVaultId?"active":""}" data-vault-id="${a.id}">
                <div style="display:flex; align-items:center; gap:10px;">
                  <span style="font-size:16px;">🗄️</span>
                  <span style="font-weight:${a.id===n.cachedActiveVaultId?"600":"500"}; font-size:13px; color:var(--text-main);">${C(a.name)}</span>
                </div>
                ${a.id===n.cachedActiveVaultId?'<span style="color:var(--sp-primary); font-weight:bold; font-size:13px;">✓</span>':""}
              </div>
            `).join("")}
          </div>

          <button type="button" class="sp-btn-secondary" id="sp-btn-profile-create-new" style="width:100%; justify-content:center; margin-bottom:10px;">
            ${_e} ${s("auth.create_new_db_btn")}
          </button>

          <div style="text-align:center;">
            <button type="button" class="sp-link-btn" id="sp-btn-cancel-profile-select">${s("auth.return_to_login_btn")}</button>
          </div>
        </div>
      </div>
    `;const e=Ae(),t=e>0;return`
    <div class="sp-auth-screen">
      <div class="sp-auth-box">
        <div class="sp-auth-logo"><img src="icons/icon-128.png" style="width:52px;height:52px;display:block;object-fit:contain;" alt="Logo" /></div>
        <h2 class="sp-auth-title">${s("auth.locked_title")}</h2>
        <p class="sp-auth-desc">${s("auth.locked_desc")}</p>

        ${t?`
          <div class="sp-lockout-alert" id="sp-lockout-msg">
            ${s("auth.lockout_wait",{seconds:`<span id="sp-lockout-seconds" style="font-weight:bold;">${e}</span>`})}
          </div>
        `:""}

        <form class="sp-auth-form" id="sp-unlock-form" novalidate>
          <div>
            <input type="password" id="sp-unlock-pwd" class="sp-input" placeholder="${s("settings.master_pwd_label")}" ${t?'disabled style="opacity:0.4; cursor:not-allowed;"':"autofocus"} />
            <div class="sp-field-error" id="sp-err-unlock" ${n.failedAttempts>0&&!t?'style="display:block;"':""}>${n.failedAttempts>0&&!t?s("auth.lockout_attempt_error",{current:n.failedAttempts}):""}</div>
          </div>

          <button type="submit" class="sp-btn-primary" ${t?'disabled style="opacity:0.5; cursor:not-allowed;"':""} style="justify-content:center; margin-top: 6px;">
            ${Tt} ${s("auth.unlock_btn")}
          </button>

          <div id="sp-auth-links-wrap" style="text-align:center; margin-top: 10px; display:flex; flex-direction:column; gap:6px; align-items:center;">
            <button type="button" class="sp-link-btn" id="sp-forgot-pwd">${s("auth.forgot_pwd_btn")}</button>
            <button type="button" class="sp-link-btn" id="sp-switch-profile" style="color:var(--text-dim); font-size:12px;">${s("auth.switch_profile_btn")}</button>
          </div>
        </form>
      </div>
    </div>
  `}function qa(){let e=s("nav.passwords");return c.activeTab==="generator"?e=s("nav.generator"):c.activeTab==="security"?e=s("security.title"):c.activeTab==="settings"?e=s("nav.settings"):c.activeTab==="item-details"&&(e=c.selectedItem?s("form.edit_title"):s("form.new_title")),`
    <header class="sp-header">
      <div class="sp-header-left">
        <button class="sp-btn-icon" id="sp-burger-btn" title="${s("nav.menu")}">${Na}</button>
        <span class="sp-header-title" id="sp-header-title">${C(e)}</span>
      </div>
      <div class="sp-header-actions">
        ${c.activeTab!=="security"?`
        <button class="sp-btn-add-pwd" id="sp-btn-add" title="${s("nav.add_password")}">
          ${_e}
          <span>${s("nav.add_password")}</span>
        </button>
        `:""}
        <button class="sp-btn-icon" id="sp-btn-lock" title="${s("nav.lock_vault")}">${Gt}</button>
      </div>
    </header>
  `}function Wa(){const e=ge(),t=n.isDrawerOpen;return`
    <div class="sp-drawer-overlay ${t?"open":""}" id="sp-drawer-overlay"></div>
    <aside class="sp-drawer ${t?"open":""}" id="sp-drawer">
      <div class="sp-drawer-header">
        <span class="sp-drawer-heading">${s("nav.menu")}</span>
        <button class="sp-btn-icon" id="sp-close-drawer-btn" title="${s("nav.close")}">${X}</button>
      </div>
      <nav class="sp-drawer-menu">
        <button class="sp-drawer-item ${c.activeTab==="vault"?"active":""}" data-nav="vault">
          <span class="sp-drawer-item-icon">${Xe}</span>
          <span>${s("nav.passwords")}</span>
          <span class="sp-drawer-item-badge">${e.length}</span>
        </button>
        <button class="sp-drawer-item ${c.activeTab==="generator"?"active":""}" data-nav="generator">
          <span class="sp-drawer-item-icon">${gs}</span>
          <span>${s("nav.generator")}</span>
        </button>
        <button class="sp-drawer-item ${c.activeTab==="security"?"active":""}" data-nav="security">
          <span class="sp-drawer-item-icon">${ps}</span>
          <span>${s("security.title")}</span>
          <span class="sp-badge-info" style="font-size:9px; padding:1px 4px; text-transform:uppercase;">${s("security.experimental")}</span>
        </button>
        <button class="sp-drawer-item ${c.activeTab==="settings"?"active":""}" data-nav="settings">
          <span class="sp-drawer-item-icon">${Oa}</span>
          <span>${s("nav.settings")}</span>
        </button>
      </nav>
    </aside>
  `}function Ja(){const e=me(),t=ge();return`
    <footer class="sp-footer">
      <div class="sp-footer-left">
        <span>${s("footer.items_count",{count:t.length})}</span>
      </div>
      <div class="sp-footer-right">
        <div class="sp-project-badge ${c.isProjectSwitcherOpen?"active":""}" id="sp-project-container" title="${s("footer.db_project")}">
          <span class="sp-project-dot"></span>
          <span id="sp-project-display">${e?C(e.name):"—"}</span>
        </div>
      </div>
    </footer>
  `}function hs(){return c.categories.map(e=>{const t=e==="All",a=t?s("categories.All"):e==="Work"?s("categories.Work"):e==="Personal"?s("categories.Personal"):e;if(t)return`<button class="sp-pill sp-pill-all ${e===c.activeCategory?"active":""}" data-cat="${e}">${a}</button>`;const o=Oe(e,c.categoryColors),i=Ve(o);return`
        <button class="sp-pill ${e===c.activeCategory?"active":""}" data-color-pill="true" data-cat="${e}" style="${i}">
          <span class="sp-pill-dot" style="background-color:${o.color};"></span>
          <span>${a}</span>
        </button>
      `}).join("")}function fs(){const e=ge(),t=n.activeTabDomain;if(t){const a=e.filter(i=>Qt(i,t)),o=We(t);if(a.length>0&&o)return`
        <div id="sp-active-domain-banner" style="background: var(--bg-surface); border: 1px solid var(--border-subtle); padding: 6px 12px; margin: 8px 14px 0; border-radius: var(--radius-sm); font-size: 11px; display: flex; align-items: center; justify-content: space-between; cursor: pointer; transition: background 0.15s ease;" title="${s("vault.filter_domain_title")}">
          <span style="color: var(--text-main); font-weight: 600; display:flex; align-items:center; gap:6px;">
            <span style="color:var(--accent);">${Bt}</span> ${s("vault.current_site")}: <b>${C(o)}</b> (${a.length})
          </span>
          <button class="sp-btn-icon" id="sp-filter-domain" style="width:20px;height:20px;" title="${s("vault.filter_domain_title")}">${Qe}</button>
        </div>
      `}else if(!c.hasTabsPermission&&c.currentSiteEnabled)return`
      <div id="sp-enable-tabs-banner" style="background: var(--bg-surface); border: 1px dashed var(--accent, #6366f1); padding: 7px 12px; margin: 8px 14px 0; border-radius: var(--radius-sm); font-size: 11px; display: flex; align-items: center; justify-content: space-between; gap: 8px; cursor: pointer;">
        <span style="display:flex; align-items:center; gap:6px; color:var(--text-main);">
          <span style="color:var(--accent, #6366f1);">${Bt}</span>
          <span>${s("vault.enable_site_detection_desc")}</span>
        </span>
        <button type="button" class="sp-btn-primary" id="sp-btn-enable-tabs" style="padding: 3px 8px; font-size: 10px; height: auto; white-space: nowrap;">
          ${s("vault.enable_site_detection_btn")}
        </button>
      </div>
    `;return""}function ze(){const e=c.searchQuery.toLowerCase().trim(),t=c.activeCategory,o=ge().filter(r=>{const d=le(r),u=t==="All"||d.includes(t)||r.category===t,l=!e||r.title.toLowerCase().includes(e)||r.domain&&r.domain.toLowerCase().includes(e)||r.username&&r.username.toLowerCase().includes(e)||r.url&&r.url.toLowerCase().includes(e)||d.some(p=>p.toLowerCase().includes(e));return u&&l}),i=ks(o,n.activeTabDomain);return i.length===0?`
      <div class="sp-empty-state">
        <div class="sp-empty-icon">${Xe}</div>
        <p style="font-size: 13px; font-weight: 600;">${s("vault.empty_title")}</p>
        <p style="font-size: 11px;">${s("vault.empty_desc")}</p>
        <button type="button" class="sp-btn-add-pwd" id="sp-empty-btn-add" style="margin-top:8px;">
          ${_e}
          <span>${s("nav.add_password")}</span>
        </button>
      </div>
    `:i.map(r=>{const d=r.title?r.title[0]:"?",u=Qt(r,n.activeTabDomain),l=r.domain||ce(r.url),p=l?l.split(":")[0]:"",m=c.showFavicons?r.favicon||l&&n.cachedFavicons[l]||p&&n.cachedFavicons[p]:null,h=m?`<img src="${C(m)}" class="sp-card-favicon" alt="" /><span class="sp-card-fallback-letter" style="display:none;">${d}</span>`:`<span>${d}</span>`;let g="";return c.showCardTags&&(g=le(r).map(y=>{const b=Oe(y,c.categoryColors),j=Ve(b),F=y==="Work"?s("categories.Work"):y==="Personal"?s("categories.Personal"):y;return`<span class="sp-pill sp-pill-tag-card" data-color-pill="true" style="${j}; pointer-events:none;"><span class="sp-pill-dot" style="background-color:${b.color};"></span><span>${C(F)}</span></span>`}).join("")),`
        <div class="sp-card ${u?"sp-card-matched":""}" data-id="${r.id}">
          <div class="sp-card-left" data-action="view">
            <div class="sp-card-avatar">${h}</div>
            <div class="sp-card-meta">
              <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                <span class="sp-card-title">${C(r.title)}</span>
                ${g}
              </div>
              <span class="sp-card-sub">${C(r.username||r.url||s("vault.no_login"))}</span>
            </div>
          </div>
          <div class="sp-card-actions">
            <button class="sp-btn-icon" data-action="autofill" title="${n.isAutofillSupported?s("vault.autofill_action"):s("vault.autofill_unsupported")}" ${n.isAutofillSupported?"":'disabled style="opacity:0.35; cursor:not-allowed;"'}>${Va}</button>
            <button class="sp-btn-icon" data-action="copy-user" title="${s("vault.copy_user")}">${yt}</button>
            <button class="sp-btn-icon" data-action="copy-pwd" title="${s("vault.copy_pwd")}">${Xe}</button>
          </div>
        </div>
      `}).join("")}function Ka(){return`
    <div class="sp-search-bar">
      <div class="sp-search-input-wrap">
        <span class="sp-search-icon">${Qe}</span>
        <input type="text" id="sp-search-input" class="sp-search-input" placeholder="${s("vault.search_placeholder")}" value="${C(c.searchQuery)}" />
        <button class="sp-search-clear" id="sp-search-clear" style="display: ${c.searchQuery?"flex":"none"};">${X}</button>
      </div>
      <div class="sp-category-pills" id="sp-category-pills">
        ${hs()}
      </div>
    </div>
    <div id="sp-vault-domain-notice">
      ${fs()}
    </div>
    <div class="sp-vault-list" id="sp-vault-cards-container">
      ${ze()}
    </div>
  `}function Xa(){const e=me(),t=!c.selectedItem,a=c.selectedItem?c.selectedItem.id:"__new__",o=n.formDraft&&(t&&n.formDraft.isNew||!t&&n.formDraft.id===c.selectedItem.id);n.currentFormItemId!==a&&(n.currentFormItemId=a,o&&Array.isArray(n.formDraft.tags)?n.formSelectedTags=[...n.formDraft.tags]:n.formSelectedTags=t?[]:le(c.selectedItem));const i=e?e.id:c.projects[0]?c.projects[0].id:"proj_default",r=c.selectedItem||{id:"",projectId:i,title:"",username:"",password:"",url:n.activeTabDomain?n.activeTabDomain.includes(":")||Xt(n.activeTabDomain)?`http://${n.activeTabDomain}`:`https://${n.activeTabDomain}`:"",domain:We(n.activeTabDomain)||"",favicon:n.activeTabDomain&&n.cachedFavicons[n.activeTabDomain]||n.activeTabDomain&&n.cachedFavicons[n.activeTabDomain.split(":")[0]]||"",category:"",notes:""},d=o?{id:n.formDraft.id,projectId:n.formDraft.projectId||r.projectId,title:n.formDraft.title!==void 0?n.formDraft.title:r.title,username:n.formDraft.username!==void 0?n.formDraft.username:r.username,password:n.formDraft.password!==void 0?n.formDraft.password:r.password,url:n.formDraft.url!==void 0?n.formDraft.url:r.url,domain:n.formDraft.domain!==void 0?n.formDraft.domain:r.domain||"",favicon:n.formDraft.favicon!==void 0?n.formDraft.favicon:r.favicon||"",category:n.formDraft.tags&&n.formDraft.tags[0]?n.formDraft.tags[0]:r.category||"",notes:n.formDraft.notes!==void 0?n.formDraft.notes:r.notes}:r;n.currentFormItemPassword=d.password||"";const u=d.projectId||i,l=c.projects.find(g=>g.id===u)||c.projects[0]||{id:"proj_default",name:"main"},p=We(d.domain||d.url),m=p?p.split(":")[0]:"",h=c.showFavicons&&(d.favicon||p&&n.cachedFavicons[p]||m&&n.cachedFavicons[m])||"";return`
    <div class="sp-view-container">
      <div style="display:flex; align-items:center; justify-content:space-between;">
        <button class="sp-btn-secondary" id="sp-form-back" style="padding:6px 10px;">
          ${X} ${s("form.back")}
        </button>
        <h3 style="font-size:14px; font-weight:700;">${s(t?"form.new_title":"form.edit_title")}</h3>
        <div style="display:flex; gap:6px;">
          ${t?"":`<button type="button" class="sp-btn-secondary" id="sp-form-export-csv" style="padding:6px 10px;" title="${s("vault.export_csv_btn")}">${Ie}</button>`}
          ${t?"<div></div>":`<button type="button" class="sp-btn-danger" id="sp-form-delete" style="padding:6px 10px;" title="${s("form.delete_btn")}">${pe}</button>`}
        </div>
      </div>

      ${t?`
        <div style="background:var(--bg-surface); border:1px dashed var(--border-subtle); border-radius:var(--radius-sm); padding:10px 12px; display:flex; align-items:center; justify-content:space-between;">
          <div>
            <div style="font-size:12px; font-weight:600; color:var(--text-main);">${s("form.csv_title")}</div>
            <div style="font-size:11px; color:var(--text-dim);">${s("form.csv_sub")}</div>
          </div>
          <label class="sp-btn-secondary" style="padding:5px 10px; font-size:11px; cursor:pointer;">
            ${Ie} ${s("form.csv_choose_file")}
            <input type="file" id="sp-csv-file-input" accept=".csv,text/csv" style="display:none;" />
          </label>
        </div>
      `:""}

      <form id="sp-item-form" novalidate style="display:flex; flex-direction:column; gap:12px;">
        <input type="hidden" id="sp-item-id" value="${d.id}" />

        <div class="sp-form-group">
          <label class="sp-label">${s("footer.db_project")}</label>
          <div class="sp-custom-select-wrap" id="sp-project-select-wrap">
            <input type="hidden" id="sp-item-project" value="${l.id}" />
            <div class="sp-select-trigger" id="sp-project-select-trigger" tabindex="0" role="combobox" aria-expanded="false">
              <span class="sp-select-trigger-text" id="sp-project-select-label">${C(l.name)}</span>
              <button type="button" class="sp-input-action-btn" id="sp-project-dropdown-toggle" title="${s("footer.db_project")}" tabindex="-1">
                ${ie}
              </button>
            </div>
            <div class="sp-select-dropdown" id="sp-project-dropdown" style="display:none;">
              ${c.projects.map(g=>{const k=g.id===l.id;return`
                  <div class="sp-select-option ${k?"selected":""}" data-action="select-form-project" data-project-id="${g.id}" data-project-name="${C(g.name)}">
                    <div style="display:flex; align-items:center; gap:8px;">
                      <span style="color:var(--text-dim); display:flex; align-items:center;">${g.type==="pass_cli"?Ra:wt}</span>
                      <span>${C(g.name)}</span>
                    </div>
                    ${k?`<span style="color:var(--text-main); font-size:12px; display:flex; align-items:center;">${G}</span>`:""}
                  </div>
                `}).join("")}
            </div>
          </div>
        </div>

        <div class="sp-form-group">
          <label class="sp-label">${s("form.title_label")} *</label>
          <input type="text" id="sp-item-title" class="sp-input" value="${C(d.title||"")}" placeholder="${s("form.title_placeholder")}" autocomplete="off" />
          <div class="sp-field-error" id="sp-item-title-error"></div>
        </div>

        <div class="sp-form-group">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <label class="sp-label" style="margin:0; display:flex; align-items:center; gap:6px;">
              ${h?`<img id="sp-form-favicon-preview" src="${C(h)}" style="width:14px; height:14px; border-radius:3px; object-fit:contain;" alt="" />`:'<img id="sp-form-favicon-preview" style="width:14px; height:14px; border-radius:3px; object-fit:contain; display:none;" alt="" />'}
              <span>${s("form.url_label")}</span>
            </label>
            ${p?`<span id="sp-form-domain-badge" style="font-size:10px; color:var(--text-dim);">${C(p)}</span>`:'<span id="sp-form-domain-badge" style="font-size:10px; color:var(--text-dim); display:none;"></span>'}
          </div>
          <div class="sp-input-with-action">
            <input type="text" id="sp-item-url" class="sp-input" value="${C(d.url||"")}" placeholder="${s("form.url_placeholder")}" style="padding-right: ${c.showFavicons?"36px":"10px"};" />
            ${c.showFavicons?`
            <button type="button" class="sp-input-action-btn" id="sp-btn-refresh-favicon" title="${s("form.refresh_favicon_title")}">
              ${bt}
            </button>
            `:""}
          </div>
        </div>

        <div class="sp-form-group">
          <label class="sp-label">${s("form.login_label")}</label>
          <input type="text" id="sp-item-username" class="sp-input" value="${C(d.username||"")}" placeholder="${s("form.login_placeholder")}" />
        </div>

        <div class="sp-form-group">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <label class="sp-label">${s("form.password_label")} *</label>
            <button type="button" class="sp-btn-icon" id="sp-btn-gen-inline" style="width:auto; height:20px; font-size:11px; gap:4px;" title="${s("generator.refresh_title")}">
              ${gs} ${s("form.generate_btn")}
            </button>
          </div>
          <div class="sp-input-with-action">
            <input type="${n.isPasswordVisible?"text":"password"}" id="sp-item-password" class="sp-input" autocomplete="new-password" spellcheck="false" inputmode="text" style="padding-right: 36px;" />
            <button type="button" class="sp-input-action-btn" id="sp-toggle-pwd-vis">
              ${n.isPasswordVisible?ms:us}
            </button>
          </div>
          <div class="sp-field-error" id="sp-item-password-error"></div>
          ${!t&&d.passwordHistory&&d.passwordHistory.length>0?`
            <div class="sp-pwd-history-wrap" style="margin-top:6px;">
              <button type="button" class="sp-btn-link" id="sp-toggle-pwd-history" style="font-size:11px; display:inline-flex; align-items:center; gap:4px; color:var(--primary); background:none; border:none; padding:2px 0; cursor:pointer;">
                ${ie}
                <span>${s("form.password_history")} (${d.passwordHistory.length})</span>
              </button>
              <div id="sp-pwd-history-list" style="display:none; margin-top:6px; flex-direction:column; gap:4px;">
                ${d.passwordHistory.map(g=>`
                  <div style="display:flex; align-items:center; justify-content:space-between; gap:6px; padding:5px 8px; background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-sm); font-size:11px;">
                    <span style="color:var(--text-dim); font-size:10px;">${new Date(g.createdAt||g.lastUsed||Date.now()).toLocaleDateString()}</span>
                    <span style="font-family:monospace; color:var(--text-dim); font-size:11px;">••••••••</span>
                    <div style="display:flex; align-items:center; gap:4px;">
                      <button type="button" class="sp-btn-icon" data-action="copy-history-pwd" data-pwd="${C(g.password)}" style="width:22px; height:22px; padding:3px;" title="${s("vault.copy_password")}">
                        ${yt}
                      </button>
                      <button type="button" class="sp-btn-secondary" data-action="restore-history-pwd" data-pwd="${C(g.password)}" style="font-size:10px; padding:2px 6px;">
                        ${s("form.restore_pwd_btn")}
                      </button>
                    </div>
                  </div>
                `).join("")}
              </div>
            </div>
          `:""}
        </div>

        <div class="sp-form-group">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <label class="sp-label" style="margin:0;">${s("form.category_label")}</label>
            <span style="font-size:11px; color:var(--text-dim);">${n.formSelectedTags.length} ${s("form.category_label").toLowerCase()}</span>
          </div>

          <div class="sp-form-tags-selected" id="sp-form-tags-selected">
            ${He()}
          </div>

          <div class="sp-tag-input-container" style="margin-top:6px;">
            <div class="sp-input-with-action">
              <input type="text" id="sp-tag-search-input" class="sp-input" placeholder="${s("form.tags_placeholder")}" autocomplete="off" maxlength="30" />
              <button type="button" class="sp-input-action-btn" id="sp-tag-dropdown-toggle" title="${s("form.category_label")}">
                ${ie}
              </button>
            </div>
            <div class="sp-tags-dropdown" id="sp-tags-dropdown" style="display:none;"></div>
          </div>
          <div id="sp-tag-input-err" style="display:none; font-size:11px; color:var(--danger); margin-top:4px;"></div>
        </div>

        <div class="sp-form-group">
          <label class="sp-label">${s("form.notes_label")}</label>
          <textarea id="sp-item-notes" class="sp-input" rows="3" placeholder="${s("form.notes_placeholder")}">${C(d.notes||"")}</textarea>
        </div>

        <button type="submit" class="sp-btn-primary" style="justify-content:center; margin-top:8px;">
          ${s("form.save_btn")}
        </button>
      </form>
    </div>
  `}function He(){return!n.formSelectedTags||n.formSelectedTags.length===0?`<span style="font-size:11px; color:var(--text-dim);">${s("form.tags_no_tags")}</span>`:n.formSelectedTags.map(e=>{const t=Oe(e,c.categoryColors),a=Ve(t),o=e==="Work"?s("categories.Work"):e==="Personal"?s("categories.Personal"):e;return`
      <span class="sp-pill sp-form-tag-pill" data-color-pill="true" style="${a}">
        <span class="sp-pill-dot" style="background-color:${t.color};"></span>
        <span>${C(o)}</span>
        <button type="button" class="sp-tag-remove-btn" data-action="remove-form-tag" data-tag="${C(e)}" title="${s("form.delete_btn")}">×</button>
      </span>
    `}).join("")}function Qa(){return n.currentGeneratedPassword||(n.currentGeneratedPassword=et(n.genOptions)),`
    <div class="sp-view-container">
      <div class="sp-gen-result-card">
        <div style="display:flex; justify-content:flex-end; align-items:center;">
          <div style="display:flex; gap:4px;">
            <button class="sp-btn-icon" id="sp-gen-refresh" title="${s("generator.refresh_title")}">${bt}</button>
            <button class="sp-btn-icon" id="sp-gen-copy" title="${s("generator.copy_title")}">${yt}</button>
          </div>
        </div>
        <div class="sp-gen-password-display" id="sp-gen-display">${n.currentGeneratedPassword}</div>
      </div>

      <div style="display:flex; flex-direction:column; gap:8px;">
        <div class="sp-form-group">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <label class="sp-label" style="margin:0;">${s("generator.length_label")}</label>
            <span style="font-size:13px; font-weight:700; color:var(--text-main);" id="sp-length-val">${n.genOptions.length}</span>
          </div>
          <input type="range" id="sp-slider-len" min="8" max="64" value="${n.genOptions.length}" style="width:100%; accent-color:var(--text-main); cursor:pointer;" />
        </div>

        <div class="sp-toggle-row">
          <span class="sp-toggle-label">${s("generator.uppercase")}</span>
          <label class="sp-liquid-switch">
            <input type="checkbox" id="sp-chk-upper" ${n.genOptions.useUpper?"checked":""} />
            <span class="sp-liquid-slider"></span>
          </label>
        </div>
        <div class="sp-toggle-row">
          <span class="sp-toggle-label">${s("generator.lowercase")}</span>
          <label class="sp-liquid-switch">
            <input type="checkbox" id="sp-chk-lower" ${n.genOptions.useLower?"checked":""} />
            <span class="sp-liquid-slider"></span>
          </label>
        </div>
        <div class="sp-toggle-row">
          <span class="sp-toggle-label">${s("generator.numbers")}</span>
          <label class="sp-liquid-switch">
            <input type="checkbox" id="sp-chk-digits" ${n.genOptions.useDigits?"checked":""} />
            <span class="sp-liquid-slider"></span>
          </label>
        </div>
        <div class="sp-toggle-row">
          <span class="sp-toggle-label">${s("generator.symbols")}</span>
          <label class="sp-liquid-switch">
            <input type="checkbox" id="sp-chk-symbols" ${n.genOptions.useSymbols?"checked":""} />
            <span class="sp-liquid-slider"></span>
          </label>
        </div>
        <div class="sp-toggle-row">
          <span class="sp-toggle-label">${s("generator.avoid_ambiguous")}</span>
          <label class="sp-liquid-switch">
            <input type="checkbox" id="sp-chk-ambig" ${n.genOptions.avoidAmbiguous?"checked":""} />
            <span class="sp-liquid-slider"></span>
          </label>
        </div>
      </div>
    </div>
  `}function vs(e){if(!e)return"";let t=0;for(let a=0;a<e.length;a++){const o=e.charCodeAt(a);t=(t<<5)-t+o,t|=0}return`pwd_${e.length}_${t}`}function Ya(e,t=new Map,a=Date.now()){const o=e.password||"",i=vs(o),r=o&&t.get(i)||0,d=r>1,u=ns(o),l=!o||u.score<60||o.length<10;let p="strong";return d?p="reused":l?p="weak":p="strong",{itemId:e.id,item:e,isReused:d,reusedCount:r,isWeak:l,strength:u,riskLevel:p}}function Za(e=[],t={}){const a=t.nowMs||Date.now(),o=new Map;e.forEach(h=>{if(h.password){const g=vs(h.password);o.set(g,(o.get(g)||0)+1)}});const i=e.map(h=>Ya(h,o,a)),r=i.length;let d=0,u=0,l=0,p=0;return i.forEach(h=>{h.isReused&&d++,h.isWeak&&u++,h.riskLevel==="strong"&&l++;let g=h.strength.score;h.isReused&&(g*=.4),p+=Math.max(0,Math.min(100,g))}),{healthScore:r>0?Math.round(p/r):100,total:r,reusedCount:d,weakCount:u,strongCount:l,auditedItems:i,auditDate:new Date(a).toISOString()}}function en(){const e=ge(),t=Za(e),a=(n.securitySearchQuery||"").toLowerCase().trim(),o=n.securityActiveRiskFilter||"all",i=t.auditedItems.filter(u=>{const l=u.item;if(o==="reused"&&!u.isReused||o==="weak"&&!u.isWeak||o==="strong"&&u.riskLevel!=="strong")return!1;if(a){const p=(l.title||"").toLowerCase().includes(a),m=(l.username||"").toLowerCase().includes(a),h=(l.url||"").toLowerCase().includes(a),g=(l.domain||"").toLowerCase().includes(a);if(!p&&!m&&!h&&!g)return!1}return!0});let r="var(--accent)";t.healthScore<50?r="var(--danger)":t.healthScore<80&&(r="var(--warning)");const d=i.length>0?i.map(u=>{const l=u.item;let p="sp-card-risk-strong";return u.isReused?p="sp-card-risk-reused":u.isWeak&&(p="sp-card-risk-weak"),`
              <div class="sp-card ${p}" style="margin-bottom:0; padding:10px 12px; display:flex; flex-direction:column; gap:6px;">
                <div style="display:flex; align-items:center; gap:8px; min-width:0;">
                  ${l.favicon?`<img src="${C(l.favicon)}" style="width:16px; height:16px; border-radius:3px; object-fit:contain;" alt="" />`:`<span style="color:var(--text-dim); display:flex;">${Xe}</span>`}
                  <span style="font-size:13px; font-weight:600; color:var(--text-main); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                    ${C(l.title||"Untitled")}
                  </span>
                </div>

                <div style="display:flex; align-items:center; justify-content:space-between; font-size:11px; color:var(--text-dim);">
                  <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:180px;">
                    ${C(l.username||l.domain||l.url||"—")}
                  </span>
                  <button type="button" class="sp-btn-secondary" data-action="fix-security-item" data-id="${C(l.id)}" style="padding:3px 8px; font-size:10px;">
                    ${qt}
                    <span>${s("security.fix_pwd_btn")}</span>
                  </button>
                </div>
              </div>
            `}).join(""):`
        <div class="sp-empty-state" style="padding:30px 16px; text-align:center;">
          <div style="font-size:24px; margin-bottom:6px; opacity:0.5;">${G}</div>
          <p style="font-size:12px; font-weight:600; color:var(--text-main);">${s("security.no_issues_found")}</p>
          <p style="font-size:11px; color:var(--text-dim); margin-top:2px;">${s("security.filter_empty_hint")}</p>
        </div>
      `;return`
    <div style="display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden; flex:1;">
      <!-- Pinned Top Header Pane (Fixed, will not scroll) -->
      <div style="padding:10px 16px 8px; background:var(--bg-card); border-bottom:1px solid var(--border-subtle); display:flex; flex-direction:column; gap:8px; flex-shrink:0;">
        <!-- Top Row: Experimental Pill Only -->
        <div style="display:flex; align-items:center; justify-content:flex-start;">
          <span class="sp-badge-info" style="font-size:9px; padding:2px 6px; text-transform:uppercase; letter-spacing:0.5px; border-radius:4px;">
            ${s("security.experimental")}
          </span>
        </div>

        <!-- Health Score & Metrics Card -->
        <div style="display:flex; align-items:center; justify-content:space-between; padding:8px 12px; background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-sm); gap:12px;">
          <div style="display:flex; align-items:center; gap:10px;">
            <div style="width:38px; height:38px; border-radius:50%; border:3px solid ${r}; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:12px; color:${r}; flex-shrink:0;">
              ${t.healthScore}%
            </div>
            <div>
              <div style="font-size:12px; font-weight:600; color:var(--text-main);">${s("security.health_score")}</div>
              <div style="font-size:10px; color:var(--text-dim);">${s("security.audited_count",{count:t.total})}</div>
            </div>
          </div>
          <div style="display:flex; gap:10px; align-items:center;">
            <span style="display:inline-flex; align-items:center; gap:5px; font-size:11px; font-weight:600; color:var(--text-main);" title="${s("security.filter_reused")}">
              <span class="sp-pill-dot" style="background:var(--danger); box-shadow:0 0 4px var(--danger);"></span>
              ${t.reusedCount}
            </span>
            <span style="display:inline-flex; align-items:center; gap:5px; font-size:11px; font-weight:600; color:var(--text-main);" title="${s("security.filter_weak")}">
              <span class="sp-pill-dot" style="background:var(--warning); box-shadow:0 0 4px var(--warning);"></span>
              ${t.weakCount}
            </span>
            <span style="display:inline-flex; align-items:center; gap:5px; font-size:11px; font-weight:600; color:var(--text-main);" title="${s("security.filter_strong")}">
              <span class="sp-pill-dot" style="background:var(--accent); box-shadow:0 0 4px var(--accent);"></span>
              ${t.strongCount}
            </span>
          </div>
        </div>

        <!-- Color Legend Accordion (Collapsed by default) -->
        <div class="sp-settings-item ${n.isSecurityLegendOpen?"open":""}" style="margin:0; border:1px solid var(--border-subtle); border-radius:var(--radius-sm); overflow:hidden;">
          <button type="button" class="sp-settings-item-header" id="sp-btn-toggle-legend" style="padding:6px 10px; font-size:11px; background:var(--bg-surface);">
            <div class="sp-settings-item-left">
              <span class="sp-settings-item-title" style="font-size:11px; font-weight:600;">${s("security.legend_title")}</span>
            </div>
            <span class="sp-settings-item-arrow">${ie}</span>
          </button>
          ${n.isSecurityLegendOpen?`
            <div style="padding:8px 10px; background:var(--bg-card); font-size:11px; display:flex; flex-direction:column; gap:6px; border-top:1px solid var(--border-subtle);">
              <div style="display:flex; align-items:flex-start; gap:8px;">
                <span class="sp-pill-dot" style="background:var(--danger); box-shadow:0 0 4px var(--danger); margin-top:4px;"></span>
                <div>
                  <strong style="color:var(--text-main);">${s("security.legend_reused_title")}</strong>:
                  <span style="color:var(--text-dim);">${s("security.legend_reused_desc")}</span>
                </div>
              </div>
              <div style="display:flex; align-items:flex-start; gap:8px;">
                <span class="sp-pill-dot" style="background:var(--warning); box-shadow:0 0 4px var(--warning); margin-top:4px;"></span>
                <div>
                  <strong style="color:var(--text-main);">${s("security.legend_weak_title")}</strong>:
                  <span style="color:var(--text-dim);">${s("security.legend_weak_desc")}</span>
                </div>
              </div>
              <div style="display:flex; align-items:flex-start; gap:8px;">
                <span class="sp-pill-dot" style="background:var(--accent); box-shadow:0 0 4px var(--accent); margin-top:4px;"></span>
                <div>
                  <strong style="color:var(--text-main);">${s("security.legend_strong_title")}</strong>:
                  <span style="color:var(--text-dim);">${s("security.legend_strong_desc")}</span>
                </div>
              </div>
            </div>
          `:""}
        </div>

        <!-- Filter Search Bar -->
        <div class="sp-search-bar" style="padding:0; margin:0;">
          <div class="sp-search-input-wrap">
            <span class="sp-search-icon">${Qe}</span>
            <input type="text" id="sp-security-search" class="sp-search-input" placeholder="${s("security.search_placeholder")}" value="${C(n.securitySearchQuery||"")}" />
            ${n.securitySearchQuery?`<button class="sp-search-clear" id="sp-security-search-clear">${X}</button>`:""}
          </div>
        </div>

        <!-- Risk Filter Pills (Styled matching category tag pills) -->
        <div class="sp-cat-pills-wrap" style="padding:0; margin:0;">
          <div class="sp-cat-pills-scroll" style="display:flex; gap:6px; overflow-x:auto; padding-bottom:2px;">
            <button type="button" class="sp-pill-risk sp-pill-risk-all ${o==="all"?"active":""}" data-action="filter-risk" data-risk="all">
              <span>${s("security.filter_all")}</span>
              <span style="opacity:0.75; font-size:10px;">(${t.total})</span>
            </button>
            <button type="button" class="sp-pill-risk sp-pill-risk-reused ${o==="reused"?"active":""}" data-action="filter-risk" data-risk="reused">
              <span class="sp-pill-dot" style="background:var(--danger); box-shadow:0 0 4px var(--danger);"></span>
              <span>${s("security.filter_reused")}</span>
              <span style="opacity:0.75; font-size:10px;">(${t.reusedCount})</span>
            </button>
            <button type="button" class="sp-pill-risk sp-pill-risk-weak ${o==="weak"?"active":""}" data-action="filter-risk" data-risk="weak">
              <span class="sp-pill-dot" style="background:var(--warning); box-shadow:0 0 4px var(--warning);"></span>
              <span>${s("security.filter_weak")}</span>
              <span style="opacity:0.75; font-size:10px;">(${t.weakCount})</span>
            </button>
            <button type="button" class="sp-pill-risk sp-pill-risk-strong ${o==="strong"?"active":""}" data-action="filter-risk" data-risk="strong">
              <span class="sp-pill-dot" style="background:var(--accent); box-shadow:0 0 4px var(--accent);"></span>
              <span>${s("security.filter_strong")}</span>
              <span style="opacity:0.75; font-size:10px;">(${t.strongCount})</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Dedicated Scrollable Container for Password Cards Only -->
      <div id="sp-security-cards-container" style="flex:1; min-height:0; overflow-y:auto; padding:10px 16px 16px; display:flex; flex-direction:column; gap:8px;">
        ${d}
      </div>
    </div>
  `}function tn(){const e=c.trash||[];if(e.length===0)return`
      <div style="padding:14px; text-align:center; color:var(--text-dim); font-size:12px;">
        <div style="font-size:24px; margin-bottom:6px; opacity:0.6;">${pe}</div>
        <p>${s("trash.empty")}</p>
        <p style="font-size:11px; margin-top:4px; opacity:0.8;">${s("trash.desc")}</p>
      </div>
    `;const t=e.map(a=>{const o=a.deletedAt?new Date(a.deletedAt).getTime():Date.now(),i=Date.now()-o,r=Math.max(1,Math.ceil((30*24*60*60*1e3-i)/(24*60*60*1e3))),d=s("trash.days_left",{count:r});return`
        <div class="sp-trash-item" style="display:flex; align-items:center; justify-content:space-between; gap:10px; padding:10px 12px; background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-sm); margin-bottom:8px;">
          <div style="min-width:0; flex:1;">
            <div style="display:flex; align-items:center; gap:6px;">
              <span style="font-size:13px; font-weight:600; color:var(--text-main); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                ${C(a.title||"Untitled")}
              </span>
              <span class="sp-badge-info" style="font-size:10px; padding:2px 6px;">${d}</span>
            </div>
            <div style="font-size:11px; color:var(--text-dim); margin-top:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${C(a.username||a.domain||a.url||"")}
            </div>
          </div>
          <div style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
            <button type="button" class="sp-btn-secondary" data-action="restore-trash-item" data-id="${C(a.id)}" style="padding:4px 8px; font-size:11px;" title="${s("trash.restore_btn")}">
              ${bt}
              <span>${s("trash.restore_btn")}</span>
            </button>
            <button type="button" class="sp-btn-icon" data-action="delete-perm-trash-item" data-id="${C(a.id)}" style="color:var(--danger); padding:4px;" title="${s("trash.delete_perm_btn")}">
              ${pe}
            </button>
          </div>
        </div>
      `}).join("");return`
    <div style="display:flex; flex-direction:column; gap:8px;">
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:4px;">
        <p class="sp-setting-desc" style="margin:0; font-size:11px;">${s("trash.desc")}</p>
        <button type="button" class="sp-btn-danger" id="sp-btn-empty-trash" style="padding:4px 8px; font-size:11px; flex-shrink:0; margin-left:8px;">
          ${pe}
          <span>${s("trash.empty_btn")}</span>
        </button>
      </div>
      <div style="display:flex; flex-direction:column;">
        ${t}
      </div>
    </div>
  `}function sn(){var w,$,E,T,O,v,_;const e=n.settingsSearchQuery.toLowerCase().trim();let t=s("settings.session_active");if(c.lockInterval==="session")t=s("settings.session_active_browser");else if(c.sessionExpiresAt){const f=c.sessionExpiresAt-Date.now();if(f>0){const I=Math.round(f/36e5);if(I>=24){const B=Math.round(I/24);t=s("settings.session_active_days",{days:B})}else t=s("settings.session_active_hours",{hours:I})}else t=s("settings.session_expired")}const a={session:s("settings.interval_session"),"15m":s("settings.interval_15m"),"1h":s("settings.interval_1h"),"8h":s("settings.interval_8h"),"1day":s("settings.interval_1day")},o=a[c.lockInterval]||a.session,i=c.autolockMinutes!==void 0?Number(c.autolockMinutes):15,r={0:s("settings.autolock_off"),1:s("settings.autolock_1m"),5:s("settings.autolock_5m"),15:s("settings.autolock_15m"),30:s("settings.autolock_30m")},d=r[i]||r[15],u=c.theme==="dark",l=va(),p=_t.find(f=>f.code===l)||_t[0],m=`
    <div class="sp-setting-row" data-search="language язык мова беларуская қазақша 中文 日本語 हिन्दी hindi english интерфейс switch">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.language_label")}</span>
        <span class="sp-badge-info">${p.code.toUpperCase()}</span>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.language_desc")}
      </p>
      <div class="sp-setting-control">
        <div class="sp-custom-select ${n.isLangSelectOpen?"open":""}" id="sp-setting-lang-dropdown">
          <button type="button" class="sp-custom-select-trigger" id="sp-custom-lang-trigger" aria-haspopup="listbox" aria-expanded="${n.isLangSelectOpen}">
            <span class="sp-custom-select-value">${p.flag} ${p.name}</span>
            <span class="sp-custom-select-arrow">${ie}</span>
          </button>
          <div class="sp-custom-select-dropdown">
            ${_t.map(f=>{const I=f.code===l;return`
                <div class="sp-custom-select-option ${I?"selected":""}" data-val="${f.code}">
                  <span>${f.flag} ${f.name}</span>
                  ${I?`<span style="color:var(--text-main);">${G}</span>`:""}
                </div>
              `}).join("")}
          </div>
        </div>
      </div>
    </div>

    <div class="sp-setting-row" data-search="тема оформления темная светлая cloud dancer darkest hour вид интерфейс переключатель theme dark light">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.theme_label")}</span>
        <label class="sp-liquid-switch">
          <input type="checkbox" id="sp-theme-toggle" ${u?"checked":""} />
          <span class="sp-liquid-slider"></span>
        </label>
      </div>
      <p class="sp-setting-desc">
        ${s(u?"settings.theme_dark_desc":"settings.theme_light_desc")}
      </p>
    </div>

    <div class="sp-setting-row" data-search="фавикон favicon иконки сайтов карточки отображение favicons icons cards show hide">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.show_favicons_label")}</span>
        <label class="sp-liquid-switch">
          <input type="checkbox" id="sp-show-favicons-toggle" ${c.showFavicons?"checked":""} />
          <span class="sp-liquid-slider"></span>
        </label>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.show_favicons_desc")}
      </p>
    </div>

    <div class="sp-setting-row" data-search="внешние сервисы иконок google duckduckgo external icon services">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.external_icons_label")}</span>
        <label class="sp-liquid-switch">
          <input type="checkbox" id="sp-use-external-icons-toggle" ${c.useExternalIcons?"checked":""} />
          <span class="sp-liquid-slider"></span>
        </label>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.external_icons_desc")}
      </p>
    </div>

    <div class="sp-setting-row" data-search="текущий сайт вкладка активная домен автозаполнение tabs current site">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.current_site_label")}</span>
        <label class="sp-liquid-switch">
          <input type="checkbox" id="sp-current-site-toggle" ${c.currentSiteEnabled&&c.hasTabsPermission?"checked":""} />
          <span class="sp-liquid-slider"></span>
        </label>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.current_site_desc")}
      </p>
    </div>
  `,h=`
    <div class="sp-setting-row" data-search="проверка пароля сессия тайм-аут 3 дня день неделя месяц безопасность security session">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.master_pwd_check")}</span>
        <span class="sp-badge-info">${c.lockInterval||"session"}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.master_pwd_check_desc")}</p>
      <div class="sp-setting-control">
        <div class="sp-custom-select ${n.isCustomSelectOpen?"open":""}" id="sp-setting-lock-interval-dropdown">
          <button type="button" class="sp-custom-select-trigger" id="sp-custom-lock-trigger">
            <span class="sp-custom-select-value">${o}</span>
            <span class="sp-custom-select-arrow">${ie}</span>
          </button>
          <div class="sp-custom-select-dropdown">
            <div class="sp-custom-select-option ${c.lockInterval==="session"?"selected":""}" data-val="session">
              <span>${s("settings.interval_session")}</span>
              ${c.lockInterval==="session"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${c.lockInterval==="15m"?"selected":""}" data-val="15m">
              <span>${s("settings.interval_15m")}</span>
              ${c.lockInterval==="15m"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${c.lockInterval==="1h"?"selected":""}" data-val="1h">
              <span>${s("settings.interval_1h")}</span>
              ${c.lockInterval==="1h"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${c.lockInterval==="8h"?"selected":""}" data-val="8h">
              <span>${s("settings.interval_8h")}</span>
              ${c.lockInterval==="8h"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${c.lockInterval==="1day"?"selected":""}" data-val="1day">
              <span>${s("settings.interval_1day")}</span>
              ${c.lockInterval==="1day"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
          </div>
        </div>
        ${c.lockInterval==="1day"?`<p style="font-size:10px; color:var(--text-dim); margin-top:5px; line-height:1.3;">⚠️ ${s("settings.interval_1day_warning")}</p>`:""}
      </div>
    </div>

    <div class="sp-setting-row" data-search="автоблокировка бездействие inactivity autolock security">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.autolock_title")}</span>
        <span class="sp-badge-info">${i===0?"off":i+"m"}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.autolock_desc")}</p>
      <div class="sp-setting-control">
        <div class="sp-custom-select ${n.isAutolockSelectOpen?"open":""}" id="sp-setting-autolock-dropdown">
          <button type="button" class="sp-custom-select-trigger" id="sp-custom-autolock-trigger">
            <span class="sp-custom-select-value">${d}</span>
            <span class="sp-custom-select-arrow">${ie}</span>
          </button>
          <div class="sp-custom-select-dropdown">
            <div class="sp-custom-select-option ${i===1?"selected":""}" data-val="1">
              <span>${s("settings.autolock_1m")}</span>
              ${i===1?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${i===5?"selected":""}" data-val="5">
              <span>${s("settings.autolock_5m")}</span>
              ${i===5?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${i===15?"selected":""}" data-val="15">
              <span>${s("settings.autolock_15m")}</span>
              ${i===15?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${i===30?"selected":""}" data-val="30">
              <span>${s("settings.autolock_30m")}</span>
              ${i===30?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${i===0?"selected":""}" data-val="0">
              <span>${s("settings.autolock_off")}</span>
              ${i===0?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="sp-setting-row" data-search="статус сессия время активности status session active">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.session_status_label")}</span>
        <span style="font-size:11px; font-weight:600; color:var(--success);">${t}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.session_status_desc")}</p>
    </div>

    <div class="sp-setting-row" data-search="сменить мастер пароль ключ безопасность change password">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.master_pwd_label")}</span>
        <button class="sp-btn-secondary" id="sp-btn-toggle-change-pwd" style="padding:4px 8px; font-size:11px;">
          ${n.isChangePwdOpen?s("form.cancel_btn"):s("settings.change_pwd_btn")}
        </button>
      </div>
      <p class="sp-setting-desc">${s("settings.master_pwd_desc")}</p>

      ${n.isChangePwdOpen?`
        <form id="sp-change-pwd-form" style="display:flex; flex-direction:column; gap:8px; margin-top:8px; padding:10px; background:var(--bg-surface); border-radius:var(--radius-sm); border:1px solid var(--border-subtle);">
          <input type="password" id="sp-pwd-old" class="sp-input" placeholder="${s("settings.current_pwd_placeholder")}" required />
          <input type="password" id="sp-pwd-new" class="sp-input" placeholder="${s("settings.new_pwd_placeholder")}" required />
          <div id="sp-pwd-new-strength"></div>
          <input type="password" id="sp-pwd-new2" class="sp-input" placeholder="${s("settings.repeat_new_pwd_placeholder")}" required />
          <div id="sp-change-pwd-err" style="display:none; font-size:11px; color:var(--danger);"></div>
          <button type="submit" class="sp-btn-primary" style="justify-content:center; padding:6px 12px; margin-top:4px;">
            ${s("settings.save_new_pwd_btn")}
          </button>
        </form>
      `:""}
    </div>

    <div class="sp-setting-row" data-search="заблокировать блокировка выйти заморозить lock vault">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.lock_vault_label")}</span>
        <button class="sp-btn-danger" id="sp-btn-lock-now" style="padding:4px 10px; font-size:11px;">
          ${s("settings.lock_now_btn")}
        </button>
      </div>
      <p class="sp-setting-desc">${s("settings.lock_vault_desc")}</p>
    </div>
  `,g=me(),k=!!(c.passHostStatus&&c.passHostStatus.ok),y=`
    <div class="sp-setting-row" data-search="база данных проект хранилище active project pass">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.current_db_label")}</span>
        <div style="display:flex; align-items:center; gap:6px;">
          <span class="sp-badge-info">${g?C(g.name):"—"}</span>
          ${g&&g.type==="pass_cli"?`<span class="sp-badge-pass">${s("settings.badge_pass_cli")}</span>`:`<span class="sp-badge-browser">${s("settings.badge_browser")}</span>`}
        </div>
      </div>
      <p class="sp-setting-desc">${s("settings.db_stats_desc",{projects:c.projects.length,items:ge().length})}</p>
      <div class="sp-setting-control">
        <button class="sp-btn-secondary" id="sp-btn-open-switcher" style="width:100%; justify-content:center;">
          ${s("settings.manage_dbs_btn")}
        </button>
      </div>
    </div>

    <div class="sp-setting-row" data-search="хранилище тип локальное браузер pass cli синхронизация gpg native">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.pass_cli_label")}</span>
        <span style="font-size:11px; font-weight:600; color:${k?"var(--success)":"#f59e0b"};">
          ${k?s("settings.pass_connected",{version:c.passHostStatus.version}):s("settings.pass_not_connected")}
        </span>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.pass_desc")}
      </p>

      <div class="sp-host-status-box">
        <div style="display:flex; justify-content:space-between;">
          <span style="color:var(--text-dim);">${s("settings.store_path_label")}</span>
          <span><code>${((w=c.passHostStatus)==null?void 0:w.storePath)||"~/.password-store"}</code></span>
        </div>
        <div style="display:flex; justify-content:space-between;">
          <span style="color:var(--text-dim);">${s("settings.pass_tool_label")}</span>
          <span style="color:${($=c.passHostStatus)!=null&&$.passInstalled?"var(--success)":"var(--danger)"};">
            ${(E=c.passHostStatus)!=null&&E.passInstalled?s("settings.tool_installed"):s("settings.tool_not_found")}
          </span>
        </div>
        <div style="display:flex; justify-content:space-between;">
          <span style="color:var(--text-dim);">${s("settings.gpg_tool_label")}</span>
          <span style="color:${(T=c.passHostStatus)!=null&&T.gpgInstalled?"var(--success)":"var(--danger)"};">
            ${(O=c.passHostStatus)!=null&&O.gpgInstalled?s("settings.tool_installed"):s("settings.tool_not_found")}
          </span>
        </div>
        <div style="display:flex; justify-content:space-between;">
          <span style="color:var(--text-dim);">${s("settings.pass_entries_label")}</span>
          <span style="font-weight:600;">${((v=c.passHostStatus)==null?void 0:v.entriesCount)??0}</span>
        </div>
      </div>

      <div style="display:flex; gap:8px; margin-top:4px;">
        <button class="sp-btn-secondary" id="sp-btn-check-pass-host" style="flex:1; justify-content:center; font-size:11px; padding:6px 8px;">
          ${c.hasNativeMessagingPermission?s("settings.check_status_btn"):s("settings.connect_pass_btn")}
        </button>
        <button class="sp-btn-secondary" id="sp-btn-show-pass-instructions" style="flex:1; justify-content:center; font-size:11px; padding:6px 8px;">
          ${s("settings.instructions_btn")}
        </button>
      </div>

      ${g&&g.type==="pass_cli"?`
        <button class="sp-btn-primary" id="sp-btn-sync-active-pass" style="width:100%; justify-content:center; font-size:11px; padding:7px 10px; margin-top:4px;">
          ${s("settings.sync_pass_btn")}
        </button>
      `:""}
    </div>
  `,b=c.categories.filter(f=>f!=="All"),j=b.map(f=>{const I=f==="Work"||f==="Personal",B=f==="Work"?s("categories.Work"):f==="Personal"?s("categories.Personal"):f,U=Oe(f,c.categoryColors),H=Ve(U),K=n.activeColorPickerCat===f;return n.editingTagId===f?`
        <div class="sp-cat-item-wrap">
          <div class="sp-cat-item">
            <div style="display:flex; align-items:center; gap:6px; flex:1;">
              <input type="text" class="sp-input" id="sp-rename-tag-input" value="${C(f)}" maxlength="30" style="padding:4px 8px; font-size:12px; height:28px; flex:1;" />
              <button type="button" class="sp-btn-primary" id="sp-btn-save-tag-rename" data-old-name="${C(f)}" style="padding:4px 8px; font-size:11px; height:28px;" title="${s("form.save_btn")}">
                ${G}
              </button>
              <button type="button" class="sp-btn-secondary" id="sp-btn-cancel-tag-rename" style="padding:4px 8px; font-size:11px; height:28px;" title="${s("nav.close")}">
                ${X}
              </button>
            </div>
          </div>
          <div id="sp-rename-tag-err" style="display:none; font-size:11px; color:var(--danger); padding:0 4px; margin-top:2px;"></div>
        </div>
      `:`
      <div class="sp-cat-item-wrap">
        <div class="sp-cat-item ${I?"default":""}">
          <div style="display:flex; align-items:center; gap:8px;">
            <span class="sp-pill" data-color-pill="true" style="${H}; pointer-events:none; padding:3px 8px; font-size:11px;">
              <span class="sp-pill-dot" style="background-color:${U.color};"></span>
              <span>${C(B)}</span>
            </span>
            ${I?`<span style="font-size:10px; color:var(--text-dim);">${s("settings.default_cat_badge")}</span>`:""}
          </div>
          <div style="display:flex; align-items:center; gap:4px;">
            <button type="button" class="sp-cat-color-btn" data-action="toggle-cat-color-picker" data-cat="${C(f)}" style="background-color:${U.color};" title="${s("settings.change_color_title")}"></button>
            <button type="button" class="sp-cat-edit-btn" data-action="start-tag-rename" data-cat="${C(f)}" title="${s("settings.rename_cat_title")}">${qt}</button>
            ${I?"":`<button type="button" class="sp-cat-del-btn" data-cat="${C(f)}" title="${s("form.delete_btn")}">${pe}</button>`}
          </div>
        </div>
        ${K?`
          <div class="sp-cat-edit-palette">
            <span style="font-size:11px; color:var(--text-dim); margin-right:4px;">${s("settings.new_cat_color_label")}</span>
            <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
              ${Object.values(lt).map(Q=>`
                <button type="button" class="sp-color-swatch-sm ${Q.id===(c.categoryColors[f]||dt[f]||"slate")?"selected":""}" data-action="set-cat-color" data-cat="${C(f)}" data-color-id="${Q.id}" style="background-color:${Q.color};" title="${Q.name}">
                  ${Q.id===(c.categoryColors[f]||dt[f]||"slate")?G:""}
                </button>
              `).join("")}
            </div>
          </div>
        `:""}
      </div>
    `}).join(""),F=`
    <div class="sp-setting-row" data-search="метки теги карточки показывать скрывать отображение tags badge pills cards show hide">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.show_card_tags_label")}</span>
        <label class="sp-liquid-switch">
          <input type="checkbox" id="sp-show-card-tags-toggle" ${c.showCardTags?"checked":""} />
          <span class="sp-liquid-slider"></span>
        </label>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.show_card_tags_desc")}
      </p>
    </div>

    <div class="sp-setting-row" data-search="метки теги tags categories папки work personal создать добавить цвет tone переименовать">
      <p class="sp-setting-desc" style="margin-top:0;">${s("settings.categories_desc")}</p>

      <div class="sp-cat-list">
        ${j}
      </div>

      <div style="margin-top:14px; padding-top:12px; border-top:1px dashed var(--border-subtle); display:flex; flex-direction:column; gap:8px;">
        <span style="font-size:11px; font-weight:600; color:var(--text-muted);">${s("settings.new_cat_color_label")}</span>
        <div class="sp-color-palette" id="sp-new-cat-palette">
          ${Object.values(lt).map(f=>{const I=f.id===n.selectedNewCatColor;return`
              <button type="button" class="sp-color-swatch ${I?"selected":""}" data-action="select-new-cat-color" data-color-id="${f.id}" style="background-color:${f.color};" title="${f.name}">
                ${I?G:""}
              </button>
            `}).join("")}
        </div>

        <div style="display:flex; gap:6px; margin-top:2px;">
          <input type="text" id="sp-new-cat-name" class="sp-input" placeholder="${s("settings.new_cat_placeholder")}" maxlength="30" style="flex:1;" />
          <button type="button" class="sp-btn-primary" id="sp-btn-add-cat" style="white-space:nowrap; padding:6px 12px; font-size:12px;">
            ${s("settings.add_cat_btn")}
          </button>
        </div>
        <div id="sp-cat-err" style="display:none; font-size:11px; color:var(--danger); margin-top:4px;"></div>
      </div>
    </div>
  `,M=ge(),R=Array.from(new Set([...c.categories.filter(f=>f!=="All"),...M.flatMap(f=>le(f))])).filter(Boolean),A=R.length>0?R.map(f=>{const I=n.exportSelectedTags.has(f),B=Oe(f,c.categoryColors),U=Ve(B),H=M.filter(ee=>le(ee).includes(f)).length,K=f==="Work"?s("categories.Work"):f==="Personal"?s("categories.Personal"):f;return`
          <button type="button"
            class="sp-pill ${I?"active":""}"
            data-color-pill="true"
            data-action="toggle-export-tag"
            data-tag="${C(f)}"
            style="${U}; font-size:11px; padding:3px 8px; cursor:pointer;"
            title="${H}">
            <span class="sp-pill-dot" style="background-color:${B.color};"></span>
            <span>${C(K)}</span>
            <span style="font-size:10px; opacity:0.75;">(${H})</span>
            ${I?`<span style="margin-left:2px; display:inline-flex; align-items:center;">${G}</span>`:""}
          </button>
        `}).join(""):`<span style="font-size:11px; color:var(--text-muted); font-style:italic;">${s("settings.export_no_tags_available")}</span>`;let V="";if(n.exportSelectedTags.size===0)V=s("settings.export_tags_none_selected",{count:M.length});else{const f=M.filter(I=>le(I).some(U=>n.exportSelectedTags.has(U))).length;V=s("settings.export_tags_selected_count",{count:f,total:M.length})}const D=`
    <div class="sp-setting-row" data-search="экспорт export json csv метки tags фильтр">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.export_title")}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.export_desc")}</p>
      <div class="sp-setting-control" style="display:flex; gap:8px; align-items:center;">
        <button class="sp-btn-secondary" id="sp-btn-export-unified" style="flex:1; justify-content:center;">
          ${s("settings.csv_export_btn")}
        </button>
        <div class="sp-custom-select sp-custom-select-sm ${n.isExportFormatSelectOpen?"open":""}" id="sp-export-format-dropdown" style="width:125px; flex-shrink:0;">
          <button type="button" class="sp-custom-select-trigger" id="sp-export-format-trigger" aria-haspopup="listbox" aria-expanded="${n.isExportFormatSelectOpen}">
            <span class="sp-custom-select-value">${n.selectedExportFormat==="spbackup"?".SPBACKUP":n.selectedExportFormat.toUpperCase()}</span>
            <span class="sp-custom-select-arrow">${ie}</span>
          </button>
          <div class="sp-custom-select-dropdown" style="min-width:125px;">
            <div class="sp-custom-select-option ${n.selectedExportFormat==="spbackup"?"selected":""}" data-val="spbackup" style="font-size:12px; padding:6px 10px;">
              <span>🔒 .spbackup</span>
              ${n.selectedExportFormat==="spbackup"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${n.selectedExportFormat==="json"?"selected":""}" data-val="json" style="font-size:12px; padding:6px 10px;">
              <span>JSON</span>
              ${n.selectedExportFormat==="json"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
            <div class="sp-custom-select-option ${n.selectedExportFormat==="csv"?"selected":""}" data-val="csv" style="font-size:12px; padding:6px 10px;">
              <span>CSV</span>
              ${n.selectedExportFormat==="csv"?`<span style="color:var(--text-main);">${G}</span>`:""}
            </div>
          </div>
        </div>
      </div>

      <div style="margin-top:8px;">
        <button type="button" class="sp-export-advanced-toggle" id="sp-export-advanced-toggle" style="background:none; border:none; padding:0; display:inline-flex; align-items:center; gap:5px; font-size:11px; color:var(--text-dim); cursor:pointer; text-decoration:none; transition:color 0.15s ease;">
          <span class="sp-settings-item-arrow ${n.isExportAdvancedOpen?"open":""}" style="display:inline-flex; align-items:center; transform:${n.isExportAdvancedOpen?"rotate(180deg)":"rotate(0deg)"}; transition:transform 0.2s cubic-bezier(0.2, 0.8, 0.2, 1);">${ie}</span>
          <span style="text-decoration:underline;">${s("settings.export_advanced_link")}</span>
          ${n.exportSelectedTags.size>0?`<span class="sp-badge-info" style="font-size:10px; padding:1px 5px; margin-left:2px;">${n.exportSelectedTags.size}</span>`:""}
        </button>
      </div>

      ${n.isExportAdvancedOpen?`
        <div class="sp-export-advanced-panel" style="margin-top:10px; padding:12px; background:var(--bg-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-sm); display:flex; flex-direction:column; gap:10px;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:11px; font-weight:600; color:var(--text-main);">${s("settings.export_by_tags_title")}</span>
            <div style="display:flex; gap:10px;">
              <button type="button" id="sp-export-select-all-tags" style="background:none; border:none; padding:0; font-size:11px; color:var(--accent); cursor:pointer; text-decoration:underline;">${s("settings.export_select_all")}</button>
              <button type="button" id="sp-export-clear-tags" style="background:none; border:none; padding:0; font-size:11px; color:var(--text-dim); cursor:pointer; text-decoration:underline;">${s("settings.export_clear_tags")}</button>
            </div>
          </div>

          <div class="sp-export-tags-wrap" style="display:flex; flex-wrap:wrap; gap:6px;">
            ${A}
          </div>

          <div style="font-size:11px; color:var(--text-dim); border-top:1px dashed var(--border-subtle); padding-top:8px;">
            ${V}
          </div>
        </div>
      `:""}
    </div>

    <div class="sp-setting-row" data-search="импорт import json csv bitwarden">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.import_title")}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.import_desc")}</p>
      <div class="sp-setting-control">
        <input type="file" id="sp-import-unified-file-input" style="display:none;" accept=".json,.csv,text/csv,application/json,.txt" />
        <button class="sp-btn-secondary" id="sp-btn-trigger-import-unified" style="width:100%; justify-content:center;">
          ${s("settings.csv_import_btn")}
        </button>
      </div>
      <div style="margin-top:8px; display:flex; justify-content:flex-start;">
        <a href="#" id="sp-download-csv-template" style="font-size:11px; color:var(--text-dim); text-decoration:underline; cursor:pointer; display:inline-flex; align-items:center; gap:5px; transition:color 0.15s ease;">
          ${Ie} ${s("settings.csv_template_link")}
        </a>
      </div>
    </div>
  `,L=`
    <div class="sp-setting-row" data-search="версия simplepass лицензия open source mit инфо about">
      <div class="sp-setting-header">
        <span class="sp-setting-label">SimplePass Manager</span>
        <span class="sp-badge-info">v0.6</span>
      </div>
      <p class="sp-setting-desc">
        ${s("settings.about_desc")}
      </p>
    </div>

    <div class="sp-setting-row" data-search="шифрование криптография алгоритм aes pbkdf2 cryptography">
      <div class="sp-setting-header">
        <span class="sp-setting-label">${s("settings.crypto_spec_title")}</span>
      </div>
      <p class="sp-setting-desc" style="font-family:monospace; font-size:10px; line-height:1.5;">
        Algorithm: AES-256-GCM (12-byte random IV)<br>
        Derivation: PBKDF2 (SHA-256, 600,000 rounds)<br>
        Standard: W3C Web Cryptography API
      </p>
    </div>

    ${n.cachedVaultProfiles.length>1?`
    <div class="sp-setting-row" data-search="удалить текущую базу данных delete database">
      <div class="sp-setting-header">
        <span class="sp-setting-label" style="color:var(--danger);">${s("settings.delete_current_vault_btn")}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.delete_current_vault_desc")}</p>
      <div class="sp-setting-control">
        <button class="sp-btn-secondary" id="sp-btn-delete-current-vault" style="width:100%; justify-content:center; color:var(--danger); border-color:var(--danger);">
          ${pe} ${s("settings.delete_current_vault_btn")} (${C(((_=n.cachedVaultProfiles.find(f=>f.id===n.cachedActiveVaultId))==null?void 0:_.name)||"")})
        </button>
      </div>
    </div>
    `:""}

    <div class="sp-setting-row" data-search="сброс удалить все данные стереть очистить wipe danger reset">
      <div class="sp-setting-header">
        <span class="sp-setting-label" style="color:var(--danger);">${s("settings.wipe_data_label")}</span>
      </div>
      <p class="sp-setting-desc">${s("settings.wipe_data_desc")}</p>
      <div class="sp-setting-control">
        <button class="sp-btn-danger" id="sp-btn-reset-all" style="width:100%; justify-content:center;">
          ${s("settings.wipe_all_btn")}
        </button>
      </div>
    </div>
  `,N=[{id:"appearance",title:s("settings.appearance_section"),desc:s("settings.appearance_desc_short"),icon:Fa,content:m,keywords:"тема оформления темная светлая вид цвет language язык мова беларуская қазақша 中文 日本語 हिन्दी hindi english"},{id:"security",title:s("settings.security_section"),desc:s("settings.security_desc_short"),icon:ps,content:h,keywords:"пароль сессия 3 дня тайм-аут блокировка безопасность смена мастер-пароль"},{id:"databases",title:s("settings.db_section"),desc:s("settings.db_desc_short"),icon:wt,content:y,keywords:"база проект хранилище список pass синхронизация"},{id:"categories",title:s("settings.categories_section"),desc:s("settings.categories_desc_short"),icon:Ua,badge:b.length,content:F,keywords:"метки теги категории папки work personal создать добавить цвет tone карточки badge pills cards show hide"},{id:"backup",title:s("settings.backup_section"),desc:s("settings.backup_desc_short"),icon:Ie,content:D,keywords:"бэкап экспорт импорт json csv pass txt export backup plaintext"},{id:"trash",title:s("trash.title"),desc:s("trash.desc"),icon:pe,badge:c.trash&&c.trash.length?c.trash.length:void 0,content:tn(),keywords:"корзина trash deleted удаленные восстановить purge"},{id:"about",title:s("settings.about_section"),desc:s("settings.about_desc_short"),icon:Bt,content:L,keywords:"версия лицензия шифрование сброс о программе mit about"}].filter(f=>e?f.title.toLowerCase().includes(e)||f.desc&&f.desc.toLowerCase().includes(e)||f.keywords.toLowerCase().includes(e)||f.content.toLowerCase().includes(e):!0),x=N.length?`
      <div class="sp-settings-list">
        ${N.map(f=>{const I=e?!0:n.openSections.has(f.id);return`
            <div class="sp-settings-item ${I?"open":""}" data-section-id="${f.id}">
              <button type="button" class="sp-settings-item-header" data-action="toggle-section" data-section-id="${f.id}">
                <div class="sp-settings-item-left">
                  <span class="sp-settings-item-icon">${f.icon}</span>
                  <span class="sp-settings-item-title">${f.title}</span>
                  ${f.badge!==void 0?`<span class="sp-badge-info" style="margin-left:6px;">${f.badge}</span>`:""}
                </div>
                <span class="sp-settings-item-arrow">${ie}</span>
              </button>
              ${I?`
                <div class="sp-settings-item-body">
                  ${f.content}
                </div>
              `:""}
            </div>
          `}).join("")}
      </div>
    `:`
      <div class="sp-empty-state" style="height: 180px;">
        <div class="sp-empty-icon">${Qe}</div>
        <p style="font-size: 13px; font-weight: 600;">${s("settings.settings_not_found")}</p>
        <p style="font-size: 11px;">${s("settings.no_search_results",{query:C(n.settingsSearchQuery)})}</p>
      </div>
    `;return`
    <div style="display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden; flex:1;">
      <div class="sp-search-bar" style="padding: 10px 16px 6px;">
        <div class="sp-search-input-wrap">
          <span class="sp-search-icon">${Qe}</span>
          <input type="text" id="sp-settings-search" class="sp-search-input" placeholder="${s("settings.search_placeholder")}" value="${C(n.settingsSearchQuery)}" />
          ${n.settingsSearchQuery?`<button class="sp-search-clear" id="sp-settings-search-clear">${X}</button>`:""}
        </div>
      </div>

      <div class="sp-settings-container">
        ${x}
      </div>
    </div>
  `}function an(){const e=me(),t=c.projects.map(a=>{const o=e&&e.id===a.id,i=c.items.filter(d=>d.projectId===a.id).length,r=a.type==="pass_cli"?`<span class="sp-badge-pass">${s("settings.badge_pass_cli")}</span>`:`<span class="sp-badge-browser">${s("settings.badge_browser")}</span>`;return`
      <div class="sp-project-item ${o?"active":""}" data-project-id="${a.id}">
        <div class="sp-project-item-left" data-action="select-project" data-project-id="${a.id}">
          <div class="sp-radio-indicator"></div>
          <div class="sp-project-info">
            <div style="display:flex; align-items:center; gap:6px;">
              <span class="sp-project-name">${C(a.name)}</span>
              ${r}
            </div>
            <span class="sp-project-meta">${i} ${s("nav.passwords").toLowerCase()}</span>
          </div>
        </div>
        <div class="sp-project-item-actions">
          ${a.type==="pass_cli"?`<button class="sp-btn-icon" data-action="sync-pass-project" data-project-id="${a.id}" title="${s("settings.sync_pass_btn")}">${bt}</button>`:""}
          <button class="sp-btn-icon" data-action="rename-project" data-project-id="${a.id}" title="${s("settings.change_pwd_btn")}">${qt}</button>
          ${c.projects.length>1?`<button class="sp-btn-icon" data-action="delete-project" data-project-id="${a.id}" title="${s("form.delete_btn")}">${pe}</button>`:""}
        </div>
      </div>
    `}).join("");return`
    <div class="sp-project-switcher-panel ${c.isProjectSwitcherOpen?"open":""}" id="sp-project-panel">
      <div class="sp-panel-header">
        <span class="sp-panel-title">${wt} ${s("project_switcher.title")}</span>
        <button class="sp-btn-icon" id="sp-close-project-panel" title="${s("nav.close")}">${X}</button>
      </div>

      <div class="sp-project-list">
        ${t}
      </div>

      <div class="sp-new-project-card">
        <span style="font-size:11px; font-weight:700; color:var(--text-muted); text-transform:uppercase; display:block; margin-bottom:8px;">
          ${s("project_switcher.create_new")}
        </span>
        <form id="sp-create-project-form" style="display:flex; flex-direction:column; gap:8px;">
          <div style="display:flex; gap:8px;">
            <input type="text" id="sp-new-project-name" class="sp-input" placeholder="${s("project_switcher.name_placeholder")}" required style="flex:1;" />
            <button type="submit" class="sp-btn-primary" style="padding:8px 12px; white-space:nowrap;">
              ${_e} ${s("project_switcher.create_btn")}
            </button>
          </div>
          <div style="display:flex; align-items:center; gap:12px; margin-top:2px;">
            <label style="font-size:11px; color:var(--text-dim); display:flex; align-items:center; gap:4px; cursor:pointer;">
              <input type="radio" name="sp-new-project-type" value="browser" checked style="accent-color:var(--text-main);" />
              <span>${s("project_switcher.browser_type")}</span>
            </label>
            <label style="font-size:11px; color:var(--text-dim); display:flex; align-items:center; gap:4px; cursor:pointer;" title="${s("project_switcher.pass_type_title")}">
              <input type="radio" name="sp-new-project-type" value="pass_cli" style="accent-color:var(--text-main);" />
              <span>${s("project_switcher.pass_type")}</span>
            </label>
          </div>
        </form>
      </div>
    </div>
  `}function nn(){if(!c.projectToDelete)return"";const e=c.projectToDelete,t=c.items.filter(a=>a.projectId===e.id).length;return`
    <div class="sp-modal-overlay" id="sp-delete-modal-overlay">
      <div class="sp-modal-content">
        <div class="sp-modal-header">
          <span class="sp-modal-title">${pe} ${s("delete_modal.title")}</span>
          <button class="sp-btn-icon" id="sp-modal-cancel-btn" title="${s("nav.close")}">${X}</button>
        </div>

        <div class="sp-modal-danger-box">
          <strong>${s("delete_modal.warning_title")}</strong><br>
          ${s("delete_modal.desc",{name:C(e.name),count:t})}
        </div>

        <form id="sp-delete-project-form" style="display:flex; flex-direction:column; gap:10px;">
          <div class="sp-form-group">
            <label class="sp-label">${s("form.title_label")}: «<strong>${C(e.name)}</strong>»:</label>
            <input type="text" id="sp-delete-confirm-name" class="sp-input" placeholder="${C(e.name)}" required />
          </div>

          <div class="sp-form-group">
            <label class="sp-label">${s("settings.master_pwd_label")}:</label>
            <input type="password" id="sp-delete-confirm-pwd" class="sp-input" placeholder="${s("settings.master_pwd_label")}" required />
          </div>

          <div id="sp-delete-modal-error" style="display:none; font-size:11px; color:var(--danger);"></div>

          <div style="display:flex; gap:8px; margin-top:4px;">
            <button type="button" class="sp-btn-secondary" id="sp-modal-close-btn" style="flex:1; justify-content:center;">
              ${s("delete_modal.cancel_btn")}
            </button>
            <button type="submit" class="sp-btn-danger" style="flex:1; justify-content:center;">
              ${s("delete_modal.confirm_btn")}
            </button>
          </div>
        </form>
      </div>
    </div>
  `}function on(){return c.isShowPassInstructions?`
    <div class="sp-modal-overlay" id="sp-pass-instructions-overlay">
      <div class="sp-modal-content" style="max-width: 360px;">
        <div class="sp-modal-header">
          <span class="sp-modal-title" style="color:var(--text-main);">${wt} ${s("pass_modal.title")}</span>
          <button class="sp-btn-icon" id="sp-btn-close-pass-instructions">${X}</button>
        </div>

        <p class="sp-modal-desc">
          ${s("pass_modal.desc")}
        </p>

        <div style="display:flex; flex-direction:column; gap:8px; font-size:11px;">
          <div><strong>${s("pass_modal.step1")}</strong></div>
          <div class="sp-code-block">brew install pass gnupg</div>

          <div><strong>${s("pass_modal.step2")}</strong></div>
          <div class="sp-code-block">cd /Users/dima/Projects/SimplePassManager/native-host &amp;&amp; ./install.sh</div>

          <div><strong>${s("pass_modal.step3")}</strong></div>
          <div style="color:var(--text-dim); line-height:1.4;">
            ${s("pass_modal.step3_desc")}
          </div>
        </div>

        <button type="button" class="sp-btn-primary" id="sp-btn-ack-pass-instructions" style="justify-content:center; margin-top:6px;">
          ${s("pass_modal.got_it")}
        </button>
      </div>
    </div>
  `:""}function rn(){if(!n.newlyCreatedRecoveryPhrase)return"";const t=n.newlyCreatedRecoveryPhrase.split(" ").map((a,o)=>`
    <div class="sp-recovery-word-card">
      <span class="sp-recovery-word-num">${o+1}.</span>
      <span class="sp-recovery-word-val">${C(a)}</span>
    </div>
  `).join("");return`
    <div class="sp-modal-overlay" id="sp-recovery-backup-overlay" style="z-index: 300;">
      <div class="sp-modal-content" style="max-width: 360px;">
        <div class="sp-modal-header">
          <span class="sp-modal-title" style="color:var(--text-main);">${Xe} ${s("recovery_modal.title")}</span>
          <button class="sp-btn-icon" id="sp-recovery-modal-close" title="${s("nav.close")}">${X}</button>
        </div>

        <p style="font-size:12px; color:var(--text-muted); line-height:1.4;">
          ${s("recovery_modal.desc")}
        </p>

        <div class="sp-recovery-grid">
          ${t}
        </div>

        <div style="display:flex; gap:8px; margin-top:12px;">
          <button class="sp-btn-secondary" id="sp-btn-copy-recovery-phrase" style="flex:1; justify-content:center; font-size:12px;">
            ${yt} ${s("recovery_modal.copy_btn")}
          </button>
          <button class="sp-btn-secondary" id="sp-btn-download-recovery-phrase" style="flex:1; justify-content:center; font-size:12px;">
            ${Ie} ${s("recovery_modal.download_btn")}
          </button>
        </div>

        <button class="sp-btn-primary" id="sp-btn-confirm-recovery-saved" style="width:100%; justify-content:center; margin-top:12px;">
          ${G} ${s("recovery_modal.confirm_btn")}
        </button>
      </div>
    </div>
  `}function cn(){return n.exportModalData?n.exportModalData.format==="spbackup"?`
      <div class="sp-modal-overlay" id="sp-export-modal-overlay">
        <div class="sp-modal-content" style="max-width:360px;">
          <div class="sp-modal-header">
            <span class="sp-modal-title" style="color:var(--text-main);">${Gt} ${s("settings.export_spbackup_opt")}</span>
            <button class="sp-btn-icon" id="sp-export-modal-close" title="${s("nav.close")}">${X}</button>
          </div>
          <p style="font-size:12px; color:var(--text-muted); line-height:1.4;">
            ${s("settings.export_backup_pwd_label")}
          </p>
          <form id="sp-export-backup-form" style="display:flex; flex-direction:column; gap:10px; margin-top:8px;">
            <input type="password" id="sp-export-backup-pwd" class="sp-input" placeholder="${s("settings.export_backup_pwd_label")}" required autofocus />
            <div id="sp-export-modal-err" style="display:none; font-size:11px; color:var(--danger);"></div>
            <div style="display:flex; gap:8px; margin-top:6px;">
              <button type="button" class="sp-btn-secondary" id="sp-export-modal-cancel" style="flex:1; justify-content:center;">
                ${s("form.cancel_btn")}
              </button>
              <button type="submit" class="sp-btn-primary" style="flex:1; justify-content:center;">
                ${Ie} ${s("settings.csv_export_btn")}
              </button>
            </div>
          </form>
        </div>
      </div>
    `:`
    <div class="sp-modal-overlay" id="sp-export-modal-overlay">
      <div class="sp-modal-content" style="max-width:360px;">
        <div class="sp-modal-header">
          <span class="sp-modal-title" style="color:var(--danger);">${Ha} ${s("settings.export_warning_title")}</span>
          <button class="sp-btn-icon" id="sp-export-modal-close" title="${s("nav.close")}">${X}</button>
        </div>
        <div class="sp-modal-danger-box">
          ${s("settings.export_warning_desc")}
        </div>
        <form id="sp-export-plaintext-form" style="display:flex; flex-direction:column; gap:10px; margin-top:8px;">
          <div class="sp-form-group">
            <label class="sp-label">${s("settings.export_confirm_pwd_label")}</label>
            <input type="password" id="sp-export-confirm-pwd" class="sp-input" placeholder="${s("settings.master_pwd_label")}" required autofocus />
          </div>
          <div id="sp-export-modal-err" style="display:none; font-size:11px; color:var(--danger);"></div>
          <div style="display:flex; gap:8px; margin-top:6px;">
            <button type="button" class="sp-btn-secondary" id="sp-export-modal-cancel" style="flex:1; justify-content:center;">
              ${s("form.cancel_btn")}
            </button>
            <button type="submit" class="sp-btn-danger" style="flex:1; justify-content:center;">
              ${Ie} ${n.exportModalData.format.toUpperCase()}
            </button>
          </div>
        </form>
      </div>
    </div>
  `:""}function ln(){return n.importBackupData?`
    <div class="sp-modal-overlay" id="sp-import-backup-overlay">
      <div class="sp-modal-content" style="max-width:360px;">
        <div class="sp-modal-header">
          <span class="sp-modal-title" style="color:var(--text-main);">${Gt} ${s("settings.import_backup_pwd_label")}</span>
          <button class="sp-btn-icon" id="sp-import-backup-close" title="${s("nav.close")}">${X}</button>
        </div>
        <p style="font-size:12px; color:var(--text-muted); line-height:1.4;">
          ${s("settings.import_backup_pwd_label")}
        </p>
        <form id="sp-import-backup-form" style="display:flex; flex-direction:column; gap:10px; margin-top:8px;">
          <input type="password" id="sp-import-backup-pwd" class="sp-input" placeholder="${s("settings.import_backup_pwd_label")}" required autofocus />
          <div id="sp-import-backup-err" style="display:none; font-size:11px; color:var(--danger);"></div>
          <div style="display:flex; gap:8px; margin-top:6px;">
            <button type="button" class="sp-btn-secondary" id="sp-import-backup-cancel" style="flex:1; justify-content:center;">
              ${s("form.cancel_btn")}
            </button>
            <button type="submit" class="sp-btn-primary" style="flex:1; justify-content:center;">
              ${Tt} ${s("auth.unlock_btn")}
            </button>
          </div>
        </form>
      </div>
    </div>
  `:""}function dn(){return`
    ${an()}
    ${nn()}
    ${on()}
    ${rn()}
    ${cn()}
    ${ln()}
  `}function pn({onReRenderAuth:e,syncCachedFavicons:t}){if(!c.isInitialized){["sp-init-proj-name","sp-init-pwd","sp-init-pwd2"].forEach(p=>{const m=document.getElementById(p);m&&m.addEventListener("input",()=>{m.classList.remove("has-error");const h=document.getElementById(p.replace("sp-init-","sp-err-"));h&&(h.innerText="",h.style.display="none")})}),ot("sp-init-pwd","sp-init-pwd-strength");const l=document.getElementById("sp-init-form");l&&l.addEventListener("submit",async p=>{var k,y,b;p.preventDefault();const m=(k=document.getElementById("sp-init-proj-name"))==null?void 0:k.value,h=(y=document.getElementById("sp-init-pwd"))==null?void 0:y.value,g=(b=document.getElementById("sp-init-pwd2"))==null?void 0:b.value;await mn(m,h,g)});return}if(n.isCreatingNewVaultFromLock){["sp-new-db-name","sp-new-db-pwd","sp-new-db-pwd2"].forEach(m=>{const h=document.getElementById(m);h&&h.addEventListener("input",()=>{h.classList.remove("has-error");const g=document.getElementById(m.replace("sp-new-db-","sp-err-new-db-"));g&&(g.innerText="",g.style.display="none")})}),ot("sp-new-db-pwd","sp-new-db-pwd-strength");const l=document.getElementById("sp-btn-cancel-new-db");l&&l.addEventListener("click",()=>{n.isCreatingNewVaultFromLock=!1,e()});const p=document.getElementById("sp-new-db-form");p&&p.addEventListener("submit",async m=>{var y,b,j;m.preventDefault();const h=(y=document.getElementById("sp-new-db-name"))==null?void 0:y.value,g=(b=document.getElementById("sp-new-db-pwd"))==null?void 0:b.value,k=(j=document.getElementById("sp-new-db-pwd2"))==null?void 0:j.value;await gn(h,g,k)});return}if(n.isRecoveryViewActive){["sp-recover-phrase","sp-recover-new-pwd","sp-recover-new-pwd2"].forEach(k=>{const y=document.getElementById(k);y&&y.addEventListener("input",()=>{y.classList.remove("has-error");const b=document.getElementById(k.replace("sp-recover-","sp-err-recover-"));b&&(b.innerText="",b.style.display="none")})}),ot("sp-recover-new-pwd","sp-recover-new-pwd-strength");const l=document.getElementById("sp-recover-phrase"),p=document.getElementById("sp-recover-phrase-hints");l&&p&&l.addEventListener("input",()=>{const k=l.value.trim();if(!k){p.innerHTML="";return}const y=Ps(k),b=y.filter(j=>!j.valid);if(b.length===0){const j=y.length;p.innerHTML=`<span style="color:var(--success); font-size:11px;">✓ ${s("auth.words_recognized",{count:j})}</span>`}else p.innerHTML=b.map(j=>{const F=j.suggestion?` (${s("auth.suggest_word",{suggestion:C(j.suggestion)})})`:"";return`<div style="color:var(--danger, #ef4444); margin-bottom:2px; font-size:11px;">⚠️ ${s("auth.unknown_word",{word:C(j.word)})}${F}</div>`}).join("")});const m=document.getElementById("sp-btn-create-new-vault");m&&m.addEventListener("click",()=>{n.isRecoveryViewActive=!1,n.isCreatingNewVaultFromLock=!0,e()});const h=document.getElementById("sp-btn-cancel-recovery");h&&h.addEventListener("click",()=>{n.isRecoveryViewActive=!1,e()});const g=document.getElementById("sp-recovery-form");g&&g.addEventListener("submit",async k=>{var F,M,R;k.preventDefault();const y=(F=document.getElementById("sp-recover-phrase"))==null?void 0:F.value,b=(M=document.getElementById("sp-recover-new-pwd"))==null?void 0:M.value,j=(R=document.getElementById("sp-recover-new-pwd2"))==null?void 0:R.value;await hn(y,b,j,t)});return}if(n.isProfileSelectorViewActive){document.querySelectorAll(".sp-profile-select-item").forEach(m=>{m.addEventListener("click",async()=>{const h=m.dataset.vaultId;h&&h!==n.cachedActiveVaultId&&(n.cachedActiveVaultId=h,await Bs(h),n.failedAttempts=0,n.lockoutUntil=0,typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.remove(["sp_failed_attempts","sp_lockout_until"])),n.isProfileSelectorViewActive=!1,e()})});const l=document.getElementById("sp-btn-profile-create-new");l&&l.addEventListener("click",()=>{n.isProfileSelectorViewActive=!1,n.isCreatingNewVaultFromLock=!0,e()});const p=document.getElementById("sp-btn-cancel-profile-select");p&&p.addEventListener("click",()=>{n.isProfileSelectorViewActive=!1,e()});return}n.lockoutTimer&&(clearInterval(n.lockoutTimer),n.lockoutTimer=null),Ae()>0&&(n.lockoutTimer=setInterval(()=>{const l=Ae(),p=document.getElementById("sp-lockout-seconds");p&&(p.innerText=l),l<=0&&(clearInterval(n.lockoutTimer),n.lockoutTimer=null,e())},1e3));const i=document.getElementById("sp-switch-profile");i&&i.addEventListener("click",()=>{n.isProfileSelectorViewActive=!0,e()});const r=document.getElementById("sp-unlock-pwd");r&&r.addEventListener("input",()=>{r.classList.remove("has-error");const l=document.getElementById("sp-err-unlock");l&&(l.innerText="",l.style.display="none")});const d=document.getElementById("sp-forgot-pwd");d&&d.addEventListener("click",()=>{n.isRecoveryViewActive=!0,e()});const u=document.getElementById("sp-unlock-form");u&&u.addEventListener("submit",async l=>{var m;if(l.preventDefault(),Ae()>0)return;const p=((m=document.getElementById("sp-unlock-pwd"))==null?void 0:m.value)||"";await un(p,{onReRenderAuth:e,syncCachedFavicons:t})})}async function un(e,{onReRenderAuth:t,syncCachedFavicons:a}){ft();const o=Ae();if(o>0){oe("sp-unlock-pwd","sp-err-unlock",s("auth.lockout_wait",{seconds:o})),t();return}if(!e){oe("sp-unlock-pwd","sp-err-unlock",s("auth.pwd_empty"));return}try{const i=await Ee();let r=null,d=null,u=null;if((i.version===2||i.version===3)&&i.keyByPassword)if(r=await Je(i,e),u=await mt(i,r),i.version===2){const g=await Z(r,e,"mek-pwd"),k=i.keyByRecovery?{...i.keyByRecovery,aad:!1}:null;d={keyByPassword:g,keyByRecovery:k};const y=await xe(u,r,d);await De(y)}else d={keyByPassword:i.keyByPassword,keyByRecovery:i.keyByRecovery};else{u=await Ge(i,e),r=ut();const g=pt(),k=await Z(r,e,"mek-pwd"),y=await Z(r,Ne(g),"mek-rec");d={keyByPassword:k,keyByRecovery:y};const b=await xe(u,r,d);await De(b),n.newlyCreatedRecoveryPhrase=g,S(s("toasts.vault_migrated_v3"))}const l=ht(u);a&&a(l.items);const p=await q(),m=p.latestProjectId&&l.projects.some(g=>g.id===p.latestProjectId)?p.latestProjectId:l.projects[0].id;n.failedAttempts=0,n.lockoutUntil=0,typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.remove(["sp_failed_attempts","sp_lockout_until"]);const h=await Be(r,c.lockInterval||"session");P({isUnlocked:!0,rawMek:r,keySlots:d,projects:l.projects,items:l.items,trash:l.trash||[],activeProjectId:m,sessionExpiresAt:h.expiresAt})}catch{if(n.failedAttempts++,n.failedAttempts>=3){const d=Math.min(600,30*Math.pow(2,n.failedAttempts-3));n.lockoutUntil=Date.now()+d*1e3}if(typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.set({sp_failed_attempts:n.failedAttempts,sp_lockout_until:n.lockoutUntil}),Ae()>0)t();else{oe("sp-unlock-pwd","sp-err-unlock",s("auth.lockout_attempt_error",{current:n.failedAttempts}));const d=document.getElementById("sp-auth-links-wrap");d&&(d.style.display="flex")}}}async function mn(e,t,a,o){ft();const i=gt(t);if(!i.valid){oe("sp-init-pwd","sp-err-pwd",s(`auth.${i.errorCode}`)||i.error);return}if(t!==a){oe("sp-init-pwd2","sp-err-pwd2",s("auth.pwd_mismatch"));return}const r="proj_"+Date.now(),d=new Date().toISOString(),u=e&&e.trim()||"main",p={version:2,createdAt:d,updatedAt:d,projects:[{id:r,name:u,type:"browser",createdAt:d,updatedAt:d}],items:[{id:"item_sample_1",projectId:r,title:"GitHub",username:"developer@example.com",password:et({length:24}),url:"https://github.com",category:"Work",notes:"",updatedAt:d}]},m=pt(),h=ut(),g=await Z(h,t,"mek-pwd"),k=await Z(h,Ne(m),"mek-rec"),y={keyByPassword:g,keyByRecovery:k},b=await xe(p,h,y);await De(b),n.cachedVaultProfiles=await he(),n.cachedActiveVaultId=await Fe(),await W({activeProjectId:r,latestProjectId:r,lockInterval:"session"});const j=await Be(h,"session");n.failedAttempts=0,n.lockoutUntil=0,typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.remove(["sp_failed_attempts","sp_lockout_until"]),n.newlyCreatedRecoveryPhrase=m,P({isInitialized:!0,isUnlocked:!0,rawMek:h,keySlots:y,projects:p.projects,items:p.items,activeProjectId:r,sessionExpiresAt:j.expiresAt})}async function gn(e,t,a,o){ft();const i=gt(t);if(!i.valid){oe("sp-new-db-pwd","sp-err-new-db-pwd",s(`auth.${i.errorCode}`)||i.error);return}if(t!==a){oe("sp-new-db-pwd2","sp-err-new-db-pwd2",s("auth.pwd_mismatch"));return}const r="proj_"+Date.now(),d=new Date().toISOString(),u=e&&e.trim()||"Vault "+(n.cachedVaultProfiles.length+1),p={version:2,createdAt:d,updatedAt:d,projects:[{id:r,name:u,type:"browser",createdAt:d,updatedAt:d}],items:[{id:"item_sample_1",projectId:r,title:"SimplePass",username:"user@example.com",password:et({length:24}),url:"https://example.com",category:"Work",notes:"",updatedAt:d}]},m=pt(),h=ut(),g=await Z(h,t,"mek-pwd"),k=await Z(h,Ne(m),"mek-rec"),y={keyByPassword:g,keyByRecovery:k},b=await xe(p,h,y),j=await Ds(u,b);n.cachedVaultProfiles=await he(),n.cachedActiveVaultId=j.id;const F=await Be(h,"session");n.failedAttempts=0,n.lockoutUntil=0,typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.remove(["sp_failed_attempts","sp_lockout_until"]),n.isCreatingNewVaultFromLock=!1,n.isRecoveryViewActive=!1,n.newlyCreatedRecoveryPhrase=m,P({isInitialized:!0,isUnlocked:!0,rawMek:h,keySlots:y,projects:p.projects,items:p.items,activeProjectId:r,sessionExpiresAt:F.expiresAt})}async function hn(e,t,a,o){ft();const i=e?e.trim().toLowerCase().split(/\s+/).join(" "):"";if(!i||i.split(" ").length!==12){oe("sp-recover-phrase","sp-err-recover-phrase",s("auth.recovery_exact_words"));return}const r=gt(t);if(!r.valid){oe("sp-recover-new-pwd","sp-err-recover-pwd",s(`auth.${r.errorCode}`)||r.error);return}if(t!==a){oe("sp-recover-new-pwd2","sp-err-recover-pwd2",s("auth.pwd_mismatch"));return}try{const d=await Ee(),{vaultData:u,rawMek:l}=await As(d,i),p=ht(u);o&&o(p.items);const m=await Z(l,t,"mek-pwd"),h=pt(),g=await Z(l,Ne(h),"mek-rec"),k={keyByPassword:m,keyByRecovery:g},y=await xe(p,l,k);await De(y),n.failedAttempts=0,n.lockoutUntil=0,typeof chrome<"u"&&chrome.storage&&chrome.storage.session&&chrome.storage.session.remove(["sp_failed_attempts","sp_lockout_until"]);const b=await Be(l,"session");n.isRecoveryViewActive=!1,n.newlyCreatedRecoveryPhrase=h,P({isUnlocked:!0,rawMek:l,keySlots:k,projects:p.projects,items:p.items,trash:p.trash||[],activeProjectId:p.projects[0].id,sessionExpiresAt:b.expiresAt}),S(s("toasts.access_restored"))}catch{oe("sp-recover-phrase","sp-err-recover-phrase",s("auth.recovery_invalid_err"))}}function fn({renderApp:e}){const t=document.getElementById("sp-burger-btn"),a=document.getElementById("sp-close-drawer-btn"),o=document.getElementById("sp-drawer-overlay");t&&t.addEventListener("click",()=>{n.isDrawerOpen=!0,e()}),[a,o].forEach(u=>{u&&u.addEventListener("click",()=>{n.isDrawerOpen=!1,e()})}),document.querySelectorAll(".sp-drawer-item").forEach(u=>{u.addEventListener("click",()=>{const l=u.dataset.nav;n.isDrawerOpen=!1,l==="settings"&&(n.settingsSearchQuery=""),c.activeTab==="item-details"&&l!=="item-details"&&be(),P({activeTab:l,selectedItem:null,isProjectSwitcherOpen:!1})})});const i=document.getElementById("sp-btn-add");i&&i.addEventListener("click",()=>{be(),P({activeTab:"item-details",selectedItem:null})});const r=document.getElementById("sp-btn-lock");r&&r.addEventListener("click",()=>{je()});const d=document.getElementById("sp-project-container");d&&d.addEventListener("click",()=>{P({isProjectSwitcherOpen:!c.isProjectSwitcherOpen})})}function vn({updateActiveTabDomain:e,renderApp:t}){const a=document.getElementById("sp-search-input"),o=document.getElementById("sp-search-clear"),i=document.getElementById("sp-vault-cards-container");a&&a.addEventListener("input",l=>{const p=l.target.value;P({searchQuery:p}),o&&(o.style.display=p?"flex":"none"),i&&(i.innerHTML=ze())}),o&&o.addEventListener("click",()=>{a&&(a.value="",a.focus()),P({searchQuery:""}),o.style.display="none",i&&(i.innerHTML=ze())});const r=document.getElementById("sp-category-pills");r&&r.addEventListener("click",l=>{const p=l.target.closest(".sp-pill");if(!p)return;const m=p.dataset.cat;m&&(P({activeCategory:m}),r.querySelectorAll(".sp-pill").forEach(h=>{h.classList.toggle("active",h.dataset.cat===m)}),i&&(i.innerHTML=ze()))});const d=document.getElementById("sp-active-domain-banner");d&&d.addEventListener("click",()=>{const l=We(n.activeTabDomain);l&&(a&&(a.value=l),P({searchQuery:l}),o&&(o.style.display="flex"),i&&(i.innerHTML=ze()))});const u=document.getElementById("sp-enable-tabs-banner")||document.getElementById("sp-btn-enable-tabs");u&&u.addEventListener("click",async l=>{l.stopPropagation(),await Me("tabs")?(P({hasTabsPermission:!0,currentSiteEnabled:!0}),e(),t()):S(s("toasts.tabs_permission_denied"))}),i&&(i.addEventListener("click",async l=>{if(l.target.closest("#sp-empty-btn-add")){be(),P({activeTab:"item-details",selectedItem:null,isProjectSwitcherOpen:!1}),t();return}const m=l.target.closest(".sp-card");if(!m)return;const h=m.dataset.id,g=c.items.find(b=>b.id===h);if(!g)return;const k=l.target.closest("[data-action]"),y=k?k.dataset.action:"view";y==="view"?(be(),P({activeTab:"item-details",selectedItem:g,isProjectSwitcherOpen:!1}),t()):y==="autofill"?await Dt(g):y==="copy-user"?(se(g.username||""),S(s("toasts.copied"))):y==="copy-pwd"&&(se(g.password||""),S(s("toasts.pwd_copied")),typeof chrome<"u"&&chrome.alarms&&chrome.alarms.create("clearClipboardAlarm",{delayInMinutes:.5}))}),i.addEventListener("error",l=>{if(l.target&&l.target.classList.contains("sp-card-favicon")){l.target.style.display="none";const p=l.target.nextElementSibling;p&&p.classList.contains("sp-card-fallback-letter")&&(p.style.display="inline-block")}},!0))}async function Dt(e,t=!1){const a=e.url||e.domain||"",o=ce(a),i=_a(o);if(i.length>0&&!await ka(i)){se(e.password),S(s("toasts.autofill_copied"));return}c.hasTabsPermission||await Me("tabs")&&P({hasTabsPermission:!0}),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage&&n.activeTabId?chrome.runtime.sendMessage({action:"AUTOFILL_LOGIN",tabId:n.activeTabId,username:e.username,password:e.password,forceFill:t},async r=>{var d;if((d=chrome.runtime)!=null&&d.lastError){se(e.password),S(s("toasts.autofill_copied"));return}if(r&&r.success)S(s("toasts.form_autofilled"));else if(r&&r.reason==="no_tab_access")await Me("tabs")?(P({hasTabsPermission:!0}),Dt(e,t)):(se(e.password),S(s("toasts.autofill_copied")));else if(r&&r.reason==="domain_mismatch"){const u=r.tabDomain||"current site",l=r.itemDomain||"this item";confirm(s("toasts.domain_mismatch_warning",{tabDomain:u,itemDomain:l}))?Dt(e,!0):(se(e.password),S(s("toasts.autofill_copied")))}else se(e.password),S(s("toasts.autofill_copied"))}):(se(e.password),S(s("toasts.autofill_copied")))}function yn({renderApp:e}){const t=document.getElementById("sp-form-back");t&&t.addEventListener("click",()=>{be(),P({activeTab:"vault",selectedItem:null}),e()});const a=document.getElementById("sp-form-export-csv");a&&c.selectedItem&&a.addEventListener("click",()=>{Ba(c.selectedItem,{renderApp:e})});const o=document.getElementById("sp-form-delete");o&&c.selectedItem&&o.addEventListener("click",()=>{const x=c.selectedItem.id;be(),za(x,{renderApp:e})});const i=document.getElementById("sp-toggle-pwd-vis");i&&i.addEventListener("click",()=>{n.isPasswordVisible=!n.isPasswordVisible;const x=document.getElementById("sp-item-password");x&&(x.type=n.isPasswordVisible?"text":"password"),i.innerHTML=n.isPasswordVisible?ms:us});const r=document.getElementById("sp-btn-gen-inline");r&&r.addEventListener("click",()=>{const x=et({length:22}),w=document.getElementById("sp-item-password");if(w){w.value=x,w.type="text",n.isPasswordVisible=!0,w.classList.remove("has-error");const $=document.getElementById("sp-item-password-error");$&&($.style.display="none")}te()});const d=document.getElementById("sp-toggle-pwd-history"),u=document.getElementById("sp-pwd-history-list");d&&u&&d.addEventListener("click",x=>{x.preventDefault();const w=u.style.display==="flex";u.style.display=w?"none":"flex"}),document.querySelectorAll('[data-action="copy-history-pwd"]').forEach(x=>{x.addEventListener("click",async w=>{w.preventDefault();const $=x.dataset.pwd;$&&(await se($),S(s("form.pwd_history_copied")))})}),document.querySelectorAll('[data-action="restore-history-pwd"]').forEach(x=>{x.addEventListener("click",w=>{w.preventDefault();const $=x.dataset.pwd,E=document.getElementById("sp-item-password");$&&E&&(E.value=$,E.type="text",n.isPasswordVisible=!0,S(s("form.pwd_history_restored")),te())})});const l=document.getElementById("sp-item-url");l&&(l.addEventListener("input",()=>{const x=l.value.trim(),w=ce(x),$=We(x),E=document.getElementById("sp-form-domain-badge");if(E&&($?(E.textContent=$,E.style.display="inline"):E.style.display="none"),c.showFavicons&&w&&n.cachedFavicons[w]){const T=document.getElementById("sp-form-favicon-preview");T&&(T.src=n.cachedFavicons[w],T.style.display="inline-block"),n.formDraft&&(n.formDraft.domain=$,n.formDraft.favicon=n.cachedFavicons[w])}}),l.addEventListener("blur",async()=>{if(!c.showFavicons)return;const x=l.value.trim(),w=ce(x);if(!w)return;const $=w.split(":")[0];let E=n.cachedFavicons[w]||n.cachedFavicons[$]||await ye(w)||await ye($);if(!E){let T=n.activeTabFavicon;if(typeof chrome<"u"&&chrome.tabs&&chrome.tabs.query)try{const v=await new Promise(_=>chrome.tabs.query({active:!0,currentWindow:!0},_));if(v&&v[0]&&v[0].favIconUrl){const _=ce(v[0].url);(_===w||_.split(":")[0]===$)&&(T=v[0].favIconUrl)}}catch{}const O=await it(x,{forceRefresh:!1,activeTabFavIconUrl:T,useExternalServices:c.useExternalIcons===!0});O&&O.favicon&&(E=O.favicon,n.cachedFavicons[w]=E,$&&(n.cachedFavicons[$]=E))}if(E){n.formDraft&&(n.formDraft.domain=w,n.formDraft.favicon=E);const T=document.getElementById("sp-form-favicon-preview");T&&(T.src=E,T.style.display="inline-block")}}));const p=document.getElementById("sp-btn-refresh-favicon");p&&p.addEventListener("click",async x=>{var T;x.preventDefault(),x.stopPropagation();const w=document.getElementById("sp-item-url"),$=w?w.value.trim():"",E=ce($);if(!E){S(s("toasts.favicon_empty_url"));return}p.classList.add("sp-spin"),p.disabled=!0;try{let O=n.activeTabFavicon;if(typeof chrome<"u"&&chrome.tabs&&chrome.tabs.query)try{const _=await new Promise(f=>chrome.tabs.query({active:!0,currentWindow:!0},f));_&&_[0]&&_[0].favIconUrl&&(O=_[0].favIconUrl)}catch{}const v=await it($,{forceRefresh:!0,activeTabFavIconUrl:O,useExternalServices:c.useExternalIcons===!0});if(v&&v.favicon){const _=E.split(":")[0];n.cachedFavicons[E]=v.favicon,v.domain&&(n.cachedFavicons[v.domain]=v.favicon),_&&(n.cachedFavicons[_]=v.favicon);const f=_||E;n.formDraft&&(n.formDraft.domain=f,n.formDraft.favicon=v.favicon);const I=document.getElementById("sp-form-domain-badge");I&&(I.textContent=f,I.style.display="inline");const B=document.getElementById("sp-form-favicon-preview");B&&(B.src=v.favicon,B.style.display="inline-block");const U=(T=document.getElementById("sp-item-id"))==null?void 0:T.value;if(U){const H=c.items.findIndex(K=>K.id===U);H>=0&&(c.items[H].domain=f,c.items[H].favicon=v.favicon,await J())}S(s("toasts.favicon_updated"))}else S(s("toasts.favicon_fetch_failed"))}catch{S(s("toasts.favicon_fetch_failed"))}finally{p.classList.remove("sp-spin"),p.disabled=!1}});const m=document.getElementById("sp-project-select-wrap"),h=document.getElementById("sp-project-select-trigger"),g=document.getElementById("sp-project-dropdown"),k=document.getElementById("sp-item-project"),y=document.getElementById("sp-project-select-label");if(m&&h&&g){const x=w=>{var E;if(w==null||w.stopPropagation(),g.style.display==="flex"||m.classList.contains("open"))g.style.display="none",m.classList.remove("open");else{g.style.display="flex",m.classList.add("open");const T=document.getElementById("sp-tags-dropdown");T&&(T.style.display="none",(E=document.querySelector(".sp-tag-input-container"))==null||E.classList.remove("open"))}};h.addEventListener("click",x),g.querySelectorAll('[data-action="select-form-project"]').forEach(w=>{w.addEventListener("click",$=>{$.stopPropagation();const E=w.dataset.projectId,T=w.dataset.projectName;k&&(k.value=E),y&&(y.textContent=T),g.querySelectorAll('[data-action="select-form-project"]').forEach(O=>{const v=O.dataset.projectId===E;O.classList.toggle("selected",v)}),g.style.display="none",m.classList.remove("open"),te()})})}const b=document.getElementById("sp-form-tags-selected");b&&b.addEventListener("click",x=>{const w=x.target.closest('[data-action="remove-form-tag"]');if(!w)return;x.stopPropagation(),te();const $=w.dataset.tag;n.formSelectedTags=n.formSelectedTags.filter(E=>E!==$),n.formDraft&&(n.formDraft.tags=[...n.formSelectedTags]),b.innerHTML=He()});const j=document.getElementById("sp-tag-search-input"),F=document.getElementById("sp-tag-dropdown-toggle"),M=document.getElementById("sp-tags-dropdown"),R=document.getElementById("sp-tag-input-err");async function A(x){const w=(x||"").trim();if(!w)return;const $=At(w);if(!$.valid){R&&(R.innerText=$.error,R.style.display="block");return}if(!c.categories.includes(w)){c.categories.push(w),c.categoryColors||(c.categoryColors={}),c.categoryColors[w]="slate";const T=await q();await W({...T,categories:c.categories.filter(O=>O!=="All"),categoryColors:c.categoryColors})}n.formSelectedTags.includes(w)||n.formSelectedTags.push(w),n.formDraft&&(n.formDraft.tags=[...n.formSelectedTags]),j&&(j.value=""),M&&(M.style.display="none");const E=document.querySelector(".sp-tag-input-container");E&&E.classList.remove("open"),R&&(R.style.display="none"),b&&(b.innerHTML=He())}function V(x=""){if(!M)return;const w=x.trim().toLowerCase(),$=c.categories.filter(f=>f!=="All"),E=$.filter(f=>!w||f.toLowerCase().includes(w));let T="";const O=x.trim(),v=$.some(f=>f.toLowerCase()===O.toLowerCase());O&&!v?T+=`
        <div class="sp-tag-drop-create sp-tag-drop-create-top" data-action="create-dropdown-tag" data-tag="${C(O)}">
          <span class="sp-tag-create-icon">${_e}</span>
          <span class="sp-tag-create-text">${s("form.tags_create_option",{name:C(O)})}</span>
        </div>
      `:O||(T+=`
        <div class="sp-tag-drop-create sp-tag-drop-create-top" data-action="prompt-create-tag">
          <span class="sp-tag-create-icon">${_e}</span>
          <span class="sp-tag-create-text">${s("form.tags_create_new_action")}</span>
        </div>
      `),E.length>0&&(T+=E.map(f=>{const I=n.formSelectedTags.includes(f),B=Oe(f,c.categoryColors),U=Ve(B),H=f==="Work"?s("categories.Work"):f==="Personal"?s("categories.Personal"):f;return`
          <div class="sp-tag-drop-item ${I?"selected":""}" data-action="select-dropdown-tag" data-tag="${C(f)}">
            <span class="sp-pill sp-pill-tag-card" data-color-pill="true" style="${U}; pointer-events:none;">
              <span class="sp-pill-dot" style="background-color:${B.color};"></span>
              <span>${C(H)}</span>
            </span>
            ${I?`<span style="color:var(--text-main); font-size:12px;">${G}</span>`:""}
          </div>
        `}).join("")),T||(T=`<div style="padding:8px 10px; font-size:11px; color:var(--text-dim);">${s("form.tags_no_tags")}</div>`),M.innerHTML=T,M.style.display="block";const _=document.querySelector(".sp-tag-input-container");_&&_.classList.add("open"),g&&(g.style.display="none",m==null||m.classList.remove("open")),M.querySelectorAll('[data-action="select-dropdown-tag"]').forEach(f=>{f.addEventListener("click",I=>{I.stopPropagation(),te();const B=f.dataset.tag;n.formSelectedTags.includes(B)?n.formSelectedTags=n.formSelectedTags.filter(U=>U!==B):n.formSelectedTags.push(B),n.formDraft&&(n.formDraft.tags=[...n.formSelectedTags]),M.style.display="none",_==null||_.classList.remove("open"),R&&(R.style.display="none"),b&&(b.innerHTML=He())})}),M.querySelectorAll('[data-action="prompt-create-tag"]').forEach(f=>{f.addEventListener("click",async I=>{I.stopPropagation();const B=window.prompt(s("form.tags_prompt_new"));B&&B.trim()?(te(),await A(B.trim())):j==null||j.focus()})}),M.querySelectorAll('[data-action="create-dropdown-tag"]').forEach(f=>{f.addEventListener("click",async I=>{I.stopPropagation(),te(),await A(f.dataset.tag)})})}j&&(j.addEventListener("input",x=>{R&&(R.style.display="none"),V(x.target.value)}),j.addEventListener("focus",()=>{V(j.value)}),j.addEventListener("keydown",async x=>{var w,$;if(x.key==="Enter"){x.preventDefault();const E=j.value.trim();if(!E)return;te();const O=c.categories.filter(v=>v!=="All").find(v=>v.toLowerCase()===E.toLowerCase());O?(n.formSelectedTags.includes(O)||n.formSelectedTags.push(O),n.formDraft&&(n.formDraft.tags=[...n.formSelectedTags]),j.value="",M.style.display="none",(w=document.querySelector(".sp-tag-input-container"))==null||w.classList.remove("open"),b&&(b.innerHTML=He())):await A(E)}else x.key==="Escape"&&(M&&(M.style.display="none"),($=document.querySelector(".sp-tag-input-container"))==null||$.classList.remove("open"))})),F&&M&&F.addEventListener("click",x=>{x.stopPropagation();const w=document.querySelector(".sp-tag-input-container");M.style.display==="block"?(M.style.display="none",w==null||w.classList.remove("open")):V(j?j.value:"")});const D=document.getElementById("sp-csv-file-input");D&&D.addEventListener("change",async x=>{const w=x.target.files[0];if(w)try{const $=await w.text(),E=me(),T=Ma($);T.forEach(O=>{O.projectId=E?E.id:"proj_default"}),c.items=[...c.items,...T],await J(),S(s("settings.csv_import_success",{count:T.length})),be(),P({activeTab:"vault",selectedItem:null}),e()}catch($){alert(s("toasts.csv_import_error")+": "+$.message)}});const L=document.getElementById("sp-item-title");L&&L.addEventListener("input",()=>{if(L.value.trim()){L.classList.remove("has-error");const x=document.getElementById("sp-item-title-error");x&&(x.style.display="none")}});const z=document.getElementById("sp-item-password");z&&(z.value=n.currentFormItemPassword||"",z.addEventListener("input",()=>{if(n.currentFormItemPassword=z.value,z.value){z.classList.remove("has-error");const x=document.getElementById("sp-item-password-error");x&&(x.style.display="none")}}));const N=document.getElementById("sp-item-form");N&&(N.addEventListener("input",()=>{te()}),N.addEventListener("submit",async x=>{var B,U,H,K,ee,Q;x.preventDefault();let w=!0,$=null;const E=L?L.value.trim():"",T=document.getElementById("sp-item-title-error");E?(L&&L.classList.remove("has-error"),T&&(T.style.display="none")):(w=!1,L&&(L.classList.add("has-error","sp-shake"),setTimeout(()=>L.classList.remove("sp-shake"),450),$||($=L)),T&&(T.innerText=s("form.title_required"),T.style.display="block"));const O=z?z.value:"",v=document.getElementById("sp-item-password-error");if(O?(z&&z.classList.remove("has-error"),v&&(v.style.display="none")):(w=!1,z&&(z.classList.add("has-error","sp-shake"),setTimeout(()=>z.classList.remove("sp-shake"),450),$||($=z)),v&&(v.innerText=s("form.password_required"),v.style.display="block")),!w){$&&$.focus(),S(s("toasts.fill_required_fields"));return}const _=[...n.formSelectedTags],f=((B=document.getElementById("sp-item-url"))==null?void 0:B.value.trim())||"",I=ce(f);await Pa({id:((U=document.getElementById("sp-item-id"))==null?void 0:U.value)||"",projectId:((H=document.getElementById("sp-item-project"))==null?void 0:H.value)||"",title:E,url:f,domain:I,favicon:((K=n.formDraft)==null?void 0:K.favicon)||I&&n.cachedFavicons[I]||"",username:((ee=document.getElementById("sp-item-username"))==null?void 0:ee.value.trim())||"",password:O,category:_[0]||"",tags:_,notes:((Q=document.getElementById("sp-item-notes"))==null?void 0:Q.value.trim())||""},{renderApp:e}),be()}))}function bn(){const e=document.getElementById("sp-gen-display"),t=document.getElementById("sp-slider-len"),a=document.getElementById("sp-length-val"),o=()=>{n.currentGeneratedPassword=et(n.genOptions),e&&(e.innerText=n.currentGeneratedPassword)};t&&t.addEventListener("input",u=>{const l=parseInt(u.target.value,10);n.genOptions.length=l,a&&(a.innerText=l),o()}),[{id:"sp-chk-upper",prop:"useUpper"},{id:"sp-chk-lower",prop:"useLower"},{id:"sp-chk-digits",prop:"useDigits"},{id:"sp-chk-symbols",prop:"useSymbols"},{id:"sp-chk-ambig",prop:"avoidAmbiguous"}].forEach(({id:u,prop:l})=>{const p=document.getElementById(u);p&&p.addEventListener("change",m=>{n.genOptions[l]=m.target.checked,o()})});const r=document.getElementById("sp-gen-refresh");r&&r.addEventListener("click",()=>{o()});const d=document.getElementById("sp-gen-copy");d&&d.addEventListener("click",()=>{n.currentGeneratedPassword&&(se(n.currentGeneratedPassword),S(s("toasts.pwd_copied")),typeof chrome<"u"&&chrome.alarms&&chrome.alarms.create("clearClipboardAlarm",{delayInMinutes:.5}))})}function wn({renderApp:e}){const t=document.getElementById("sp-security-search"),a=document.getElementById("sp-security-search-clear");t&&t.addEventListener("input",i=>{n.securitySearchQuery=i.target.value;const r=t.selectionStart,d=t.selectionEnd;e();const u=document.getElementById("sp-security-search");if(u&&(u.focus(),r!==null&&d!==null))try{u.setSelectionRange(r,d)}catch{}}),a&&a.addEventListener("click",()=>{n.securitySearchQuery="",e();const i=document.getElementById("sp-security-search");i&&i.focus()}),document.querySelectorAll('[data-action="filter-risk"]').forEach(i=>{i.addEventListener("click",()=>{const r=i.dataset.risk;r&&(n.securityActiveRiskFilter=r,e())})});const o=document.getElementById("sp-btn-toggle-legend");o&&o.addEventListener("click",()=>{n.isSecurityLegendOpen=!n.isSecurityLegendOpen,e()}),document.querySelectorAll('[data-action="fix-security-item"]').forEach(i=>{i.addEventListener("click",r=>{r.stopPropagation();const d=i.dataset.id,u=c.items.find(l=>l.id===d);u&&P({activeTab:"item-details",selectedItem:u,isEditing:!0})})})}function kn({renderApp:e}){document.querySelectorAll('[data-action="start-tag-rename"]').forEach(l=>{l.addEventListener("click",p=>{p.stopPropagation(),n.editingTagId=l.dataset.cat,e(),setTimeout(()=>{const m=document.getElementById("sp-rename-tag-input");m&&(m.focus(),m.select())},30)})});const t=document.getElementById("sp-btn-cancel-tag-rename");t&&t.addEventListener("click",l=>{l.stopPropagation(),n.editingTagId=null,e()});async function a(l){const p=document.getElementById("sp-rename-tag-input"),m=document.getElementById("sp-rename-tag-err");if(!p)return;const h=p.value.trim();if(!h){m&&(m.innerText=s("settings.tag_name_empty"),m.style.display="block");return}if(h===l){n.editingTagId=null,e();return}const g=At(h);if(!g.valid){m&&(m.innerText=g.error,m.style.display="block");return}if(c.categories.some(b=>b.toLowerCase()===h.toLowerCase()&&b.toLowerCase()!==l.toLowerCase())){m&&(m.innerText=s("toasts.tag_exists"),m.style.display="block");return}if(c.categories=c.categories.map(b=>b===l?h:b),c.categoryColors&&c.categoryColors[l]){const b=c.categoryColors[l];delete c.categoryColors[l],c.categoryColors[h]=b}c.items=c.items.map(b=>{const j=le(b),F=[...new Set(j.map(R=>R===l?h:R))],M=b.category===l?h:b.category;return{...b,category:M,tags:F}}),c.activeCategory===l&&(c.activeCategory=h),await J();const y=await q();await W({...y,categories:c.categories.filter(b=>b!=="All"),categoryColors:c.categoryColors}),n.editingTagId=null,S(s("settings.cat_renamed")),e()}const o=document.getElementById("sp-btn-save-tag-rename");o&&o.addEventListener("click",async l=>{l.stopPropagation();const p=o.dataset.oldName||n.editingTagId;await a(p)});const i=document.getElementById("sp-rename-tag-input");i&&i.addEventListener("keydown",async l=>{l.key==="Enter"?(l.preventDefault(),await a(n.editingTagId)):l.key==="Escape"&&(n.editingTagId=null,e())});const r=document.getElementById("sp-btn-add-cat"),d=document.getElementById("sp-new-cat-name"),u=document.getElementById("sp-cat-err");if(r&&d){const l=async()=>{const p=d.value.trim();if(!p)return;const m=At(p);if(!m.valid){u&&(u.innerText=m.error,u.style.display="block");return}if(c.categories.some(g=>g.toLowerCase()===p.toLowerCase())){u&&(u.innerText=s("toasts.tag_exists"),u.style.display="block");return}c.categories.push(p),c.categoryColors||(c.categoryColors={}),c.categoryColors[p]=n.selectedNewCatColor;const h=await q();await W({...h,categories:c.categories.filter(g=>g!=="All"),categoryColors:c.categoryColors}),S(s("toasts.tag_added",{name:p})),e()};r.addEventListener("click",l),d.addEventListener("keydown",p=>{p.key==="Enter"&&(p.preventDefault(),l())})}document.querySelectorAll('[data-action="select-new-cat-color"]').forEach(l=>{l.addEventListener("click",p=>{p.stopPropagation(),n.selectedNewCatColor=l.dataset.colorId,e()})}),document.querySelectorAll('[data-action="toggle-cat-color-picker"]').forEach(l=>{l.addEventListener("click",p=>{p.stopPropagation();const m=l.dataset.cat;n.activeColorPickerCat=n.activeColorPickerCat===m?null:m,e()})}),document.querySelectorAll('[data-action="set-cat-color"]').forEach(l=>{l.addEventListener("click",async p=>{p.stopPropagation();const m=l.dataset.cat,h=l.dataset.colorId;c.categoryColors||(c.categoryColors={}),c.categoryColors[m]=h,n.activeColorPickerCat=null;const g=await q();await W({...g,categoryColors:c.categoryColors}),S(s("settings.cat_color_updated")),e()})}),document.querySelectorAll(".sp-cat-del-btn").forEach(l=>{l.addEventListener("click",async p=>{p.stopPropagation();const m=l.dataset.cat;if(m==="Work"||m==="Personal")return;c.categories=c.categories.filter(g=>g!==m),c.categoryColors&&delete c.categoryColors[m],c.items=c.items.map(g=>{const y=le(g).filter(j=>j!==m),b=y.length>0?y:["Work"];return{...g,tags:b,category:g.category===m?b[0]:g.category}}),c.activeCategory===m&&(c.activeCategory="All"),await J();const h=await q();await W({...h,categories:c.categories.filter(g=>g!=="All"),categoryColors:c.categoryColors}),S(s("toasts.tag_deleted",{name:m})),e()})})}function _n({renderApp:e,updateActiveTabDomain:t}){const a=document.getElementById("sp-settings-search");a&&a.addEventListener("input",v=>{n.settingsSearchQuery=v.target.value,e()});const o=document.getElementById("sp-settings-search-clear");o&&o.addEventListener("click",()=>{n.settingsSearchQuery="",e()});const i=document.getElementById("sp-setting-lang-dropdown"),r=document.getElementById("sp-custom-lang-trigger");i&&r&&(r.addEventListener("click",v=>{v.stopPropagation(),n.isLangSelectOpen=!n.isLangSelectOpen,i.classList.toggle("open",n.isLangSelectOpen),F("lang")}),i.querySelectorAll(".sp-custom-select-option").forEach(v=>{v.addEventListener("click",async _=>{_.stopPropagation();const f=v.dataset.val;if(n.isLangSelectOpen=!1,f&&Ft.includes(f)){os(f),P({language:f});const I=await q();await W({...I,language:f}),S(s("toasts.language_changed")),e()}})}));const d=document.getElementById("sp-theme-toggle");d&&d.addEventListener("change",async v=>{const _=v.target.checked?"dark":"light";rs(_),P({theme:_});const f=await q();await W({...f,theme:_}),S(s(_==="dark"?"toasts.theme_dark_enabled":"toasts.theme_light_enabled"))});const u=document.getElementById("sp-show-favicons-toggle");u&&u.addEventListener("change",async v=>{const _=v.target.checked;P({showFavicons:_});const f=await q();await W({...f,showFavicons:_}),S(s(_?"toasts.favicons_shown":"toasts.favicons_hidden"))});const l=document.getElementById("sp-use-external-icons-toggle");l&&l.addEventListener("change",async v=>{const _=v.target.checked;P({useExternalIcons:_});const f=await q();await W({...f,useExternalIcons:_}),S(s(_?"toasts.external_icons_enabled":"toasts.external_icons_disabled"))});const p=document.getElementById("sp-current-site-toggle");p&&p.addEventListener("change",async v=>{if(v.target.checked)if(await Me("tabs")){P({hasTabsPermission:!0,currentSiteEnabled:!0});const f=await q();await W({...f,currentSiteEnabled:!0}),t&&t(),e()}else v.target.checked=!1,S(s("toasts.tabs_permission_denied"));else{P({currentSiteEnabled:!1});const _=await q();await W({..._,currentSiteEnabled:!1}),t&&t(),e()}});const m=document.getElementById("sp-show-card-tags-toggle");m&&m.addEventListener("change",async v=>{const _=v.target.checked;P({showCardTags:_});const f=await q();await W({...f,showCardTags:_}),S(s(_?"toasts.card_tags_shown":"toasts.card_tags_hidden"))}),document.querySelectorAll('[data-action="toggle-section"]').forEach(v=>{v.addEventListener("click",()=>{const _=v.dataset.sectionId;n.openSections.has(_)?n.openSections.delete(_):n.openSections.add(_),e()})});const h=document.getElementById("sp-setting-lock-interval-dropdown"),g=document.getElementById("sp-custom-lock-trigger");h&&g&&(g.addEventListener("click",v=>{v.stopPropagation(),n.isCustomSelectOpen=!n.isCustomSelectOpen,h.classList.toggle("open",n.isCustomSelectOpen),F("lock")}),h.querySelectorAll(".sp-custom-select-option").forEach(v=>{v.addEventListener("click",async _=>{_.stopPropagation();const f=v.dataset.val;c.lockInterval=f,n.isCustomSelectOpen=!1;const I=await q();if(await W({...I,lockInterval:f}),c.rawMek){const B=await Be(c.rawMek,f);P({sessionExpiresAt:B.expiresAt})}else c.isUnlocked&&S(s("toasts.session_invalid"));S(f==="1day"?`⚠️ ${s("settings.interval_1day_warning")}`:s("toasts.interval_updated")),e()})}));const k=document.getElementById("sp-setting-autolock-dropdown"),y=document.getElementById("sp-custom-autolock-trigger");k&&y&&(y.addEventListener("click",v=>{v.stopPropagation(),n.isAutolockSelectOpen=!n.isAutolockSelectOpen,k.classList.toggle("open",n.isAutolockSelectOpen),F("autolock")}),k.querySelectorAll(".sp-custom-select-option").forEach(v=>{v.addEventListener("click",async _=>{_.stopPropagation();const f=Number(v.dataset.val);c.autolockMinutes=f,n.isAutolockSelectOpen=!1;const I=await q();await W({...I,autolockMinutes:f}),c.isUnlocked&&zt({idleMinutes:f,onLock:()=>je()}),S(s("toasts.interval_updated")),e()})}));const b=document.getElementById("sp-export-format-dropdown"),j=document.getElementById("sp-export-format-trigger");b&&j&&(j.addEventListener("click",v=>{v.stopPropagation(),n.isExportFormatSelectOpen=!n.isExportFormatSelectOpen,b.classList.toggle("open",n.isExportFormatSelectOpen),F("export")}),b.querySelectorAll(".sp-custom-select-option").forEach(v=>{v.addEventListener("click",_=>{_.stopPropagation(),n.selectedExportFormat=v.dataset.val||"spbackup",n.isExportFormatSelectOpen=!1,e()})}));function F(v){v!=="lang"&&i&&(n.isLangSelectOpen=!1,i.classList.remove("open")),v!=="lock"&&h&&(n.isCustomSelectOpen=!1,h.classList.remove("open")),v!=="autolock"&&k&&(n.isAutolockSelectOpen=!1,k.classList.remove("open")),v!=="export"&&b&&(n.isExportFormatSelectOpen=!1,b.classList.remove("open"))}kn({renderApp:e});const M=document.getElementById("sp-btn-toggle-change-pwd");M&&M.addEventListener("click",()=>{n.isChangePwdOpen=!n.isChangePwdOpen,e(),n.isChangePwdOpen&&setTimeout(()=>{const v=document.getElementById("sp-change-pwd-form");v&&v.scrollIntoView({behavior:"smooth",block:"nearest"})},30)});const R=document.getElementById("sp-change-pwd-form");R&&(ot("sp-pwd-new","sp-pwd-new-strength"),R.addEventListener("submit",async v=>{v.preventDefault();const _=document.getElementById("sp-pwd-old").value,f=document.getElementById("sp-pwd-new").value,I=document.getElementById("sp-pwd-new2").value,B=document.getElementById("sp-change-pwd-err"),U=await Ee();let H=c.rawMek;try{H=await Je(U,_)}catch{B&&(B.innerText=s("auth.invalid_master_pwd"),B.style.display="block");return}const K=gt(f);if(!K.valid){B&&(B.innerText=s(`auth.${K.errorCode}`)||K.error,B.style.display="block");return}if(f!==I){B&&(B.innerText=s("auth.pwd_mismatch"),B.style.display="block");return}try{const ee=await Z(H,f,"mek-pwd");c.rawMek=H,c.keySlots||(c.keySlots={keyByPassword:U.keyByPassword,keyByRecovery:U.keyByRecovery?{...U.keyByRecovery,aad:U.keyByRecovery.aad??!1}:null}),c.keySlots.keyByPassword=ee;const Q={version:3,updatedAt:new Date().toISOString(),projects:c.projects,items:c.items},bs=await xe(Q,H,c.keySlots);await De(bs);const ws=await Be(H,c.lockInterval||"session");n.isChangePwdOpen=!1,P({rawMek:H,keySlots:c.keySlots,sessionExpiresAt:ws.expiresAt}),S(s("toasts.pwd_changed_success")),e()}catch(ee){B&&(B.innerText=ee.message,B.style.display="block")}}));const A=document.getElementById("sp-btn-lock-now");A&&A.addEventListener("click",()=>{je()});const V=document.getElementById("sp-btn-open-switcher");V&&V.addEventListener("click",()=>{P({isProjectSwitcherOpen:!0})});const D=document.getElementById("sp-export-advanced-toggle");D&&D.addEventListener("click",v=>{v.preventDefault(),n.isExportAdvancedOpen=!n.isExportAdvancedOpen,e()});const L=document.getElementById("sp-export-select-all-tags");L&&L.addEventListener("click",v=>{v.preventDefault();const _=ge();Array.from(new Set([...c.categories.filter(I=>I!=="All"),..._.flatMap(I=>le(I))])).filter(Boolean).forEach(I=>n.exportSelectedTags.add(I)),e()});const z=document.getElementById("sp-export-clear-tags");z&&z.addEventListener("click",v=>{v.preventDefault(),n.exportSelectedTags.clear(),e()}),document.querySelectorAll('[data-action="toggle-export-tag"]').forEach(v=>{v.addEventListener("click",_=>{_.preventDefault();const f=v.dataset.tag;f&&(n.exportSelectedTags.has(f)?n.exportSelectedTags.delete(f):n.exportSelectedTags.add(f),e())})});const N=document.getElementById("sp-btn-export-unified");N&&N.addEventListener("click",()=>{const v=n.selectedExportFormat||"spbackup",_=me(),f=ge(),I=f.length>0?f:c.items;let B=I;if(n.exportSelectedTags.size>0&&(B=I.filter(K=>le(K).some(Q=>n.exportSelectedTags.has(Q))),B.length===0)){S(s("settings.export_no_matching_items"));return}const U=_!=null&&_.name?_.name.replace(/[^a-zA-Z0-9_\u0400-\u04FF-]/g,"_"):"passwords",H=n.exportSelectedTags.size===1?`-${Array.from(n.exportSelectedTags)[0]}`:n.exportSelectedTags.size>1?"-filtered":"";n.exportModalData={format:v,items:B,fileName:`passwords-${U}${H}`},e()});const x=document.getElementById("sp-btn-delete-current-vault");x&&x.addEventListener("click",async()=>{const v=await Fe(),f=(await he()).find(B=>B.id===v),I=f?f.name:"";confirm(s("settings.delete_vault_confirm",{name:I}))&&(await Ms(v),await ve(),window.location.reload())});const w=document.getElementById("sp-btn-reset-all");w&&w.addEventListener("click",async()=>{prompt(s("settings.reset_prompt"))==="СБРОС"&&(await Ns(),await ve(),window.location.reload())});const $=document.getElementById("sp-btn-check-pass-host");$&&$.addEventListener("click",async()=>{if(!c.hasNativeMessagingPermission){if(!await Me("nativeMessaging")){S(s("toasts.native_permission_denied"));return}P({hasNativeMessagingPermission:!0})}S(s("toasts.native_checking"));const v=await cs();P({passHostStatus:v}),v&&v.ok?S(s("toasts.native_connected",{count:v.entriesCount})):v&&v.permissionRequired?S(s("toasts.native_permission_denied")):S(s("toasts.native_unresponsive")),e()});const E=document.getElementById("sp-btn-show-pass-instructions");E&&E.addEventListener("click",()=>{P({isShowPassInstructions:!0})});const T=document.getElementById("sp-btn-sync-active-pass");T&&T.addEventListener("click",()=>{const v=me();v&&ls(v.id)}),document.querySelectorAll('[data-action="restore-trash-item"]').forEach(v=>{v.addEventListener("click",async _=>{_.stopPropagation();const f=v.dataset.id;f&&await La(f,{renderApp:e})})}),document.querySelectorAll('[data-action="delete-perm-trash-item"]').forEach(v=>{v.addEventListener("click",async _=>{_.stopPropagation();const f=v.dataset.id;f&&await Aa(f,{renderApp:e})})});const O=document.getElementById("sp-btn-empty-trash");O&&O.addEventListener("click",async()=>{await Ta({renderApp:e})})}function xn({renderApp:e,handleSyncPassProject:t}){const a=document.getElementById("sp-recovery-modal-close"),o=document.getElementById("sp-btn-confirm-recovery-saved");[a,o].forEach(A=>{A&&A.addEventListener("click",()=>{n.newlyCreatedRecoveryPhrase=null,e()})});const i=document.getElementById("sp-btn-copy-recovery-phrase");i&&n.newlyCreatedRecoveryPhrase&&i.addEventListener("click",()=>{se(n.newlyCreatedRecoveryPhrase),S(s("toasts.recovery_words_copied"))});const r=document.getElementById("sp-btn-download-recovery-phrase");r&&n.newlyCreatedRecoveryPhrase&&r.addEventListener("click",()=>{const A=`SimplePass Recovery Key (12 Words)
Generated: ${new Date().toISOString()}

${n.newlyCreatedRecoveryPhrase}

${s("recovery_modal.safe_warning")}`,V=new Blob([A],{type:"text/plain"}),D=URL.createObjectURL(V),L=document.createElement("a");L.href=D,L.download=`simplepass-recovery-key-${new Date().toISOString().slice(0,10)}.txt`,L.click(),URL.revokeObjectURL(D),S(s("recovery_modal.file_saved"))});const d=document.getElementById("sp-close-project-panel");d&&d.addEventListener("click",()=>{P({isProjectSwitcherOpen:!1}),e()}),document.querySelectorAll('[data-action="select-project"]').forEach(A=>{A.addEventListener("click",()=>{const V=A.dataset.projectId;Ws(V),P({isProjectSwitcherOpen:!1,selectedItem:null,isEditing:!1}),e()})}),document.querySelectorAll('[data-action="rename-project"]').forEach(A=>{A.addEventListener("click",async V=>{V.stopPropagation();const D=A.dataset.projectId,L=c.projects.find(N=>N.id===D);if(!L)return;const z=prompt(s("project_switcher.rename_prompt"),L.name);z&&z.trim()&&z.trim()!==L.name&&(Ks(D,z.trim()),await J(),e())})}),document.querySelectorAll('[data-action="delete-project"]').forEach(A=>{A.addEventListener("click",V=>{V.stopPropagation();const D=A.dataset.projectId,L=c.projects.find(z=>z.id===D);L&&(P({projectToDelete:L,isProjectSwitcherOpen:!1}),e())})});const u=document.getElementById("sp-create-project-form");u&&u.addEventListener("submit",async A=>{var N;A.preventDefault();const D=document.getElementById("sp-new-project-name").value.trim();if(!D)return;const L=((N=document.querySelector('input[name="sp-new-project-type"]:checked'))==null?void 0:N.value)||"browser",z=Js(D,L);await J(),L==="pass_cli"?(S(s("toasts.db_created_pass",{name:D})),t&&t(z.id)):S(s("toasts.db_created",{name:D})),e()}),document.querySelectorAll('[data-action="sync-pass-project"]').forEach(A=>{A.addEventListener("click",V=>{V.stopPropagation();const D=A.dataset.projectId;t&&t(D)})});const l=document.getElementById("sp-modal-cancel-btn"),p=document.getElementById("sp-modal-close-btn");[l,p].forEach(A=>{A&&A.addEventListener("click",()=>{P({projectToDelete:null}),e()})});const m=document.getElementById("sp-delete-project-form");m&&c.projectToDelete&&m.addEventListener("submit",async A=>{A.preventDefault();const V=document.getElementById("sp-delete-confirm-name").value.trim(),D=document.getElementById("sp-delete-confirm-pwd").value,L=document.getElementById("sp-delete-modal-error"),z=c.projectToDelete;if(V!==z.name){L&&(L.innerText=s("delete_modal.name_mismatch_err"),L.style.display="block");return}try{const N=await Ee();(N.version===2||N.version===3)&&N.keyByPassword?await Je(N,D):await Ge(N,D)}catch{L&&(L.innerText=s("auth.invalid_master_pwd"),L.style.display="block");return}Xs(z.id),await J(),P({projectToDelete:null}),e(),S(s("toasts.db_deleted"))});const h=document.getElementById("sp-btn-close-pass-instructions"),g=document.getElementById("sp-btn-ack-pass-instructions");[h,g].forEach(A=>{A&&A.addEventListener("click",()=>{P({isShowPassInstructions:!1}),e()})});const k=document.getElementById("sp-export-modal-close"),y=document.getElementById("sp-export-modal-cancel");[k,y].forEach(A=>{A&&A.addEventListener("click",()=>{n.exportModalData=null,e()})});const b=document.getElementById("sp-export-backup-form");b&&n.exportModalData&&b.addEventListener("submit",async A=>{A.preventDefault();const V=document.getElementById("sp-export-backup-pwd"),D=document.getElementById("sp-export-modal-err"),L=V?V.value:"";if(L)try{const z={version:1,exportedAt:new Date().toISOString(),projects:c.projects,items:n.exportModalData.items},N=await Ls(z,L,null),x=JSON.stringify(N,null,2),w=new Blob([x],{type:"application/json;charset=utf-8;"}),$=URL.createObjectURL(w),E=document.createElement("a");E.href=$,E.download=`${n.exportModalData.fileName}.spbackup`,E.click(),URL.revokeObjectURL($),S(s("settings.export_spbackup_success")),n.exportModalData=null,e()}catch(z){D&&(D.style.display="block",D.textContent=z.message)}});const j=document.getElementById("sp-export-plaintext-form");j&&n.exportModalData&&j.addEventListener("submit",async A=>{A.preventDefault();const V=document.getElementById("sp-export-confirm-pwd"),D=document.getElementById("sp-export-modal-err"),L=V?V.value:"";if(L){try{const z=await Ee();let N=!1;if(z&&((z.version===2||z.version===3)&&z.keyByPassword?(await Je(z,L),N=!0):(await Ge(z,L),N=!0)),!N){D&&(D.style.display="block",D.textContent=s("auth.invalid_pwd_err"));return}}catch{D&&(D.style.display="block",D.textContent=s("auth.invalid_pwd_err"));return}if(n.exportModalData.format==="csv"){const z=Hs(n.exportModalData.items),N=new Blob([z],{type:"text/csv;charset=utf-8;"}),x=URL.createObjectURL(N),w=document.createElement("a");w.href=x,w.download=`${n.exportModalData.fileName}.csv`,w.click(),URL.revokeObjectURL(x),S(s("settings.export_csv_success"))}else{const z=Gs(n.exportModalData.items),N=new Blob([z],{type:"application/json;charset=utf-8;"}),x=URL.createObjectURL(N),w=document.createElement("a");w.href=x,w.download=`${n.exportModalData.fileName}.json`,w.click(),URL.revokeObjectURL(x),S(s("settings.export_json_success"))}n.exportModalData=null,e()}});const F=document.getElementById("sp-import-backup-close"),M=document.getElementById("sp-import-backup-cancel");[F,M].forEach(A=>{A&&A.addEventListener("click",()=>{n.importBackupData=null,e()})});const R=document.getElementById("sp-import-backup-form");R&&n.importBackupData&&R.addEventListener("submit",async A=>{A.preventDefault();const V=document.getElementById("sp-import-backup-pwd"),D=document.getElementById("sp-import-backup-err"),L=V?V.value:"";if(L)try{const z=await Ge(n.importBackupData.envelope,L),x=(ht(z).items||[]).map(($,E)=>{var T;return{...$,id:$.id||`item_${Date.now()}_${E}`,projectId:n.importBackupData.targetProjId||$.projectId||((T=c.projects[0])==null?void 0:T.id)||"proj_default"}});if(x.length===0){D&&(D.style.display="block",D.textContent=s("settings.csv_import_empty"));return}const w=[...c.items,...x];P({items:w}),await J(),S(s("settings.csv_import_success",{count:x.length})),n.importBackupData=null,e()}catch{D&&(D.style.display="block",D.textContent=s("auth.invalid_pwd_err"))}})}let Se=null,ys=!1;function Sn(e){e.innerHTML=`
    <div id="sp-auth-container" style="display:none; width:100%; height:100%;"></div>
    <div id="sp-main-layout" style="display:none; position:relative; width:100%; height:100%; flex-direction:column; overflow:hidden;">
      <div id="sp-header-container"></div>
      <div id="sp-drawer-container"></div>
      <main id="sp-view-container" style="flex:1; overflow:hidden; display:flex; flex-direction:column;"></main>
      <div id="sp-footer-container"></div>
      <div id="sp-modals-container"></div>
    </div>
    <div id="sp-toast" class="sp-toast"></div>
  `,ys=!0}function ae(){const e=document.getElementById("sp-app-root");if(!e)return;(!ys||!document.getElementById("sp-auth-container"))&&Sn(e);const t=document.getElementById("sp-auth-container"),a=document.getElementById("sp-main-layout"),o=document.getElementById("sp-header-container"),i=document.getElementById("sp-drawer-container"),r=document.getElementById("sp-view-container"),d=document.getElementById("sp-footer-container"),u=document.getElementById("sp-modals-container");if(!c.isUnlocked){Se=null,a.style.display="none",t.style.display="flex",t.innerHTML=Ga(),pn({});return}t.style.display="none",a.style.display="flex",o.innerHTML=qa(),i.innerHTML=Wa(),d.innerHTML=Ja(),fn({renderApp:ae});const l=c.activeTab;if(l==="vault"){const p=document.getElementById("sp-search-input"),m=document.getElementById("sp-vault-cards-container");if(Se==="vault"&&p&&m){m.innerHTML=ze();const h=document.querySelector(".sp-cat-pills-scroll");h&&(h.innerHTML=hs());const g=document.getElementById("sp-active-domain-notice-container");g&&(g.innerHTML=fs())}else r.innerHTML=Ka(),vn({renderApp:ae,updateActiveTabDomain:Ye}),Se="vault"}else if(l==="item-details")r.innerHTML=Xa(),yn({renderApp:ae}),Se="item-details";else if(l==="generator")r.innerHTML=Qa(),bn(),Se="generator";else if(l==="security")r.innerHTML=en(),wn({renderApp:ae}),Se="security";else if(l==="settings"){const p=document.activeElement,m=p&&p.id==="sp-settings-search",h=m?p.selectionStart:null,g=m?p.selectionEnd:null;if(r.innerHTML=sn(),_n({renderApp:ae,updateActiveTabDomain:Ye}),Se="settings",m){const k=document.getElementById("sp-settings-search");if(k&&(k.focus(),h!==null&&g!==null))try{k.setSelectionRange(h,g)}catch{}}}u.innerHTML=dn(),xn({renderApp:ae,handleSyncPassProject:ls})}function Ye(){if(!c.currentSiteEnabled||!c.hasTabsPermission){(n.activeTabDomain||n.activeTabUrl)&&(n.activeTabDomain="",n.activeTabUrl="",n.isAutofillSupported=!1,c.isUnlocked&&c.activeTab!=="item-details"&&ae());return}const e=(t,a,o)=>{const i=ce(t);n.activeTabUrl=t||"",n.isAutofillSupported=_s(n.activeTabUrl),o&&(n.activeTabFavicon=o);const r=i!==n.activeTabDomain,d=a!==n.activeTabId,u=c.showFavicons&&i&&!n.cachedFavicons[i];if((r||d||u)&&(n.activeTabDomain=i,n.activeTabId=a,i&&c.showFavicons&&it(t,{forceRefresh:!1,activeTabFavIconUrl:o||n.activeTabFavicon,useExternalServices:c.useExternalIcons===!0}).then(l=>{if(l&&l.favicon){n.cachedFavicons[i]=l.favicon,l.domain&&(n.cachedFavicons[l.domain]=l.favicon);const p=i.split(":")[0];n.cachedFavicons[p]=l.favicon;const m=document.getElementById("sp-form-favicon-preview");m&&(!m.src||m.style.display==="none")&&(m.src=l.favicon,m.style.display="inline-block")}}).catch(()=>{}),c.isUnlocked)){if(c.activeTab==="item-details"){te();return}ae()}};typeof chrome<"u"&&chrome.tabs&&chrome.tabs.query?chrome.tabs.query({active:!0,lastFocusedWindow:!0},t=>{var a;(a=chrome.runtime)!=null&&a.lastError||(t&&t[0]?e(t[0].url,t[0].id,t[0].favIconUrl):chrome.tabs.query({active:!0,currentWindow:!0},o=>{var i;(i=chrome.runtime)!=null&&i.lastError||o&&o[0]&&e(o[0].url,o[0].id,o[0].favIconUrl)}))}):typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:"GET_ACTIVE_TAB_INFO"},t=>{var a;(a=chrome.runtime)!=null&&a.lastError||t&&t.domain&&e(t.domain,t.tabId,t.favIconUrl)})}typeof window<"u"&&(window.addEventListener("blur",()=>{c&&c.activeTab==="item-details"&&te()}),document.addEventListener("click",e=>{var l;const t=document.getElementById("sp-project-dropdown"),a=document.getElementById("sp-project-select-wrap");t&&(t.style.display==="flex"||a!=null&&a.classList.contains("open"))&&(e.target.closest("#sp-project-select-wrap")||(t.style.display="none",a==null||a.classList.remove("open")));const o=document.getElementById("sp-tag-dropdown");o&&o.style.display==="block"&&(e.target.closest(".sp-tag-input-container")||(o.style.display="none",(l=document.querySelector(".sp-tag-input-container"))==null||l.classList.remove("open")));const i=document.getElementById("sp-setting-lang-dropdown");i&&(i.classList.contains("open")||n.isLangSelectOpen)&&(e.target.closest("#sp-setting-lang-dropdown")||(n.isLangSelectOpen=!1,i.classList.remove("open")));const r=document.getElementById("sp-setting-lock-interval-dropdown");r&&(r.classList.contains("open")||n.isCustomSelectOpen)&&(e.target.closest("#sp-setting-lock-interval-dropdown")||(n.isCustomSelectOpen=!1,r.classList.remove("open")));const d=document.getElementById("sp-setting-autolock-dropdown");d&&(d.classList.contains("open")||n.isAutolockSelectOpen)&&(e.target.closest("#sp-setting-autolock-dropdown")||(n.isAutolockSelectOpen=!1,d.classList.remove("open")));const u=document.getElementById("sp-export-format-dropdown");u&&(u.classList.contains("open")||n.isExportFormatSelectOpen)&&(e.target.closest("#sp-export-format-dropdown")||(n.isExportFormatSelectOpen=!1,u.classList.remove("open")))}));if(typeof chrome<"u"&&chrome.tabs)try{chrome.tabs.onActivated&&chrome.tabs.onActivated.addListener(()=>Ye()),chrome.tabs.onUpdated&&chrome.tabs.onUpdated.addListener((e,t)=>{(t.status==="complete"||t.url||t.favIconUrl)&&Ye()})}catch{}async function jn(){try{n.cachedFavicons=await as()}catch{n.cachedFavicons={}}n.cachedVaultProfiles=await he(),n.cachedActiveVaultId=await Fe();const e=await Ee(),t=await q(),a=t.theme||"light";rs(a);const o=t.language||fa();os(o);const i=await Ct("tabs"),r=await Ct("nativeMessaging");P({hasTabsPermission:i,hasNativeMessagingPermission:r,currentSiteEnabled:t.currentSiteEnabled!==void 0?t.currentSiteEnabled:!0}),typeof chrome<"u"&&chrome.storage&&(chrome.storage.local&&chrome.storage.local.remove("sp_failed_attempts"),chrome.storage.session&&chrome.storage.session.get(["sp_failed_attempts","sp_lockout_until"],g=>{n.failedAttempts=g.sp_failed_attempts||0,n.lockoutUntil=g.sp_lockout_until||0,c.isUnlocked||ae()}));const u=["All",...(t.categories||["Work","Personal"]).filter(g=>g!=="All")],l={...dt,...t.categoryColors||{}},p=t.lockInterval==="3days"||t.lockInterval==="1week"||t.lockInterval==="1month"?"session":t.lockInterval||"session",m=t.autolockMinutes!==void 0?Number(t.autolockMinutes):15;if(P({isInitialized:e!==null,lockInterval:p,autolockMinutes:m,theme:a,language:o,showCardTags:t.showCardTags===!0,showFavicons:t.showFavicons!==!1,useExternalIcons:t.useExternalIcons===!0,categories:u,categoryColors:l}),Ye(),e){const g=await $s();if(g&&g.rawMek&&(e.version===2||e.version===3)&&e.data)try{const k=g.rawMek,y=await mt(e,k),b={keyByPassword:e.keyByPassword,keyByRecovery:e.keyByRecovery};if(y){const j=ht(y);Da(j.items);const F=t.latestProjectId&&j.projects.some(M=>M.id===t.latestProjectId)?t.latestProjectId:j.projects[0].id;P({isUnlocked:!0,rawMek:k,keySlots:b,projects:j.projects,items:j.items,trash:j.trash||[],activeProjectId:F,sessionExpiresAt:g.expiresAt})}}catch(k){console.warn("Session restoration failed:",k),await ve()}}cs().then(g=>{P({passHostStatus:g})}).catch(()=>{});let h=!1;qs(()=>{c.isUnlocked!==h&&(h=c.isUnlocked,c.isUnlocked?zt({idleMinutes:c.autolockMinutes!==void 0?c.autolockMinutes:15,onLock:()=>je()}):Lt()),ae()}),c.isUnlocked&&(h=!0,zt({idleMinutes:c.autolockMinutes!==void 0?c.autolockMinutes:15,onLock:()=>je()})),setInterval(()=>{c.isUnlocked&&c.sessionExpiresAt>0&&Date.now()>c.sessionExpiresAt&&je()},3e4),ae()}jn();
